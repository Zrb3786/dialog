# Rollback Points

Fixed package HEAD: `29264b72d7f3bd3156788969e15d931bb6285d48` on `repro/dialogxpert-corrected-v1`.

Important points:

```text
dx-p0-pass-20260716T063043Z	2849eb1a8207650c9d5b91063e9747c3bf5f7f3f	P0 PASS: upstream governance and sealed-test policy
dx-p1-pass-20260716T064517Z	ee4e38f972814f8e4108a2426a29c39499a80f85	P1 PASS: static corrections and CPU validation
dx-p1_5-pass-20260716T080924Z	b53ef2e472e4c8d65683aa472cba1a59e702880e	P1.5 PASS: external review fixes, standalone runtime, and deterministic CPU coverage
dx-p2-recovery-pass-20260717T011953Z	4e0cf23432fd1a4f867922d6dcd38da633ead574	P2-R PASS: formally cloned v2 environment and offline validation
dx-p3-pass-20260717T013139Z	85b3ce893cb7563d8861fe515b156cc2730d5a26	DialogXpert P3 local-Qwen7 bounded smoke pass
dx-p3_5-semantic-pass-20260717T031140Z	a59a0eb79e12f42f61e57b154651cf5985740e92	P3.5 causal Q semantics, action distinguishability, and sampled critic calibration pass; P4 requires separate authorization
dx-p3_6-pretraining-pass-20260717T071500Z	1d7de353f6c51d3abb73320ed4aeb61ac4fef021	P3.6 Gate A-I passed; reviewer authorized bounded P4-A Phase A only
upstream-dialogxpert-7b35ec95	9672fbc5069d656b60de0005c0f2eb789a638e91	Freeze upstream DialogXpert at 7b35ec95 for local reproduction rollback
```

Read-only examples (not executed by this packaging task):

```bash
git show upstream-dialogxpert-7b35ec95
git diff upstream-dialogxpert-7b35ec95..29264b72d7f3bd3156788969e15d931bb6285d48
git switch --detach dx-p3_6-pretraining-pass-20260717T071500Z
git revert <commit>  # use only after independent review
```

The thin bundle requires the upstream prerequisite `7b35ec95ceaad5afeda85438c89ed67b8750625d`. No reset,
checkout, revert, tag movement, commit, or push was performed while packaging.
