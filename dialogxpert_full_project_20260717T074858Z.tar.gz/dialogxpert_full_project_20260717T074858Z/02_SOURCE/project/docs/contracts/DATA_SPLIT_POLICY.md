# Data Split Policy

- Development accepts only explicit `train`, `valid`, and `dev` splits.
- Any path component containing `test`, and any path matching `dialog_all`, is
  denied before filesystem metadata or content access.
- A loader opens only its selected split and never constructs an all-split
  dictionary.
- Python `eval` is forbidden. Legacy line-oriented records use
  `ast.literal_eval` with schema validation until migrated to JSON.
- Test paths are stored only as sealed strings and are never opened, statted,
  hashed, counted, grepped, sampled, or displayed.
- CIMA corrected runs quarantine the exact train record duplicated in valid;
  the repository diagnostic records, but does not silently rewrite, that fact.
- P4G is limited to the verified local train/dev registry until its mismatch
  with the paper is resolved.
- ExTES is `BLOCKED` because the available aggregate may contain test data.
- Final-test scripts hard fail without an external frozen-manifest and explicit
  authorization token; P0-P3 never provides that token.

