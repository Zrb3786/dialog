# Model Asset Policy

- Exact repo ID, revision, provider, license/model card, file list, sizes, and
  hashes are required for every asset.
- Reuse the existing Qwen2.5-7B and BERT assets read-only after offline
  verification.
- Qwen2.5-14B uses a provider-specific staging directory, limited retries, and
  an atomic final rename only after verification.
- Provider fallback is hf-mirror, then Hugging Face official, then ModelScope
  only after exact manifest equivalence is proven.
- Partial files from providers are never mixed.
- Each download requires at least `50 GiB + 1.10 * estimated_asset_size` free;
  existing assets are never deleted to satisfy the reserve.
- `.complete.json` is written only after index, shards, config, tokenizer,
  model card/license, revision, and hashes pass verification.
- All model loading is local and offline during P3; Qwen2.5-14B is not loaded.

