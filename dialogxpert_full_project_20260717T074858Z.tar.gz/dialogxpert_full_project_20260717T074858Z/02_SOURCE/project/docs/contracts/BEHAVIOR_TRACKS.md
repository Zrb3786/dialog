# Behavior Tracks

| Track | Purpose | Required behavior |
|---|---|---|
| `repository_diagnostic` | Preserve upstream behavior for static or synthetic diagnosis | Original integer parsing, coupled emotion, reward and termination are identified explicitly; never used as corrected results |
| `prompt_faithful` | Match the released TOP-k integer prompt | Strict exact-k IDs, no invented probabilities, coupled emotion/system response retained as a declared baseline |
| `official_formal` | Represent the formal paper prior | Beam/continuation candidates, log-probability aggregation, deterministic projection, normalized prior; P0-P3 tests interfaces only |
| `corrected_primary` | Scientifically safe primary method | Causal emotion before action, explicit emotion in prior/Q state, strict parser, safe RL target, solved-only ESConv success, validation-only development |

Every config, log, transition, metric, checkpoint, and report must include one
track value. Cross-track checkpoint loading or metric aggregation is rejected.

