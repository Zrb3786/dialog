# Metrics Contract

- Metrics include behavior track, dataset, split, seed, case count, attempted
  and completed episodes, parse failures, generation failures, timeouts, and
  quarantined cases.
- Report attempted, eligible, completed, solved, failed, and quarantined counts.
- Report `SR_attempted`, `SR_eligible`, `AT_attempted`, `AT_completed`,
  `average_reward_attempted`, and `average_reward_completed`; never collapse
  quarantine or generation failure into one hidden denominator.
- `episode_reward` is the sum of turn rewards.
- ESConv `better` is positive but non-terminal for `corrected_primary`.
- A max-turn unresolved episode is a terminal failure. A solved final turn wins
  over the timeout condition.
- Call accounting separately reports `generation_invocations_by_role`,
  `returned_sequences_by_role`, `valid_parses_by_role`,
  `invalid_parses_by_role`, `retries_by_role`, and `unique_outputs_by_role`,
  plus prompt/completion tokens. Batched critic sequences share one invocation.
- `prior_parse_failure_rate` uses prior returned sequences/attempts only.
  `quarantined_cases` is the cardinality of persisted unique case IDs and is
  never an episode counter.
- Also report termination distribution, critic validity, and prior parse
  failure rate.
- No test metric may be computed in P0-P3.
