# Checkpoint Contract

Each checkpoint contains or references:

- online and target Q MLP state;
- optimizer and scheduler state;
- bounded replay raw transitions;
- episode, turn, and update counters;
- Python, NumPy, Torch, CUDA, and sampler RNG state;
- dataset-registry version and behavior track;
- prompt, action, reward, termination, and metric configuration;
- model, tokenizer, BERT, environment, code-commit, and dirty-state manifests;
- validation metrics and structured failure counters.

Large frozen model weights are referenced by immutable path/revision/hash and
are never copied into checkpoints. Loading rejects cross-track, dirty-code,
dataset-manifest, or model-manifest mismatches unless an explicit diagnostic
override is logged. A round-trip test must reproduce the next Q update.

Format version 2 additionally requires a SHA-256 sidecar, exact payload keys,
code commit/dirty-state checks, serialized replay sampler RNG/counter, and an
explicit `trusted_local_only=True` declaration. Because
`torch.load(weights_only=False)` can execute pickle payloads, external or
unverified checkpoints are always rejected.

Format version 3 is the P3.5 causal replay boundary. Every transition carries a
`PlannerStateView`, separate runtime audit snapshot, pair-encoded candidate
actions, all behavior-time feature hashes/Q values/token statistics, epsilon
draw and selection mode, and the corresponding next causal view. Format v2
and replay payloads without replay schema version 2 are rejected rather than
migrated. Small checkpoints produced here remain trusted-local Torch artifacts;
a future release should split Q tensors to safetensors and optimizer/replay/RNG
state to an explicitly trusted local artifact or JSON/NPZ representation.
