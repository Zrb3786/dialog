# Logging and Tmux Contract

Background tasks write under `logs/<task>/<UTC_TIMESTAMP>/`:

```text
command.sh
stdout.log
stderr.log
heartbeat.log
status.json
environment.txt
artifact_manifest.tsv
```

Python logging and status writes are line-buffered or explicitly flushed.
Every 60 seconds a heartbeat records timestamp, PID, tmux session, stage,
episode/step, last metric, GPU ID/memory, and disk free. Session names are
stable, duplicate launch is rejected, and a lock file protects watchers.
Foreground confirmation is limited to two minutes; long-running work remains
observable through tmux and logs.

Status and heartbeat context includes commit, behavior track, dataset, split,
model path/hash, GPU, PID, and tmux session. Duplicate logger handlers are
removed. A heartbeat callback failure writes a FAILED status and terminates the
heartbeat thread instead of dying silently.
