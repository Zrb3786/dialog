# P3.6 Storage and Checkpoint Report

Status: **PASS**  
Implementation commits: `9be8109`, `41f723b`

- CLS and masked-mean outputs pass through `detach().to("cpu").contiguous().clone()`.
- `PairEncodingResult` rejects non-contiguous or aliased backing storage.
- `Transition` independently validates candidate, selected, and next feature storage.
- Every tensor audit records shape, numel, element size, logical bytes, backing-storage
  bytes, contiguity, and compactness.
- A synthetic 30-transition checkpoint is below the pre-registered 10 MiB gate.
- Replay schema is 3 and checkpoint format is 6; older noncompact/noncausal formats
  are rejected without migration.
- Checkpoint v6 contains the full resume contract plus pilot config/hash, fixed
  validation schedule, stop state, and TaskLog run ID.

Evidence: `tests.test_p3_6.CompactStorageTests` and checkpoint/replay negative tests
passed in the final 90-test offline CPU suite on 2026-07-17.
The final live CLS checkpoint is 1,555,110 bytes and the masked-mean checkpoint is
969,479 bytes; both SHA-256 sidecars verify.

No generation model, GPU, network, API, download, test-split content, or remote push
was used for this gate.
