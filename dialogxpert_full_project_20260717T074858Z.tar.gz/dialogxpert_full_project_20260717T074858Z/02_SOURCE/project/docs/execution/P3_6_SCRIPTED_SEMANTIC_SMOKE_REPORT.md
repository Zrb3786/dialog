# P3.6 Scripted Semantic Smoke Report

Status: **PASS**
Artifact root: `artifacts/p3_6/scripted_final_20260717T063238Z`
Source commit: `322252e28770bd252dffe70ecebdfe655d7374b8` (clean)

Corrected and Appendix/prompt-faithful protocols each completed two train and
three valid episodes with episode-addressed seeds, one Q update, checkpoint v6,
and two independent fresh-process next-update verifications.

Across eight candidate sets per protocol, every four-action set had four distinct
feature hashes and nonzero Q variance. Action preservation, zero tokenizer state
truncation, state-token budgeting, forbidden-key absence, next-turn timing, and
exact-prompt persistence all passed. Checkpoints are 156,285 bytes (corrected) and
155,349 bytes (Appendix).

Artifacts:

- result: 16,012 bytes, SHA-256
  `64e33aaa4ab09ccf69273fcae8cb1b4673e7a8eefe91bcf06a48b3cf9163261a`;
- corrected checkpoint SHA-256
  `c16dc1100f09272aabaf77bfc08e9356f67499bea4de1ffa0aaf287844c3251c`;
- Appendix checkpoint SHA-256
  `78c24c4f11775052f05cd795e561c58ccc959848c38a9b936338b19f03c9527e`.

Scripted rewards are fixture behavior, not effectiveness evidence. No GPU,
generation model, network, API, download, test split, full training, or push was
involved.
