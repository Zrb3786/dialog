# P3.5 External Semantic Review

Status: `P3_DOWNGRADED_TO_INFRASTRUCTURE_ONLY`

The external review of P3 and the incremental review pack identified fatal
state-action semantic defects. The prior `dx-p3-pass-20260717T013139Z` tag is
retained unchanged as historical evidence, but it proves only model plumbing,
bounded execution, logging, and checkpoint round-trip infrastructure. It does
not prove a causal Q state, distinguishable action features, or sampled critic
self-consistency.

Evidence is bound to launch commit
`4d3d4bea78c9427651473c1dbe441673ba57c937`, report commit
`6ea4d57991f0a6be8ea7a8961d24228c4682325b`, and review pack
`dialogxpert_p1_5_p3_review_20260717T015124Z.tar.gz` with SHA-256
`d8ae9b4c656c6f7857a795c1b017d7fbae4c5b57043076e88935de18c913f527`.

## Findings

1. `DialogueState.case_metadata = dict(case)` retained the complete ESConv
   gold `dialog`, including future utterances and future gold strategies.
   `_state_action_texts()` serialized this privileged raw case into Q input.
2. Q input was one long `State: <JSON>\nAction: ...` string. BERT truncated at
   512 tokens before the tail action, so different actions and turns could
   produce identical features.
3. `last_reward` and `terminal_reason` were serialized into the planner/Q
   state even though they are privileged critic/simulator outputs.
4. Nonterminal next candidates could be prepared before advancing
   `turn_index`, yielding a stale next-state time index.
5. The live backend used greedy generation for ten identical critic calls.
   Parser-valid duplicates do not establish stochastic self-consistency.
6. The observed reward labels collapsed to 270 `worse`, 20 `same`, 20
   `better`, and zero `solved`; the prior smoke did not establish a useful
   learning signal.
7. The prompt-faithful quarantine outputs were semantically valid
   `Emotion`/`Response` records separated by a blank line. The parser produced
   a false-positive failure.
8. P3 did not persist exact rendered prompts or all behavior-time candidate
   features/Q values, so post-hoc reconstruction was incomplete.

## Formal reclassification

```text
P3_MODEL_PLUMBING = PASS
P3_CHECKPOINT_INFRASTRUCTURE = PASS
P3_Q_STATE_CAUSALITY = FAIL
P3_ACTION_DISTINGUISHABILITY = FAIL
P3_CRITIC_STOCHASTIC_CONSENSUS = NOT_TESTED
P4 = NOT_AUTHORIZED
```

## Required P3.5 remedies

- separate runtime audit state from a causal `PlannerStateView`;
- enforce audience-scoped dataset views and future-gold invariance;
- encode state/action as a BERT pair with `truncation="only_first"`;
- test CLS and masked-mean pooling without preselecting the winner;
- advance turn time before constructing next planner state;
- accept blank lines in the strict coupled parser while rejecting structural
  ambiguity;
- persist exact prompts and all candidate decision evidence at generation
  time;
- use role-specific generation and sampled critic calibration;
- reject legacy checkpoint/replay semantics through a schema bump.

Change ID: `DX-P3_5-001`. No test split content was accessed while recording
this review.
