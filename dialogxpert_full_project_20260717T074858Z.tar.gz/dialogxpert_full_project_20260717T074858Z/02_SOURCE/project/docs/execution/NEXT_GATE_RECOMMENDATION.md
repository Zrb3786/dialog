# Next Gate Recommendation

Status: `USER_AUTHORIZATION_REQUIRED`

Branch: `repro/dialogxpert-corrected-v1`; last passing tag:
`dx-p1-pass-20260716T064517Z`; relevant commits: `be79cac`, `812f558`,
`88ab546`. Change location is the preserved target prefix and the revision-
specific 14B partial asset; no current tmux/PID is active.

Recommended recovery order:

1. Authorize either removal/recreation of the invalid target prefix or creation
   of a new target path. Do not overlay more packages onto the current prefix.
2. Recreate Python 3.10 and the locked ML stack, then require pip, torch,
   transformers, tokenizer, local Qwen7 metadata, and offline BERT CPU-forward
   gates to pass inside that exact environment.
3. Resume the 14B hf-mirror staging directory only after mirror TLS is stable;
   retain exact revision `cf98f3b3bbb457ad9e2bb7baf9a0125b6b88caa8`
   and require all eight shards plus full verification before atomic publish.
4. Add and review the bounded P3 harness as commit `P3-1`, then launch only the
   specified two-train/three-valid, five-episode, two-turn ESConv smoke on one
   A800. Create `dx-p3-pass-*` only after corrected and prompt-faithful replay
   assertions pass.

Reason/tests/artifact hashes are in the P2/P3 reports and final execution
report. No rollback or deletion should occur without explicit authorization.
