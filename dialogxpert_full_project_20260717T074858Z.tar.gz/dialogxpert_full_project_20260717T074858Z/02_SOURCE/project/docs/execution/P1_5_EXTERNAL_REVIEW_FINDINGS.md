# P1.5 External Review Findings

Status before correction: `P1_STATIC=PASS`,
`P1_INTEGRATED_RUNTIME=NOT_YET_IMPLEMENTED`.

Accepted foundations were the frozen upstream/tag governance, train/valid-only
registry, sealed-test denylist, strict integer action parser, masked BERT
pooling, bounded replay, boolean terminal Bellman target, disabled legacy
training entry point, and preservation of the invalid environment and partial
14B download.

Required corrections were:

- replace any-success critic termination with minimum-valid conservative
  consensus;
- normalize formal full/top-k probabilities, remove action ID zero, and expose
  unmatched/ambiguous projection;
- preserve index zero and correct CB metadata;
- introduce real ESConv/CIMA/CB/P4G case-specific prompts;
- add a standalone corrected runtime and scripted/local-only backends;
- persist complete raw transition/replay provenance;
- separate metrics denominators;
- verify checkpoint integrity and next-update determinism;
- harden structured parsers and TaskLog;
- keep legacy FastChat `Env` diagnostic-only.

No test split content was used to reach or implement these findings.
