# P3.6 Live Semantic Smoke Report

Status: **PASS (semantic execution; no effectiveness claim)**
Source commit: `322252e28770bd252dffe70ecebdfe655d7374b8` (clean)
Run: `logs/p3_6_live_audit/20260717T063210Z`
tmux: `dx_p36_live_final_20260717T063210Z` (completed)
PID: `1930428`

The bounded run used local Qwen2.5-7B-Instruct and local BERT on one remapped
physical A800. Corrected protocol identity stayed bound to
`critic_compact_enum_v1`; the calibrated Appendix recommendation was recorded but
not substituted across protocols.

## Main CLS evidence

- Five train and five valid episodes, three turns each; all 30 candidate sets had
  four distinct feature hashes, nonzero Q variance, preserved actions, zero BERT
  state truncation, enforced serializer token budgets, causal Q state, correct
  next-turn timing, and exact persisted prompts.
- Two updates completed with losses `0.8022736311` and `0.6616421342`.
- Train critic validity was 148/150 (98.67%); valid was 150/150. Prior parse
  failures were zero. All five train and five valid episodes reached the bounded
  max-turn failure; this is not a success-rate claim.
- Emotion alias v2 hash is
  `9c11cf8280b9a6c851b57b442b6e9a9bf6b3f6f8645d39db1b63fc4f72aefa6e`.
  Train observed 15 labels with 7 OOV (46.67%); valid observed 15 with 3 OOV
  (20%). Unknown labels were retained with OOV flags, not collapsed to `other`.
- Two fresh-process continuations were exact: next loss `0.5140789747` and
  identical online/target hashes.

## Masked-mean ablation

The separately hashed `corrected_masked_mean_ablation` ran three train and two
valid one-turn episodes. All five candidate sets passed the same semantic gates.
Its update loss was `1.1901462078`; exact fresh-process continuation loss was
`0.8933466077`. Train and valid critic validity were 100%.

## Artifacts

- result: 20,605 bytes, SHA-256
  `e8e5230299ad4ed2034acc94caf920cedb4754263899fb2c59f07b41a818b39d`;
- CLS checkpoint: 1,555,110 bytes, SHA-256
  `65baabcba0f6d542a97233ee847b53fbd4c89b8ee5054785d38d24df5a413a5d`;
- CLS generation/transition records SHA-256
  `ee22bc06b2966f01fda2dd7534bd9752eecb94437fca956e8929dff01aac2472` /
  `de2f6e9bd63b737535e86b9fe91c48e9012ec1586b72be1f5f922104cb820bd5`;
- masked-mean checkpoint: 969,479 bytes, SHA-256
  `c50fa7771fb18d8bd61ca997906059850b96098728d5cf675524200ef4119c94`;
- masked-mean generation/transition records SHA-256
  `4699e127daf0bbf461d9787962349e2081910a9b98d0b0d53d24d65f572f3f0d` /
  `a7d2c57a1ca2ecc051ab0ed3ebd1726b26d8ff6ebd020d9cd814ada4a0c136c2`.

Both checkpoint sidecars verify. The task has the complete tmux command, four
heartbeats, status/environment, empty stdout/stderr, and artifact manifest. No
test content, network/API, 14B asset, full training, or push was used.
