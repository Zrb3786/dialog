# P3.6 Emotion Protocol Report

Status: **PASS**  
Implementation commit: `b12f4ad`

Planner emotion is now the typed `EmotionState(label, source_turn_index,
source_role, source_text_sha256, tracker_variant)`. Raw tracker model output exists
only in immutable `GenerationRecord.raw_output`. The runtime audit object retains
source role/hash, while `PlannerStateView` projects only label, source turn index,
and tracker variant; neither raw output, source text, source hash, nor source role
enters Q state.

The explicit variants are:

- `tracker_case_oracle`: case-aware/oracle ablation;
- `tracker_text_only`: corrected default, inferred only from conversation text;
- `no_emotion`: no tracker call and no emotion state.

Alias normalization is versioned as `emotion-alias-v2`, has a stable mapping hash,
and canonicalizes the required anxiety/anxious, frustration/frustrated, and
depression/depressed pairs. Unknown normalized labels are retained—not forced to
`other`—while a separate OOV flag supports accounting. Focused tests verify
raw-output exclusion, the six required aliases, unknown-label retention, OOV
behavior, and variant validation.

The final live smoke records the explicit denominator and mapping hash. CLS train
observed 15 outputs with 7 OOV (46.67%); valid observed 15 with 3 OOV (20%). This
is not leakage: the planner retains the normalized unknown label plus an audit OOV
flag and never collapses it to `other`. It remains a calibration limitation.

No test-split content, external API, or model download was used.
