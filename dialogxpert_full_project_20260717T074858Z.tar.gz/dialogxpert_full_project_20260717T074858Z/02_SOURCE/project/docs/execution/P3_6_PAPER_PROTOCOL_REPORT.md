# P3.6 Paper Protocol Report

Status: **PASS (implementation/snapshot gate)**  
Implementation commits: `ef5910d` plus the final adversarial-gate closure commit

Three non-interchangeable `ProtocolConfig` objects now have independent SHA-256
identities and are persisted in generation, transition, result, and checkpoint
configuration evidence:

- `released_code_compat`: released integer top-4, coupled response, released
  critic/reward, better-or-solved termination semantics;
- `extended_prompt_faithful`: Appendix prompts, exact complete-sentence critic
  options, and exact natural-language strategy descriptions;
- `corrected_resolved_only`: text-only emotion before action, emotion in Q/prior,
  sampled majority, positive-but-nonterminal better reward, solved-only success.

Each machine-readable protocol now freezes prior, system, user, and critic prompt
variants; emotion tracker; critic sampling; reward aggregation; termination;
Q-state variant; pooling; epsilon schedule; generation seed policy; and generation
profile. `EpisodeConfig` rejects silent behavior-track, critic, emotion, and top-k
mismatches. Oracle, no-emotion, and masked-mean ablations have independent protocol
names and hashes rather than retaining corrected-primary provenance.

Pilot controls are also non-interchangeable: A0 uses the separately hashed
`corrected_prior_only_pilot`; A3 uses `corrected_all8_q_pilot` and bypasses the
LLM prior. Phase A and conditional Phase B envelopes for A0-A3 and both required
A1/A2 learning rates are frozen in `configs/p4_a/registry.json`.

The ESConv strategy descriptions exactly follow local `qwen_prompts.py` (the
extended-paper implementation source). The Appendix runtime independently routes
the local exact ESConv policy, coupled therapist, patient, and full-sentence critic
messages. Paper-compatible prior generation is frozen at temperature 1.0,
top-p 1.0, and 25 new tokens. Critic prompt IDs are
`critic_released_code_v1`, `critic_appendix_full_sentence_v1`, and
`critic_compact_enum_v1`. Strict full-sentence parsing and all four runtime prompt
routes are covered by snapshots. C0/C1/C2 calibration records now carry the
protocol name/hash corresponding to released, Appendix, or corrected semantics.

This report does not claim paper-scale reproduction or model effectiveness.
