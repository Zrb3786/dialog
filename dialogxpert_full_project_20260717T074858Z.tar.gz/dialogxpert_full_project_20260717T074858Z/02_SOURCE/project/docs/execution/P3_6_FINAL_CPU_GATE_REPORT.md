# P3.6 Final CPU Gate Report

Status: **PASS**

- Source commit: `f874604cbc7ad13881b9d4c807288e60736f3b4d`
- Artifact root: `logs/p3_6_cpu_gate/20260717T071009Z`
- Device: CPU; offline mode; bytecode writes disabled for the test command
- Result: 90 tests passed in 177.679 seconds
- Task status: `COMPLETE`
- Heartbeat file: one header plus three timed heartbeat records

The final clean-source gate ran `python -m unittest discover -s tests -v` and
covered the complete P3.6 suite, including the 20 fail-closed P4-A harness tests.
Those tests exercise exact reviewer authorization, test-split fail-before-open,
shared cross-arm generation schedules, validation isolation, A0/A3 semantics,
Q/target-update accounting, exact episode-20 migration, checkpoint roundtrip,
and the registered hard-stop thresholds. No P4-A episode was executed.

Evidence SHA-256:

- `stderr.log`: `2abb71d68db507b2cacba7296c233c9e108f448a096e22d1ed755b9a4e8c45b3`
- `stdout.log`: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
- `status.json`: `11abb0acb0c8325d108136e7954c708680bfa5053ad09a9e9c596f9e3993aa94`
- `command.sh`: `3b59719133db2353158a61c1b6ed21cf78a873acd40228d03db0a544f92a133b`
- `environment.txt`: `e2378b59ee3e0a19d9a6e063cd8e993c6d2da53ee23d19cfdb89acb478330640`
- `heartbeat.log`: `0b68f8b409158d1d48ebe97298277147ea56170408e341bb522a32032cbf18e8`
- `artifact_manifest.tsv`: `fa4a3be31ca0c6d72e08bfa2f572544ddc770711ea263509b2b171db35876a2e`

Safety: no dataset test content, GPU, network/API, model download, full training,
or remote push was used by this gate.
