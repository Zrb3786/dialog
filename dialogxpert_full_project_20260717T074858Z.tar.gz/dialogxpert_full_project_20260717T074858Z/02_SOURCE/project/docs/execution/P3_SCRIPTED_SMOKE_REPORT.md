# P3 Scripted Smoke Report

Status: `PASS`

- Branch: `repro/dialogxpert-corrected-v1`
- Input tag: `dx-p2-recovery-pass-20260717T011953Z`
- Environment: `/data1/zhangruibo/conda_envs/dialogxpert_qwen_v2`
- Backend/encoder/device: ScriptedBackend / SHA256 deterministic encoder / CPU.
- Cases per track: 2 fixed train, 3 fixed valid; max turns 2; top-k 4.
- Tracks: `corrected_primary`, `prompt_faithful`.
- Q update: exactly one initial update per track.
- Checkpoint: format v2 with SHA sidecar and clean Git code state.
- Fresh-process replay: two independent processes per track produced identical
  next-update loss and identical online/target parameter SHA-256.
- Test/data safety: train/valid only; no test access, network, API, GPU, model
  weight, legacy Env, FastChat, self-play training loop, or full training.
- tmux/PID: not needed; bounded foreground CPU task completed.
- Artifact directory:
  `artifacts/checkpoints/smoke/scripted_20260717T012200Z`.

Results:

| Track | Train/valid completed | Initial loss | Next loss | Checkpoint SHA-256 |
|---|---:|---:|---:|---|
| corrected_primary | 2/3 | 0.4685889482498169 | 0.18272870779037476 | `3ae9988a13c192390c20bb8a703d4fed9f3838653eb36a96a5bd5415347645a6` |
| prompt_faithful | 2/3 | 0.4761703312397003 | 0.2406105250120163 | `4f5c9d76e3e4b348576242db368f2692d0d6fd42772804bad2c1801d6dfb7af7` |

Result JSON SHA-256:
`56b62303ad0d7c62c43594a037452d4e9918e9b78cc5c9ce9886ef30db376489`.
Change IDs: `DX-P3-101`, `DX-P3-102`.
