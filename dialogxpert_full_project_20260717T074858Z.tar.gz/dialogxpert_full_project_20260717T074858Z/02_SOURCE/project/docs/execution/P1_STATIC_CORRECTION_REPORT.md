# P1 Static Correction Report

Status: `PASS`

Branch: `repro/dialogxpert-corrected-v1`; upstream rollback tag:
`upstream-dialogxpert-7b35ec95`; P1 pass tag:
`dx-p1-pass-20260716T064517Z`. P1 commits are `d60e1c3`, `91fdc56`,
`32f0afe`, `7517040`, `ca82aa4`, and `bb10b44`. Changed files,
symbols/locations, reasons, tests, and rollback tokens are enumerated by
`DX-P1-*` in `docs/change_registry.tsv`.

Implemented corrections:

- disabled the legacy `train_model.py` auto-test execution path;
- removed the undeclared `chip` import and unused encoder load from execution;
- forced local-only frozen Qwen/BERT loading;
- replaced unsafe all-split `eval` loaders;
- routed dataset policy/system/user/critic behavior through the registry;
- introduced one `DialogueState` and fixed reset/history causality;
- added strict prompt-faithful parsing and formal projection interfaces;
- added causal corrected-primary emotion interface;
- added masked BERT pooling, candidate masks, bounded replay, bool terminal,
  configured gamma, correct next action, target updates, reward schemas, and
  solved-only corrected ESConv termination;
- added atomic checkpoint/resume, explicit metrics, status, and heartbeat logs.

The 12-test CPU suite and registry dry-run passed in the inspected reference
environment. No tmux process was required. No P1 model/checkpoint artifact was
created; hashes are recorded in the final execution report.
