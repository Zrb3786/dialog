# P3.6 Known-MDP Report

Status: **PASS**  
Implementation commit: `41f723b`

The four-action deterministic ToyBandit trains the production `QMLP` on fixed
normalized hash-style features and converged to the unique best action for seeds
3, 17, 101, and 509. The Two-Step MDP uses the same `QMLP`, a separately frozen/
periodically updated target network, discounting, and terminal masks; it converged
to the delayed-reward advance action for the same four seeds.

The pre-registered reward-shuffle negative control swaps the reward association and
reliably changes the learned first-step policy from `advance` to `short`. Thus the
gate detects reward/transition corruption rather than merely checking execution.

All three neural known-MDP tests passed in 150.111 seconds on offline CPU. These
tests are synthetic and access no dataset records.
