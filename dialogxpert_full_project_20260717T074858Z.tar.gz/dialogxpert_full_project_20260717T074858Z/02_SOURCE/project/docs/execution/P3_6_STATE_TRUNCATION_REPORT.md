# P3.6 State Truncation Report

Status: **PASS**  
Implementation commit: `b12f4ad`

`RuntimeState` remains the privileged audit object. `PlannerStateView` excludes raw
case metadata, reward, termination, critic labels, internal registry keys, and case
identity. `recency_critical_first_v2` serializes, in protected leading position:

1. audience-scoped public case context;
2. current turn index;
3. latest user utterance;
4. current planner-safe emotion.

It tokenizes every candidate action first, reserves the longest action plus all
three BERT pair special tokens, and gives the remaining exact token budget to the
state serializer. It then retains newest complete conversation turns and drops
oldest complete turns until both token and defensive character budgets fit. Each
transition persists kept/dropped turn IDs, serialized/max state tokens, reserved
action tokens, preserved-field flags, and truncation reason. BERT pair encoding
continues to use `only_first` as a fail-safe, and the semantic gate now requires
that it performs zero additional state-token truncation.

When a case-context field is byte-identical to the latest user utterance (the
ESConv initial situation), v2 retains the full text once under `current_user` and
records the deduplicated field name as an audited semantic reference. It never
shortens the current user text. Planner emotion is projected to the required
label/source-turn/tracker tuple; audit-only source hashes and roles do not consume
Q tokens.

An 8-turn long-dialogue stress test forced truncation while preserving all three
critical sentinels, stayed within the exact tokenizer budget, and incurred zero
additional BERT state truncation. Future-gold mutation leaves both stable ID and Q
text byte-identical. `case_id`, raw emotion, last reward, and terminal reason are
absent from Q text.

A tokenizer-only preflight over the exact Gate-H population (100 train + 50 valid)
with a deliberately OOV two-token emotion label found zero budget failures. All
150 initial situations were deduplicated; the maximum serialized state was 281
tokens with 11 tokens reserved for the longest action and pair specials.

No test-split content was accessed.
