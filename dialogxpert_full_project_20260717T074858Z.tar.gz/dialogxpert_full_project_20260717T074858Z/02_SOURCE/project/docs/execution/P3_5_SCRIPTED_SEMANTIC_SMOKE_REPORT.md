# P3.5 Scripted Semantic Smoke Report

Date: 2026-07-17 UTC

The deterministic smoke ran two train and three valid ESConv cases for each of `corrected_primary` and parser-regression `prompt_faithful`, with two turns per completed episode, one Q update, checkpoint format v3, and two fresh-process next-update verifications.

For each track:

- 10/10 candidate sets had 4/4 unique feature hashes;
- all candidate Q variances were strictly positive;
- action retention, causal forbidden-key scan, next-turn timing, and exact-prompt persistence passed;
- all 2 train and 3 valid episodes completed;
- the two fresh-process Q update JSON results were byte-identical.

Artifacts are under `artifacts/p3_5/scripted_20260717T025005Z/`: full generation JSONL, full transition JSONL, checkpoint + SHA sidecar, contract, fresh-update outputs, and aggregate result for each track.

STATUS: P3_5_SCRIPTED_SEMANTIC_SMOKE_PASS
