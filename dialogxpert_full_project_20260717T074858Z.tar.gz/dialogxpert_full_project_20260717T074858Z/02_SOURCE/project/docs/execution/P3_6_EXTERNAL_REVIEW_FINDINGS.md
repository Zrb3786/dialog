# P3.6 External Review Findings

Recorded: 2026-07-17T04:17:52Z  
Baseline: `487c0874b6f977d30388f02ec60c60dc581e4e0f`  
Scope: read-only confirmation of the external P3.5 review findings before remediation.

## Status

P3.5 is an infrastructure and semantic-smoke milestone, not authorization for
paper-scale training. P4-A remains blocked until every P3.6 gate has executable,
reviewable evidence.

## Confirmed findings

1. **CLS storage alias and checkpoint bloat.** `FrozenBertEncoder.encode_pairs`
   selects `output[:, 0, :]` and only applies `detach().cpu()`. The logical CLS
   feature can therefore retain the complete BERT hidden-state storage. Existing
   evidence shows an approximately 177 MiB CLS checkpoint versus approximately
   0.925 MiB for masked-mean pooling.
2. **Recency loss under right truncation.** BERT pair encoding correctly uses
   `truncation="only_first"`, which protects the action segment, but the current
   monolithic state JSON is right-truncated. Recent turns, the current user
   utterance, current emotion, and other decision-critical tail state may be
   removed.
3. **Unstable and semantically contaminating case identity.** `case_id` is
   serialized into Q text and fallback identity is derived from a hash of the
   complete raw record. Future-gold edits can therefore change both the Q input
   and sample identity.
4. **Emotion raw output leaks into planner state.** The current emotion history
   stores raw tracker output alongside the normalized label. Raw output can be
   the whole generated utterance and is duplicated into the Q state.
5. **Oracle emotion exposure.** Initial gold/case emotion can be exposed to the
   tracker path. Oracle, text-only, and no-emotion variants are not represented
   as distinct protocols with independent provenance.
6. **Appendix critic mismatch.** The current `paper` critic is a compact enum
   prompt, not the Appendix full-sentence critic contract. It cannot establish
   appendix-exact behavior.
7. **RNG and resume are not episode-addressable.** Generation seeds depend on a
   global invocation counter and case hash. Validation or retry ordering can
   perturb later training, and checkpoint state does not prove exact full-episode
   resume.
8. **Background execution evidence is incomplete.** Prior runs do not uniformly
   contain the full command, 60-second heartbeat, status, environment, and
   artifact manifest required for every tmux task.
9. **Protocols are conflated.** Released-code compatibility, appendix-exact
   behavior, and corrected resolved-only behavior require separate machine-
   readable configurations, hashes, prompts, rewards, termination semantics,
   and result namespaces.

## Required disposition

The above findings are blocking. Remediation must cover compact tensor ownership,
recency-aware state serialization, stable split/row identity, typed emotion
state, protocol separation, Appendix-exact prompts, functional episode seeds,
exact resume, known-MDP learning gates, prior coverage, critic stability, and
complete task logging before P4-A can be authorized.

## Safety boundary

No dataset test content was opened, parsed, counted, hashed, sampled, copied, or
displayed while confirming these findings. No model was loaded, no GPU was used,
and no network/API/download/push operation was performed.
