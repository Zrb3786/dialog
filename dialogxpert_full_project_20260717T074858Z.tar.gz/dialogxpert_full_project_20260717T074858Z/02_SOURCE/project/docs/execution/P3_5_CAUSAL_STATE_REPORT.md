# P3.5 Causal State Report

Date: 2026-07-17 UTC

## Boundary

`RuntimeState` remains the privileged runtime/audit object. It may retain the raw train/valid case and terminal bookkeeping, but no Q or prior code may serialize it. `PlannerStateView` is frozen and contains only dataset, case ID, registered public context, occurred conversation, occurred emotion history, and current turn index.

The registry now defines independent `planner`, `policy`, `system`, `user`, `critic`, and `emotion` field sets. ESConv planner views exclude `dialog`; CIMA gold target is critic-only; CraigslistBargain buyer/planner and seller/user goals are mutually hidden while the critic sees both; P4G exposes no raw case fields; ExTES remains blocked.

## Causal gates

- Mutating the complete ESConv future gold dialog leaves planner bytes and pair features unchanged: PASS.
- Removing the ESConv raw dialog leaves initialization/planning operational: PASS.
- `dialog`, `strategy`, `_dx_*`, `last_reward`, and `terminal_reason` are rejected from planner payloads and absent from recorded Q state: PASS.
- Nonterminal next state advances to `turn_index=t+1` before emotion/prior/encoding; the next transition reuses exactly that planner state and state text: PASS.
- Runtime audit snapshots retain only occurred history and metadata key names, never raw future values: PASS.

Evidence: `dialogxpert_repro/views.py`, `registry.py`, `runtime.py`, 45-test CPU gate, and `artifacts/p3_5/scripted_20260717T025005Z/*.transition_records.jsonl`.

STATUS: P3_5_CAUSAL_STATE_PASS
