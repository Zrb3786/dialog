# P3 Live Qwen7 Smoke Report

Status: `PASS_WITH_STRUCTURED_QUARANTINE`

- Branch/launch commit: `repro/dialogxpert-corrected-v1` /
  `4d3d4bea78c9427651473c1dbe441673ba57c937`.
- Input tag: `dx-p2-recovery-pass-20260717T011953Z`.
- Change IDs: `DX-P3-102`, `DX-P3-103`.
- Runtime: standalone `dialogxpert_repro` runner; legacy Env and FastChat were
  not imported.
- Environment: `/data1/zhangruibo/conda_envs/dialogxpert_qwen_v2`.
- Model: local-only `/data1/zhangruibo/models/Qwen2.5-7B-Instruct`, BF16,
  greedy generation, seed 7, trainable parameters 0.
- Model index SHA-256:
  `624bf7c47cd12468fdc16e38a47cf4f19e0415b859a223ba3c027eed2f0e1028`.
- Encoder: local BERT on CPU, frozen; Q heads and updates on `cuda:0` mapped
  exclusively to physical A800 GPU 5.
- Workload per track: five train episodes from two fixed train cases, three
  fixed valid cases, at most two turns, top-k 4, ten critics per turn, and one
  Q update. Only `train` and `valid` were opened.
- Tracks: `corrected_primary` and `prompt_faithful`.
- Session/PID/log: `dx_esconv_7b_smoke` / `1442198` /
  `logs/esconv_smoke/20260717T013500Z`. The session exited normally after the
  task wrote `COMPLETE` at `2026-07-17T01:27:46Z`.
- GPU gate: 81,153 MiB free before launch; observed model-run usage remained
  within one GPU. No other GPU was exposed to the process.
- Network/API: `HF_HUB_OFFLINE=1` and `TRANSFORMERS_OFFLINE=1`; no process TCP
  connection was observed; no external inference API was called.
- Safety: no test split access, no full training, no self-play training loop,
  no remote push, and no Qwen14B asset access or download.

Results:

| Track | Train completed/attempted | Valid completed/attempted | Critic valid | Parse quarantine | Initial Q loss | Fresh next-Q loss |
|---|---:|---:|---:|---:|---:|---:|
| corrected_primary | 5/5 | 3/3 | 160/160 | 0 | 0.9520374536514282 | 0.7120336294174194 |
| prompt_faithful | 5/5 | 2/3 | 150/150 | 1 | 0.9520374536514282 | 0.7120336294174194 |

The prompt-faithful valid quarantine is a strict coupled
`Emotion`/`Response` parse failure after three bounded retries. It generated no
trainable transition for the failed turn and is included in the attempted,
quarantined, and parse-failure metrics rather than silently discarded. This is
a safety-path success, but it remains a reliability item for the next gate.

Both tracks passed two independent fresh-process next-Q updates with identical
loss, online SHA-256
`2ebf5c3878c38fad4409402949975a9162560d80a53297023731b477e33cb52e`,
and target SHA-256
`0c7f3d5d0e3e960ee420fa3b9cdfc636b1f4b763830076971702ea8299486b84`.

Primary artifact SHA-256:

- Result JSON: `c69ac182b3313f541d2017333333d239c12db13812ff0bb01d45f540f8597f59`.
- Generation records (423 lines):
  `c19b9f21ca2d2c764f83f6e712ea0c5a1bfbaa4789a9e1cfd5f7132ee967087f`.
- Corrected checkpoint:
  `b99c7f1467c6b3d65363e4bc0bd105ac79d1c1715088ec50f776cf25ffe9df17`.
- Prompt-faithful checkpoint:
  `fc3003cf936e322dae511ceab5368de91f7941fb6c3be570c58a06932e0cb274`.
- Full manifest: `logs/esconv_smoke/20260717T013500Z/artifact_manifest.tsv`.

The only stderr messages were Transformers/Hugging Face deprecation warnings
and expected BERT head-key differences when loading `BertModel` from the local
pretraining checkpoint. No exception or generation failure occurred.
