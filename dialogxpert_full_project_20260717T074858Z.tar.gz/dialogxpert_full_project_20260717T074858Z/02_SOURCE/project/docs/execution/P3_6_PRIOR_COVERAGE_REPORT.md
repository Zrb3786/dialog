# P3.6 Prior Coverage Report

Status: **PASS (independent exact-k execution; bottleneck retained)**
Run: `logs/p3_6_prior_audit/20260717T060805Z`
Source commit: `2896df42022df1763ee023d250b006298a1b51eb`
tmux: `dx_p36_prior_exactk_pass_20260717T060805Z` (completed)
PID: `1171321`

The final audit covers fixed 100 ESConv train and 50 valid states at seeds 7, 17,
and 29. For every state/seed, k=2, 3, 4, and 5 is a separate model prompt and
rollout address (`seed:<seed>:k:<k>`), not prefixes of one top-5 answer. All 1,800
rows are unique on `(case_id, split, seed, top_k)`. There are 150 distinct prompt
hashes for every seed/k address. The result declares
`top_k_execution=independent_exact_k_prompts_v1`.

| k | rows | parse success | inclusion entropy | random entropy | all-8 Q best retained |
|---:|---:|---:|---:|---:|---:|
| 2 | 450 | 100.00% | 1.271 | 2.998 | 30.44% |
| 3 | 450 | 100.00% | 1.983 | 2.998 | 35.56% |
| 4 | 450 | 100.00% | 2.534 | 2.997 | 50.67% |
| 5 | 450 | 98.67% | 2.643 | 2.998 | 63.78% |

The k=5 failure rate is 1.33%, below the 10% pilot stop threshold, and accepted
sets contain no duplicate IDs. Coverage remains concentrated: at k=4, Reflection
appears in 450/450 and Affirmation/Reassurance in 443/450, while Providing
Suggestions appears in 32/450 and Others in 14/450. This is a measured prior
bottleneck, not balanced exploration; A3 all-eight Q is therefore preregistered
as a separately hashed pilot control.

The preserved run `20260717T055815Z` failed closed because critical state did not
fit its token budget. The repaired serializer deduplicates an ESConv situation
identical to the current user text without shortening the content. A 150-state
tokenizer preflight then had zero failures (maximum 281 state tokens with 11
action/special tokens reserved). The final run has nine heartbeat records,
reconstructed tmux command, status/environment, empty stderr, and SHA manifest.

Artifacts:

- result: 7,390 bytes, SHA-256
  `1ae7af139d1bced5794e1f5b503415d5e156893472ca4845696f402f77591f98`;
- coverage records: 1,431,807 bytes / 1,800 rows, SHA-256
  `7d889c60b430983667b3eb3185bd6f74f9ed32c596294ea9ae19a86c77305e84`;
- generation records: 7,753,995 bytes / 2,368 rows, SHA-256
  `37cfa89496ea5315e166eb63b36d2623ae87d570dbb95c208dee2b87929a996c`.

Only local Qwen2.5-7B, local BERT, one A800, train, and valid were used. No test
content, network/API, download, training, or push was used.
