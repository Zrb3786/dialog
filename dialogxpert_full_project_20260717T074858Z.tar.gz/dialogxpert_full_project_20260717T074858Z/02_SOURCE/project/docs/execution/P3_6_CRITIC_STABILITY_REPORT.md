# P3.6 Critic Stability Report

Status: **PASS**
Run: `logs/p3_6_critic_audit/20260717T055558Z`
Source commit: `42213a73bf94462e5940f6d70d0d1dbc7a6bf8a0`
tmux: `dx_p36_critic_postreview_20260717T055558Z` (completed)
PID: `830359`

The local Qwen2.5-7B audit used six ESConv train and six valid cases. Each of the
three protocol-specific critic contracts was evaluated in three independently
addressed sampled batches of ten outputs per case: 1,080 critic outputs. A further
36 dialogue calls give 1,116 complete generation records. Exact messages, prompts,
protocol name/hash, seeds, raw outputs, parsed labels, entropy, reward aggregation,
and termination are retained.

| Contract | Protocol | Parse validity | Unique / 10 | Entropy | Stable majority | Termination agreement |
|---|---|---:|---:|---:|---:|---:|
| released | `released_code_compat` | 100.00% | 1.306 | 0.237 | 91.67% | 66.67% |
| Appendix sentence | `extended_prompt_faithful` | 99.17% | 1.861 | 0.561 | 83.33% | 100.00% |
| corrected enum | `corrected_resolved_only` | 97.78% | 1.167 | 0.000 | 91.67% | 91.67% |

The preregistered cross-protocol rule selects the Appendix prompt because validity
and stability exceed 80%, without consulting SR or reward. Runtime protocol
identity still wins: corrected execution retains `critic_compact_enum_v1` and
does not silently import Appendix semantics.

Artifacts: result SHA-256
`ae2085f6dd51bf39a9dd6af298d08eb147c9531889af5cc725706f2be370eb03`;
generation records SHA-256
`5d26831c59667adcb3b2c24c980724bcc5b8d095a179fb6108b5679c42519a59`.

TaskLog includes command, heartbeat, status, environment, empty stderr, and
manifest. It used one remapped A800 and offline local assets only. No test data,
network, API, download, Q training, or push was used.
