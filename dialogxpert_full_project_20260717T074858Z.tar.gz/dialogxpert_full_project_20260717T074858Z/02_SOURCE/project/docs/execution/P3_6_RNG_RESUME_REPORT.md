# P3.6 RNG and Resume Report

Status: **PASS**  
Implementation commits: `ef5910d`, `41f723b`, `9ccad5c`

Generation and action-selection seeds are pure functions of global seed, phase,
episode ID, stable case ID, turn, role, attempt, sequence index, and rollout ID
under `episode-addressable-v1`. Invocation counters remain logging identifiers and
do not determine stochastic output.

`GenerationRecord`, `Transition`, and `EpisodeResult` persist episode/rollout and
protocol identity. Checkpoint v6 persists episode sampler state, next episode ID,
sampling RNG, epsilon schedule, backend seed protocol, target-update count, and
validation schedule.

Fresh execution of the same full episode address produced identical generation
seeds, selected actions, and candidate feature hashes. A dedicated integration
test now executes episode 0, writes checkpoint v6, continues episode 1 without
interruption, restores the checkpoint into fresh model/optimizer/replay objects,
and re-executes episode 1. Prompt hashes, generation seeds and outputs, epsilon
draws, actions, candidate feature hashes, and all Q values are exact. A separate
interleaving test proves that inserting a validation episode does not change the
subsequent train episode. Different episode and phase coordinates produce different
seeds. Old incomplete checkpoint formats fail closed.

The bounded-pilot harness additionally hashes train replay/head/target/optimizer
around fixed validation. Validation generation roots, rollout IDs, case schedule,
and role seeds are shared across A0-A3; every role seed is recomputable from the
frozen root. Baseline validation resets to its valid root and the next train
episode resets to its train root, so invocation order is irrelevant. Phase B is
permitted only from the exact matching episode-20 checkpoint. The final 90-test
offline CPU suite passed.

No external API, download, test split, or remote push was involved.
