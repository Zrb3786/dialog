# P3.5 Live Semantic Smoke Report

Date: 2026-07-17 UTC

## Execution boundary

Local Qwen2.5-7B-Instruct, local frozen BERT, offline Transformers, BF16, and only physical A800 GPU 3 exposed as logical `cuda:0`. The card was shared with a pre-existing process; no process was stopped. Main run used fixed first 5 train and first 5 valid ESConv cases, `corrected_primary`, max turns 3, top-k 4, epsilon 0.5, sampled paper critic selected by calibration, CLS pooling, and two Q updates. The ablation used 1 train + 1 valid case, max turn 1, masked-mean pooling, and one Q update.

Final evidence: `logs/p3_5_q_semantic_smoke/20260717T030230Z/evidence/`.

## Main CLS semantic gates

- Candidate sets: 30; unique feature count: 4/4 for every set.
- Candidate Q variance range: `7.009867658780422e-06` to `0.01719415746629238`; no all-equal set.
- Actions retained under `only_first`: PASS.
- Causal forbidden-key scan: PASS.
- Next-turn timing: PASS.
- Exact prompts/messages and all candidate features/Q/token evidence persisted: PASS.
- Selection: 16 random, 14 argmax.
- Selected actions: Affirmation/Reassurance 9, Restatement/Paraphrasing 9, Reflection 6, Question 3, Suggestions 2, Others 1.
- Q update losses: `0.47953251004219055`, `0.3681798279285431`.
- Fresh-process next update: PASS with byte-identical Q/target hashes and loss.
- Main checkpoint code state: commit `094682ef1bf5ee13e0203aa0aad0bf9c0cb50553`, dirty=false.

## Critic/reward/termination diagnostics

Across 300 sampled critic sequences: `worse=129`, `same=61`, `better=110`, `solved=0`; all parsed. Ten of 30 transition rewards were positive and 12 distinct aggregate reward values occurred, so reward did not collapse to all-worse. Nevertheless, all 10 main episodes ended in `max_turn_failure`, SR was 0, and average episode reward was -1.07 train / -1.02 valid. This smoke establishes signal diversity and software semantics, not effectiveness.

Valid prior generation had one invalid attempt followed by a successful retry: 1/16 = 0.0625 prior parse-failure rate, zero quarantined episodes. Train prior failure rate was 0.

## Masked-mean ablation

Both candidate sets had 4/4 unique features and nonzero Q variance (`4.33e-07` to `5.79e-07`); causal/action/prompt/turn gates and fresh update passed. Both one-turn episodes received all-worse critics. Its checkpoint recorded dirty=true because the main run's fresh verifier generated untracked Python bytecode before the ablation checkpoint; bytecode was removed after completion and no source differed. The primary CLS checkpoint is clean.

The earlier `20260717T025530Z` run is retained as superseded evidence: it exposed the recovered-prior metric numerator bug. Commit `ebcfe5a` fixed the accounting, 45 CPU tests passed, and the final `030230Z` run verified the corrected 0.0625 denominator.

STATUS: P3_5_LIVE_Q_SEMANTIC_SMOKE_PASS
