# P1 Dataset Registry Report

Status: `PASS` for available train/valid registries; `BLOCKED` for ExTES.
Branch/tag: `repro/dialogxpert-corrected-v1` /
`dx-p1-pass-20260716T064517Z`. Registry implementation commits are
`d60e1c3`, `91fdc56`, and `88ab546`; locations/reasons/tests are registered as
`DX-P1-003` through `DX-P1-012` and `DX-P2-009` through `DX-P2-011`.

| Dataset | Train/valid readiness | Corrected behavior |
|---|---|---|
| ESConv | 1040/130 | Full P3 smoke candidate |
| CIMA | 908/113 after quarantining one exact overlap | Loader, state, prompt, action, reward, termination tests only |
| CB | 3290/188 | Loader and price/reward consistency tests only |
| P4G | 866/50 | Registry only; paper reports 817/100 and provenance is unresolved |
| ExTES | BLOCKED | Aggregate may contain sealed test records and is never opened |

All test paths remain sealed strings. No test count, schema, hash, sample, or
content is produced by the corrected registry.

No dataset tmux/PID is active. CIMA, CB, and P4G train/valid command dry-runs
passed; no RL was run. Artifact hashes are recorded in the final execution
report.
