# P4-A Pilot Report

Status: **NOT LAUNCHED — REVIEWER AUTHORIZATION REQUIRED**

No P4-A episode has been executed. The harness exists at commit
`6f2267d55eee6737fdf58c5ed3ca5815e0e4d6e9`, but its CLI requires the literal
marker `P4_A_AUTHORIZED_BY_GATE`; every other value fails before model or dataset
initialization.

`configs/p4_a/registry.json` freezes Phase A (20 train + fixed 20-case post-valid,
plus a non-polluting baseline) and conditional Phase B (resume the exact episode-20
boundary to total 50) for A0 prior-only, A1 released top-4 Q, A2 corrected top-4 Q,
and separately hashed A3 all-eight Q without an LLM prior call. A1/A2 have both
required learning rates, 1e-6 and 1e-4.

The final 90-test offline CPU gate includes 20 harness tests covering config drift,
A0/A3 semantics, actual fixed validation seed roots, train/valid RNG isolation,
validation transition guards, strict solved/runtime-success separation,
all-role/prior parse denominators, critic threshold,
reward/OOM/disk/checkpoint stops, aggregate metrics, exact next-episode resume, and
controlled Phase-A-to-B migration, target Polyak synchronization, and cross-arm
generation-seed equality.

The final gate completed on source commit
`f874604cbc7ad13881b9d4c807288e60736f3b4d` at
`logs/p3_6_cpu_gate/20260717T071009Z`: 90 tests passed in 177.679 seconds and
`status.json` records `COMPLETE`. The complete evidence and hashes are recorded in
`docs/execution/P3_6_FINAL_CPU_GATE_REPORT.md`.

The TaskLog entry point enforces one visible physical GPU remapped to `cuda:0`.
Frozen BERT placement defaults to the same GPU; any CPU fallback would require a
different preregistered config hash. Target synchronization is Polyak tau=0.005
after every Q update, with independent Q-update and target-sync counters.

It checks gates at heartbeat, episode, checkpoint, and
validation boundaries; checkpoints every five episodes; performs a roundtrip
probe; and emits baseline/post validation, both SR/AT definitions, fixed-horizon
and cumulative reward, strategy counts, Q/reward pairs, critic/parse/token metrics,
throughput, and peak GPU memory. The first OOM stops fail-closed rather than
retrying a partially mutated episode. A hard stop writes `STOPPED`, never
`COMPLETE`.

There are no P4-A tmux sessions, PIDs, checkpoints, episode records, or
effectiveness results because authorization has not been issued. No validation
improvement, success-rate, or paper-reproduction claim is made.

Safety: no test content, network/API, 14B download, full training, or push was used.
