# Next Gate Recommendation V4

P4-A remains fail-closed until final adversarial review emits the exact marker
`P4_A_AUTHORIZED_BY_GATE`.

The final offline CPU gate is PASS: 90 tests passed in 177.679 seconds on source
commit `f874604cbc7ad13881b9d4c807288e60736f3b4d`; auditable TaskLog evidence is at
`logs/p3_6_cpu_gate/20260717T071009Z`. This test result is necessary but does not
itself constitute the reviewer marker.

Only after that marker, launch preregistered Phase-A configs through
`scripts/run_p4_a_pilot.py` in observable tmux tasks using local Qwen2.5-7B, local
BERT on the same device by default, ESConv train/valid, offline mode, and exactly
one A800. Do not edit a running config
or use validation to tune and continue the same run.

Phase B is arm-specific. It may resume only a matching episode-20 checkpoint whose
Phase-A gate records 20 train episodes, baseline/post 20-case validation, four
scheduled checkpoints, roundtrip resume PASS, validation isolation PASS,
nonconstant reward, nonzero Q updates where applicable, parse/critic thresholds,
and no hard stop. The standalone `phase_a_gate.json` must pass strict identity
validation before Phase B. It expands to total 50 at the Phase-A epsilon endpoint; it never
restarts from random weights.

A completed pilot would establish bounded learning/runtime behavior only. It
would not authorize 1,000-episode reproduction, test access, 14B, APIs, downloads,
remote push, or publication-level effectiveness claims.
