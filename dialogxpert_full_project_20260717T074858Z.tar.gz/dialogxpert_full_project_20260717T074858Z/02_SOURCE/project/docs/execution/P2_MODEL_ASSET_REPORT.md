# P2 Model Asset Report

- Qwen2.5-7B config/tokenizer: offline PASS; four indexed shards present.
- BERT-base-uncased revision `86b5e0934494bd15c9632b12f734a8a67f723594`:
  offline tokenizer/model forward PASS; 768 hidden size; zero trainable encoder
  parameters.
- Qwen2.5-14B exact asset:
  `Qwen/Qwen2.5-14B-Instruct@cf98f3b3bbb457ad9e2bb7baf9a0125b6b88caa8`,
  public, non-gated, model-card license `apache-2.0` as reported by hf-mirror
  metadata on 2026-07-16.
- Download reserve preflight: approximately 124 GiB free; required policy for a
  31 GiB estimate is approximately 84.1 GiB, so launch is permitted.
- Qwen2.5-14B remains download-only and was not loaded in P0-P3.
- Branch/commit/tag: `repro/dialogxpert-corrected-v1`, `be79cac` plus retry fix
  `812f558`; last passing tag `dx-p1-pass-20260716T064517Z`.
- Change IDs/symbols: `DX-P2-002` through `DX-P2-008` in the registry.
- First launch: PID `528232`, log
  `logs/model_download/20260716T065759Z`, `FAILED` after SSL EOF exposed an
  incomplete-local-directory retry defect.
- Corrected bounded launch: PID `552157`, log
  `logs/model_download/20260716T065911Z`, `FAILED` after three attempts with
  hf-mirror SSL EOF. Four of eight indexed weight shards (about 15 GiB) remain
  in the revision/provider-specific partial directory for safe resumption.
- No tmux session remains active. The final directory was not published and no
  `.complete.json` was written. Runtime-log and asset hashes are recorded in
  the final execution report.
