# P3.5 Critic Calibration Report

Date: 2026-07-17 UTC

Local asset: `/data1/zhangruibo/models/Qwen2.5-7B-Instruct`; offline Transformers, BF16, one logical CUDA device. Fixed sample: first 6 approved train and first 6 approved valid ESConv cases. One generated dialogue turn per case under a maximum-turn cap of 2. No Q training.

| Track | Invocations | Sequences | Valid | Mean unique raw/case | Mean entropy bits | Mean consensus |
|---|---:|---:|---:|---:|---:|---:|
| C0 greedy paper, parser-only | 120 | 120 | 120 | 1.000 | 0.000 | 1.000 |
| C1 sampled paper | 12 | 120 | 120 | 2.083 | 0.567 | 0.808 |
| C2 sampled compact enum | 12 | 120 | 97 | 1.417 | 0.000 | 0.917 |

C0 label counts were `worse=100, better=20`, demonstrating deterministic repetition rather than stochastic self-consistency. C1 counts were `worse=79, better=27, same=14`, with no invalid parses. C2 produced 23 invalid parses and 3 critic-schema failures.

The pre-registered selection rule was: choose sampled paper if C1 parse validity is at least 0.8, otherwise compact enum. It did not consult success rate or reward. C1 therefore supplies the live Q critic.

Exact evidence: `logs/p3_5_critic_calibration/20260717T025300Z/evidence/critic_calibration_result.json` and `generation_records.jsonl` (396 total role records, including all 360 critic sequences).

STATUS: P3_5_CRITIC_STOCHASTIC_CALIBRATION_PASS
