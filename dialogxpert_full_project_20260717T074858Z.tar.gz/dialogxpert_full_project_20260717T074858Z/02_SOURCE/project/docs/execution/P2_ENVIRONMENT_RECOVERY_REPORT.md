# P2 Environment Recovery Report

Status: `PASS`

- Branch: `repro/dialogxpert-corrected-v1`
- P1.5 input tag: `dx-p1_5-pass-20260716T080924Z`
- Recovery tag: `dx-p2-recovery-pass-20260717T011953Z`
- Preserved invalid prefix: `/data1/zhangruibo/conda_envs/dialogxpert_qwen`
- Read-only source prefix: `/data1/zhangruibo/conda_envs/qwen_multiesc_lf`
- New prefix: `/data1/zhangruibo/conda_envs/dialogxpert_qwen_v2`
- Method: formal `conda create --clone`; no manual prefix copy or overlay.
- Clone result: exit 0, 32 Conda packages, 56,971 files.
- Python/pip: 3.11.15 / 26.1.2.
- ABI: prefix-local `libexpat.so.1.12.1`; `pyexpat` reports expat 2.8.1.
- ML stack: torch 2.12.1+cu130, Transformers 5.13.0, datasets 4.0.0,
  sklearn 1.9.0, NLTK 3.9.4.
- CUDA/BF16 query: available/PASS.
- Qwen2.5-7B config/tokenizer offline: PASS, tokenizer size 151665.
- BERT offline CPU forward: PASS, shape `[1, 7, 768]`, trainable parameters 0.
- Package absolute paths: all point into v2, not the source prefix.
- P1.5 suite in v2: 24/24 PASS; registry train/valid dry-run PASS with
  ExTES blocked before open.
- tmux/PID/GPU: none used for recovery.

`conda list --explicit` ultimately passed and produced 32 URLs matching 32
`conda-meta` records. Conda 26.3.2 `env export --from-history` repeatedly
failed on a tzdata explicit-package lookup; stderr/exit code are retained and
the minimal history YAML was reconstructed from the successful clone
transaction. `conda-explicit.txt` is the authoritative exact Conda lock, with
`pip-freeze-all.txt` covering the cloned pip layer.

Change ID: `DX-P2R-001`. Artifact SHA-256 values are listed in the final report.
