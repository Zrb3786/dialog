# P3.5 BERT Pair Encoding Report

Date: 2026-07-17 UTC

## Contract

The frozen local BERT encoder now calls the tokenizer with `(state_texts, action_texts)`, `truncation="only_first"`, and a fixed `max_length`. The action is the protected second segment. Empty/oversized action segments and any failure to retain the complete action token subsequence fail closed.

Every candidate records feature SHA-256, complete active input IDs, input-ID SHA-256, action token IDs, token-type IDs, attention mask, original/encoded/truncated state lengths, action length, truncation policy, and pooling mode. The encoder manifest freezes max length, tokenizer/config hashes, pair policy, pooling, local-only mode, and zero trainable encoder parameters.

Both `cls` (paper-described primary P3.5 smoke) and `masked_mean` (corrected ablation) are implemented.

## CPU evidence

- A state far beyond the length limit with four different actions retained all four action segments: PASS.
- The four active token-ID hashes were distinct: 4/4.
- The four CLS feature hashes had at least two distinct values: PASS.
- Turn 0 versus turn 1 with the same action changed the feature hash: PASS.
- Masked-mean used the same protected pair contract and distinguished two actions: PASS.

## Scripted evidence

Both corrected and prompt-faithful scripted tracks produced 10 candidate sets each. Every set had 4/4 unique feature hashes and nonzero Q variance; no action was truncated.

STATUS: P3_5_BERT_PAIR_ENCODING_PASS
