# P1.5 Runtime Correction Report

Status: `PASS`

- Branch: `repro/dialogxpert-corrected-v1`
- Base: `37ee4ef2ec3fc206bd6aeeb473e44da826ab4682`
- Commits: `e19822f`, `171704a`, `cca730c`, `27594b2` plus the P1.5 test commit.
- Pass tag: `dx-p1_5-pass-20260716T080924Z`
- Change IDs: `DX-P1_5-001` through `DX-P1_5-021`.
- Runtime: `dialogxpert_repro.runtime.run_episode`
- Backends: `ScriptedBackend`, `TransformersLocalBackend`
- Legacy `env.py`: retained for `repository_diagnostic`; never imported by the
  standalone runtime.
- Tests: 24 deterministic CPU tests PASS under offline flags in the untouched
  reference environment.
- Data: train/valid only; ExTES blocked before open; no test access.
- Environment: `/data1/zhangruibo/conda_envs/qwen_multiesc_lf` used read-only
  for P1.5 tests.
- tmux/PID/GPU: not used for P1.5.
- Scripted pre-gate harness: both tracks completed 2 train/3 valid cases, one
  Q update, checkpoint, and identical dual fresh-process next updates.
- Artifact hashes are added to the final execution report.

The corrected call order is causal:

`emotion → exact-k prior → masked Q → system → user → ten critics → consensus
→ reward/termination → nonterminal next emotion/prior → replay`.

Terminal transitions request no next prior. Prompt-faithful retains coupled
emotion/response generation but uses safe loaders, Q/replay, consensus,
checkpoint, and validation-only routing.
