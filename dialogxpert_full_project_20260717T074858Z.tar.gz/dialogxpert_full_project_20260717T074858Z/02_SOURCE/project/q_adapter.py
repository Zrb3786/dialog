"""Compatibility exports for the corrected shared BERT/Q implementation."""

# DX-REPRO CHANGE 2026-07-16T06:28:17Z [DX-P1-013]
# Upstream: 7b35ec95, q_adapter.py:1-65 (QAdapter)
# Reason: upstream duplicated BERT, used unconditional CUDA, and pooled padding.
# Behavior: corrected shared offline BERT encoder and trainable Q MLP.
from dialogxpert_repro.qnet import FrozenBertEncoder, QAdapter, QMLP

__all__ = ["FrozenBertEncoder", "QAdapter", "QMLP"]

