from fastchat.model import load_model, get_conversation_template
from prompt import *
from qwen_prompts import *
from misc import set_random_seed, backup_loading
from dialogxpert_repro.prompts import build_policy_messages, build_roleplay_messages
from dialogxpert_repro.registry import get_dataset
from dialogxpert_repro.prior import parse_prompt_faithful
from dialogxpert_repro.rewards import aggregate_critic_outputs, decide_termination

import torch
import nltk
import re
import numpy as np

class Env(object):

    def __init__(self, args, dataset, mode, env_model = None, env_tokenizer = None):

        # DX-REPRO CHANGE 2026-07-16T06:28:17Z [DX-P1-004]
        # Upstream: 7b35ec95, env.py:14-43 (Env.__init__)
        # Reason: dataset prompts and roles were manually hard-coded downstream.
        # Behavior: registry-selected routing for all tracks.
        self._dataset_spec = get_dataset(args.data_name)

        # Vicuna and LLama check
        llm_players = [args.system, args.user, args.critic]

        self._is_vicuna = 'vicuna' in llm_players
        self._is_llama = 'llama2'in llm_players
        self._gpt_api_key = ''

        # DX-REPRO CHANGE 2026-07-16T06:28:17Z [DX-P1-025]
        # Upstream: 7b35ec95, env.py:16-31 (Env.__init__ model routing)
        # Reason: default Qwen never initialized model/tokenizer; API import was unused.
        # Behavior: local-only Qwen initialization or explicit injected frozen backend.
        self._llm_model = env_model
        self._llm_tokenizer = env_tokenizer
        if self._llm_model is None or self._llm_tokenizer is None:
            if mode != 'train':
                raise RuntimeError("evaluation environments require an injected local model/tokenizer")
            self._llm_model, self._llm_tokenizer = backup_loading(args.model_path)
                

        self._args = args
        self._behavior_track = getattr(args, "behavior_track", "corrected_primary")
        self._dataset = dataset[mode]
        self._mode = mode

        self._max_turn = args.max_turn

        self._conversation = []
        self._user_emotions = []
        self._cur_conv_step = 0
        self._top_k = args.top_k

        # For test dataset
        self._test_num = 0

        self._reward_dict = {
            'esc': {
                'worse': -1.0,
                'same': -0.5,
                'better': 0.5,
                'solved': 1.0
            },

            'cima': {
                'incorrect': -1.0,
                'did not': -0.5,
                'part': 0.5,
                'whole': 1.0,
            },

            'p4g': {
                'refused': -1.0,
                'neutral': -0.5,
                'positive': 0.1,
                'agree': 1.0
            },

            'extes': {
                'worse': -1.0,
                'same': -0.5,
                'solved': 1.0
            }
        }

        self._message_format = {
            'esc': ESConvMessages, 
            'cima': CIMAMessages, 
            'cb': CBMessages
        }

        self._system_role = {
            'esc':'Therapist', 
            'cima': 'Teacher', 
            'cb': 'Buyer',
            'extes': 'Therapist',
            'p4g': 'Persuader'
        }

        self._user_role = {
            'esc':'Patient', 
            'cima': 'Student', 
            'cb': 'Seller',
            'extes': 'Patient',
            'p4g': 'Persuadee'
        }

        self._case = []

        set_random_seed(args.seed)

    def get_llm_model(self):
        return self._llm_model
    
    def get_llm_tokenizer(self):
        return self._llm_tokenizer

    def reset(self):

        self._cur_conv_step = 0
        self._conversation = []
        self._user_emotions = []

        if self._mode == 'train':
            self._case = np.random.choice(self._dataset)
        else:
            self._case = self._dataset[self._test_num]
            self._test_num += 1

        dataset = self._args.data_name

        # P4G
        if dataset == 'p4g':
            # DX-REPRO CHANGE 2026-07-16T06:28:17Z [DX-P1-005]
            # Upstream: 7b35ec95, env.py:109-182 (Env.reset)
            # Reason: reset returned a different list from the internal state for most datasets.
            # Behavior: one shared conversation object for corrected and prompt-faithful tracks.
            self._conversation.extend([
                {
                    "role": "Persuader",
                    "content": self._case['dialog'][0]['text']
                },
                {
                    "role": "Persuadee",
                    "content": self._case['dialog'][1]['text']
                }
            ])

            return self._conversation

        # ExTES
        if dataset == 'extes':
            self._conversation = [
                {
                    "role": "Patient",
                    "content": self._case['description']
                }
            ]
            return self._conversation

        # ESConv
        if dataset == 'esc':

            self._user_emotions.append(self._case['emotion_type'])

            self._conversation = [
                {
                    "role":"Patient", 
                    "content": self._case['situation']
                }
            ]
            return self._conversation

        # CIMA
        if dataset == 'cima':
            self._conversation = [
                {
                    "role":"Teacher", 
                    "content":self._case['dialog'][0]['text']
                }, 
                {
                    "role":"Student", 
                    "content":self._case['dialog'][1]['text']
                }
            ]
            return self._conversation
        
        # CB
        self._conversation = [
            {
                "role":"Buyer", 
                "content":"Hi, how much is the %s?" % self._case['item_name']
            }, 
            {
                "role":"Seller", 
                "content":"Hi, this is a good %s and its price is %s." % (self._case['item_name'], self._case['seller_price'])
            }
        ]
        return self._conversation
    
    def is_llama_vicuna(self):
        return self._is_llama or self._is_vicuna
    
    def get_dataset_size(self):
        return len(self._dataset)
    
    def get_prior_actions_llm(self, state, action_list, options):

        # Load the state -> full conversation
        full_conv = get_full_conversation(state)

        # Choose the action list from LLM
        # DX-REPRO CHANGE 2026-07-16T06:28:17Z [DX-P1-006]
        # Upstream: 7b35ec95, env.py:190-197 (get_prior_actions_llm)
        # Reason: the upstream path routed every dataset through ExTES_prompt.
        # Behavior: registry-routed policy prompt for prompt-faithful diagnostics.
        prompt = build_policy_messages(
            self._dataset_spec, state, self._user_emotions, options, top_k=self._top_k
        )

        # Prepare the input: Text to Token IDs
        formatted_prompt = self._llm_tokenizer.apply_chat_template(
            prompt, 
            tokenize=False, 
            add_generation_prompt=True
        )

        encoded_input = self._llm_tokenizer(formatted_prompt, return_tensors="pt", add_special_tokens=False).to(self._llm_model.device)

        # Get the output
        output_ids = []

        with torch.no_grad():

            output_ids = self._llm_model.generate(
                **encoded_input,
                max_new_tokens=25,

                # Sampling
                temperature = 1.0,
                top_p = 1.0,
                do_sample = True,
                early_stopping=True,
                
                # Output
                return_dict_in_generate = True,
                output_scores = True,
                output_hidden_states = True,

                # Caching
                use_cache=True
            )
        
        # Get the output
        pre_decoded_sequences = self._llm_tokenizer.batch_decode(
            output_ids.sequences
        )[0]

        output = pre_decoded_sequences.split('assistant')[-1]
        # DX-REPRO CHANGE 2026-07-16T06:28:17Z [DX-P1-011]
        # Upstream: 7b35ec95, env.py:231-242 (get_prior_actions_llm parser)
        # Reason: regex accepted duplicates, zero, out-of-range, and non-k outputs.
        # Behavior: prompt-faithful strict exact-k IDs with explicit parse failure.
        parsed_prior = parse_prompt_faithful(output, action_list, top_k=self._top_k)
        action_pairs = list(parsed_prior.actions)

        # Create the state-action pairs
        state_action_pairs = [
            f"Action: {action} for Observation: {full_conv}"
            for action in action_pairs
        ]

        return state_action_pairs, action_pairs
    
    def predict_next_action(self, state, options):

        # Build input
        full_conv = get_full_conversation(state)

        # Load the prompt
        prompt = build_policy_messages(
            self._dataset_spec, state, self._user_emotions, options, top_k=self._top_k
        )

        formatted_prompt = self._llm_tokenizer.apply_chat_template(
            prompt, 
            tokenize=False, 
            add_generation_prompt=True
        )

        input_ids = self._llm_tokenizer(formatted_prompt, return_tensors="pt").input_ids

        # Get the output
        output_ids = []

        with torch.no_grad():

            output_ids = self._llm_model.generate(
                torch.as_tensor(input_ids).cuda(),
                max_new_tokens=100,
                temperature = 1.0,
                do_sample = True,
                top_p=1.0,
                eos_token_id=self._llm_tokenizer.eos_token_id,
            )

        output_ids = output_ids[0][len(input_ids[0]):]

        output = self._llm_tokenizer.decode(
            output_ids, skip_special_tokens=True,
            spaces_between_special_tokens=False
        )

        return output

    def get_response(self, prompt, conv_role="assistant"):

        temperature = 1.0 if self._mode == 'test' else 0.7

        formatted_prompt = self._llm_tokenizer.apply_chat_template(
            prompt, 
            tokenize=False, 
            add_generation_prompt=True
        )

        input_ids = self._llm_tokenizer(formatted_prompt, return_tensors="pt").input_ids

        # Get the output
        output_ids = []

        with torch.no_grad():

            output_ids = self._llm_model.generate(
                torch.as_tensor(input_ids).cuda(),
                max_new_tokens = self._args.max_new_tokens,
                temperature = temperature,
                early_stopping = True,
                do_sample = False
            )

        output_ids = output_ids[0][len(input_ids[0]):]

        output = self._llm_tokenizer.decode(
            output_ids, skip_special_tokens=True,
            spaces_between_special_tokens=False
        )

        return output
    
    def prepare_critic_output(self, conv_role="assistant"):

        # DX-REPRO CHANGE 2026-07-16T06:28:17Z [DX-P1-007]
        # Upstream: 7b35ec95, env.py:324-326 (prepare_critic_output)
        # Reason: critic prompt was hard-coded to ExTES.
        # Behavior: registry-routed critic prompt for prompt-faithful diagnostics.
        prompt = build_roleplay_messages(
            self._dataset_spec, self._case, 'critic', self._conversation, self._user_emotions
        )
        
        formatted_prompt = self._llm_tokenizer.apply_chat_template(
            prompt, 
            tokenize=False, 
            add_generation_prompt=True
        )

        input_ids = self._llm_tokenizer(formatted_prompt, return_tensors="pt").input_ids

        # Get the verdict
        output_ids = []

        with torch.no_grad():
            
            output_ids = self._llm_model.generate(
                torch.as_tensor(input_ids).cuda(),
                max_new_tokens=25,
                temperature = 1.1,
                do_sample = True,
                early_stopping=True,
                num_return_sequences=10,
            )

        # Return!
        outputs = []

        for o in output_ids:
            output_id = o[len(input_ids[0]):]


            output = self._llm_tokenizer.decode(
                output_id, skip_special_tokens=True,
                spaces_between_special_tokens=False
            )

            outputs.append(output)

        return outputs
    
    def calculate_reward(self, outputs, case):

        # DX-REPRO CHANGE 2026-07-16T06:28:17Z [DX-P1-015]
        # Upstream: 7b35ec95, env.py:366-409 (calculate_reward)
        # Reason: substring matching silently discarded invalid critic outputs.
        # Behavior: exact registry enum parsing with explicit invalid-output accounting.
        aggregation = aggregate_critic_outputs(self._dataset_spec, outputs, case)
        self._last_critic_aggregation = aggregation
        return aggregation.aggregate_reward

    def perform_self_play(self, action, conversation):

        # Flow: Prepare input -> Get response -> Process response

        # Self-play role: System -> Patient -> Critic

        # System
        # DX-REPRO CHANGE 2026-07-16T06:28:17Z [DX-P1-008]
        # Upstream: 7b35ec95, env.py:411-443 (perform_self_play)
        # Reason: system/user roles were hard-coded to ExTES.
        # Behavior: registry-routed prompt-faithful coupled roleplay baseline.
        messages = build_roleplay_messages(
            self._dataset_spec, self._case, 'system', conversation, None, action,
            coupled_emotion=True,
        )
        response = self.get_response(messages, conv_role="assistant")

        # Find the emotion and response
        emotion_start = response.find('Emotion:')
        emotion_end = response.find('Response:')
        
        # 8 -> Size of the string 'Emotion: '
        # 9 -> Size of the string 'Response: '
        emotion = response[emotion_start + 8 : emotion_end].strip()
        sys_reply = response[emotion_end + 9 :].strip()
        self._user_emotions.append(emotion.lower())

        response = self.postprocess_response(response,  self._user_role[self._args.data_name])
        self._conversation.append({"role": self._system_role[self._args.data_name], "content":sys_reply})

        # User
        messages = build_roleplay_messages(
            self._dataset_spec, self._case, 'user', self._conversation, self._user_emotions
        )
        response = self.get_response(messages, conv_role="assistant")

        response = self.postprocess_response(response,  self._user_role[self._args.data_name])
        self._conversation.append({"role": self._user_role[self._args.data_name], "content":response})

        # Critic check and reward calculation
        messages = self.prepare_critic_output()
        reward = self.calculate_reward(messages, self._case)

        dataset = self._args.data_name

        # DX-REPRO CHANGE 2026-07-16T06:28:17Z [DX-P1-016]
        # Upstream: 7b35ec95, env.py:445-468 (reward termination)
        # Reason: better was conflated with solved and timeout overwrote final-turn success.
        # Behavior: track-aware success, bool done, and separate terminal reason.
        outcome = decide_termination(
            self._dataset_spec,
            self._last_critic_aggregation.labels,
            turn_index=self._cur_conv_step,
            behavior_track=self._behavior_track,
        )
        done = int(outcome.done)
        self._terminal_reason = outcome.reason

        self._cur_conv_step += 1

        return self._conversation, reward, done
        
    def step(self, action):

        done = 0

        # Flow: Prepare input -> Get response -> Process response

        # User input
        messages = self._message_format[self._args.data_name](self._case, 'user', self._conversation)
        response = self.generate_response(self._args.system, messages, self._system_role[self._args.data_name])
        response = self.postprocess_response(response,  self._user_role[self._args.data_name])
        self._conversation.append({"role": self._user_role[self._args.data_name], "content":response})

        # System input
        messages = self._message_format[self._args.data_name](self._case, 'system', self._conversation, action)
        response = self.generate_response(self._args.system, messages, self._system_role[self._args.data_name])
        response = self.postprocess_response(response,  self._user_role[self._args.data_name])
        self._conversation.append({"role":  self._system_role[self._args.data_name],"content":response})

        # Critic input
        messages = self._message_format[self._args.data_name](self.case, 'critic', self.conversation)
        reward = self.calculate_reward(self._args.critic, messages, self.case)

        dataset = self._args.data_name

        if (dataset == 'esc') and (reward > 0.5):
            done = 1

        if (dataset == 'cima') and (reward == 1):
            done = 1

        if (dataset == 'cb') and (reward >= 0):
            done = 1

        if self._cur_conv_step == (self._max_turn - 1):
            done = -1

        self._cur_conv_step + 1

        return self._conversation, reward, done
    
    def postprocess_response(self, response, role):

        if role in response:
            response = response.split(role)[0].strip()

        sents = nltk.sent_tokenize(response)

        if len(sents) == 1:

            if response[-1] not in ['.','!','?',':']:
                return response + '.'
            
            return response.strip()
        try:

            if sents[-1].strip()[-1] not in ['.','!','?',':']:
                return ' '.join(sents[:-1]).strip()
            else:
                return response.strip()
        except Exception as e:
            return response.strip()
        
    def generate_response(self, model, messages, role):

        temperature = 0 if self._mode == 'test' else 0.7
        
        # Vicuna
        if model == 'vicuna':
            prompt = vicuna_prompt(messages, role)

            input_ids = self._llm_tokenizer([prompt]).input_ids
            max_new_tokens = self._args.max_new_tokens

            output_ids = self._llm_model.generate(
                torch.as_tensor(input_ids).cuda(),
                max_new_tokens=max_new_tokens,
                temperature = temperature,
                early_stopping=True
            )

            output_ids = output_ids[0][len(input_ids[0]):]

            output = self._llm_tokenizer.decode(
                output_ids, skip_special_tokens=True,
                spaces_between_special_tokens=False
            )

            return output

        return output
    
    def compute_reward(self, model, messages, case):

        # Get the reward based on the LLM
        if model == 'vicuna':

            prompt = vicuna_prompt(messages, 'critic')
            input_ids = self.vicuna_tokenizer([prompt]).input_ids
            
            output_ids = self.vicuna_model.generate(
                torch.as_tensor(input_ids).cuda(),
                max_new_tokens=16,
                temperature = 1.1,
                do_sample = True,
                early_stopping=True,
                num_return_sequences=10,
            )

            outputs = []

            for o in output_ids:
                output_id = o[len(input_ids[0]):]
                output = self.vicuna_tokenizer.decode(output_id, skip_special_tokens=True,
                                    spaces_between_special_tokens=False)
                outputs.append(output)

        # Parse based on dataset
        if self._args.data_name in ['esc','cima', 'p4g', 'extes']:

            rewards = []
            
            # Search based on keywords
            for output in outputs:
                
                # Search based on the reward dictionary
                for key in self.reward_dict[self._args.data_name]:

                    if key in output.lower():
                        rewards.append(self.reward_dict[self._args.data_name][key])
                        break
            
            reward = (sum(rewards)/len(rewards)) if len(rewards) != 0 else 0
            return reward

       
        deals = []
        rewards = []

        for output in outputs:

            if 'have not' in output.lower():
                deals.append(-1)

            if 'have reached' in output.lower():
                deals.append(1)
            
            prices = re.findall(r"[-+]?\d*\.?\d+", output.replace(",",""))
            
            if len(prices) > 0:
                deal_price = float(prices[0])
                reward = (deal_price - case['seller_price']) / (case['buyer_price'] - case['seller_price'])
                rewards.append(reward)

        if -1 in deals:
            return reward -0.1

        reward = max(set(rewards), key = rewards.count) if len(rewards) != 0 else 0

        return reward

    
