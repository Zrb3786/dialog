from transformers import BertTokenizer, RobertaTokenizer, BertConfig, RobertaConfig, BertModel, RobertaModel
from tqdm import tqdm
from sklearn.metrics import f1_score, precision_score, recall_score

from transformers import AutoTokenizer, AutoModelForCausalLM

import json
import argparse
import torch
import random
import numpy as np

def soft_update(target, source, tau):

    for target_param, param in zip(target.parameters(), source.parameters()):
        target_param.data.copy_(target_param.data * (1.0 - tau) + (param.data * tau))

def backup_loading(model_name):

    # DX-REPRO CHANGE 2026-07-16T06:28:17Z [DX-P1-021]
    # Upstream: 7b35ec95, misc.py:18-28 (backup_loading)
    # Reason: from_pretrained could silently use Hub fallback and left the LLM in train mode.
    # Behavior: corrected local-only frozen Qwen loading.

    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        device_map="auto",  
        torch_dtype=torch.bfloat16,
        local_files_only=True,
    )
    model.eval()
    model.requires_grad_(False)

    tokenizer = AutoTokenizer.from_pretrained(model_name, local_files_only=True)

    return model, tokenizer

# DX-REPRO CHANGE 2026-07-16T06:28:17Z [DX-P1-029]
# Upstream: 7b35ec95, misc.py:30-42 (get_transformers)
# Reason: the entry point loaded an unused encoder and could fall back to Hub.
# Behavior: removed from the corrected execution path; Q encoding is owned by qnet.py.

def get_args_sft():
    parser = argparse.ArgumentParser()

    ## Required parameters
    parser.add_argument('--data_name', default='esc', type=str,
                        help="dataset name")
    parser.add_argument('--model_name', default='bert', type=str,
                        help="model name")
    parser.add_argument("--model_name_or_path", default='bert-large-uncased',
                        type=str, help="model name or path")
    parser.add_argument("--output_dir", default='sft_models', type=str,
                        help="The output directory where the model predictions and checkpoints will be written.")
    parser.add_argument("--data_dir", default='data', type=str,
                        help="The data directory.")
    parser.add_argument("--cache_dir", default='/storage_fast/ydeng/plm', type=str,
                        help="The cache directory.")

    ## Other parameters
    parser.add_argument("--do_train", action='store_true',
                        help="Whether to run training.")
    parser.add_argument("--do_eval", action='store_true',
                        help="Whether to run eval.")
    parser.add_argument('--overwrite_output_dir', action='store_true',
                        help="Overwrite the content of the output directory")
    parser.add_argument('--overwrite_cache', action='store_true',
                        help="Overwrite the cached training and evaluation sets")
    parser.add_argument("--do_lower_case", action='store_false',
                        help="Set this flag if you are using an uncased model.")
    parser.add_argument("--max_seq_length", default=512, type=int,
                        help="The maximum total input sequence length after tokenization. Sequences longer "
                             "than this will be truncated, sequences shorter will be padded.")
    parser.add_argument('--seed', type=int, default=42,
                        help="random seed for initialization")
    parser.add_argument('--gpu', default="0 1", type=str,
                        help="Use CUDA on the device.")
    parser.add_argument("--per_gpu_train_batch_size", default=2, type=int,
                        help="Batch size per GPU/CPU for training.")
    parser.add_argument("--per_gpu_eval_batch_size", default=1, type=int,
                        help="Batch size per GPU/CPU for evaluation.")
    parser.add_argument("--num_train_epochs", default=10, type=float,
                        help="Total number of training epochs to perform.")
    parser.add_argument('--gradient_accumulation_steps', type=int, default=1,
                        help="Number of updates steps to accumulate before performing a backward/update pass.")
    parser.add_argument("--warmup_steps", default=400, type=int,
                        help="Linear warmup over warmup_steps.")
    
    # Changed from "6e-6" (Default) to "1e-5"
    parser.add_argument("--learning_rate", default=1e-5, type=float,
                        help="The initial learning rate for Adam.")
    
    parser.add_argument("--weight_decay", default=0.01, type=float,
                        help="Weight decay if we apply some.")
    parser.add_argument("--adam_epsilon", default=1e-8, type=float,
                        help="Epsilon for Adam optimizer.")
    parser.add_argument("--max_grad_norm", default=1.0, type=float,
                        help="Max gradient norm.")
    parser.add_argument("--local_rank", default=-1, type=int,
                        help="DDP requirement.")

    return parser.parse_args()

def get_args_train():

    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', '-seed', type=int, default=1, help='random seed.')
    parser.add_argument('--num_gpus', type=int, default=4, help='number of gpus.')
    parser.add_argument('--epochs', '-me', type=int, default=50000, help='the number of RL train epoch')
    parser.add_argument('--gamma', type=float, default=0.999, help='reward discount factor.')
    parser.add_argument('--lr', type=float, default=1e-3, help='learning rate.')

    parser.add_argument('--data_name', type=str, default='extes', choices=['esc','cima','cb', 'p4g', 'extes'],
                        help='One of {esc, cima, cb}.')
    parser.add_argument('--system', type=str, default='Qwen2.5-14B', choices=['vicuna','chatgpt','llama2'],
                        help='One of {vicuna, chatgpt, llama2}.')
    parser.add_argument('--user', type=str, default='Qwen2.5-14B', choices=['vicuna','chatgpt','llama2'],
                        help='One of {vicuna, chatgpt, llama2}.')
    parser.add_argument('--critic', type=str, default='Qwen2.5-14B', choices=['vicuna','chatgpt','llama2'],
                        help='One of {vicuna, chatgpt, llama2}.')
    parser.add_argument('--max_turn', type=int, default=8, help='max conversation turn')
    parser.add_argument('--mode', type=str, default='train', help='the mode in [train, test]')
    parser.add_argument('--load_rl_epoch', type=int, default=0, help='load agent from epoch')


    parser.add_argument("--epsilon", type = float, default = 0.5, help="The balance of exploration or exploitation")
    parser.add_argument("--max_new_tokens", type=int, default=200)
    parser.add_argument("--max_seq_length", default=512, type=int,
                        help="The maximum total input sequence length after tokenization. Sequences longer "
                             "than this will be truncated, sequences shorter will be padded.")
    parser.add_argument("--debug", action="store_true")
    parser.add_argument("--model_path", type=str, default="Qwen2.5-14B")
    parser.add_argument("--model_name", type=str, default="roberta")
    parser.add_argument("--model_name_or_path", default='roberta-large', type=str, help="model name or path")

    parser.add_argument("--do_lower_case", action='store_false', help="Set this flag if you are using an uncased model.")

    parser.add_argument('--max_steps', type=int, default=1000, help='max training steps')
    parser.add_argument('--top_k', type=int, default=4, help='Top probabilities')
    parser.add_argument('--sample_times', type=int, default=2, help='the epoch of sampling')
    parser.add_argument('--eval_num', type=int, default=1, help='the number of steps to evaluate RL model and metric')
    parser.add_argument('--save_num', type=int, default=1, help='the number of steps to save RL model and metric')
    
    parser.add_argument("--do_train", action='store_true', help="Whether to run training.")
    parser.add_argument("--do_eval", action='store_true', help="Whether to run eval.")

    return parser

def set_random_seed(seed):
    
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

def device_setup(args):
    
    use_cuda = torch.cuda.is_available()

    if use_cuda:
        torch.cuda.manual_seed(42)
        torch.backends.cudnn.deterministic = True
    
    devices_id = [int(device_id) for device_id in args.gpu.split()]

    device = (
        torch.device("cuda:{}".format(str(devices_id[0])))
        if use_cuda
        else torch.device("cpu")
    )

    return device, devices_id

def load_p4g(split):

    # DX-REPRO CHANGE 2026-07-16T06:28:17Z [DX-P1-022]
    # Upstream: 7b35ec95, misc.py:177-186 (load_p4g)
    # Reason: upstream loaded train, dev, and sealed test together.
    # Behavior: explicit single-split safe registry loader.
    from dialogxpert_repro.registry import load_split
    return load_split("p4g", split)

def load_extes(split):

    # DX-REPRO CHANGE 2026-07-16T06:28:17Z [DX-P1-023]
    # Upstream: 7b35ec95, misc.py:188-206 (load_extes)
    # Reason: aggregate shuffle occurred before seeding and could include sealed test.
    # Behavior: explicit registry block until a train/valid-only artifact exists.
    from dialogxpert_repro.registry import load_split
    return load_split("extes", split)

def load_dataset(data_name, split):

    # DX-REPRO CHANGE 2026-07-16T06:28:17Z [DX-P1-024]
    # Upstream: 7b35ec95, misc.py:208-217 (load_dataset)
    # Reason: upstream used eval and preloaded sealed test.
    # Behavior: explicit train/valid registry loader using ast.literal_eval.
    from dialogxpert_repro.registry import load_split
    return load_split(data_name, split)
