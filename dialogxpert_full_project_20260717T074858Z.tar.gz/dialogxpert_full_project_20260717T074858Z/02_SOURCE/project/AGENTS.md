# DialogXpert Corrected Reproduction Instructions

This branch is a local, research-only reproduction workspace based on upstream
commit `7b35ec95ceaad5afeda85438c89ed67b8750625d`.

## Active execution boundary

- P0-P3 may modify this branch, create the dedicated environment, prepare model
  assets, and run the explicitly bounded ESConv smoke.
- Never open, parse, hash, count, grep, sample, copy, or display test-split
  contents. Test paths may exist only as sealed metadata.
- Development loaders accept only explicit `train`, `valid`, or `dev` splits.
- Do not run the upstream `train_model.py` path until it has been replaced by a
  safe entry point that cannot preload or evaluate test.
- Do not call external inference APIs, push to a remote, run full training, or
  use more than one GPU for P3.
- ExTES remains blocked until a train/valid-only artifact is independently
  supplied and frozen.

## Change governance

- Existing upstream logic changes require a `DX-REPRO CHANGE` annotation with a
  unique ID, upstream location, reason, and behavior track.
- New Python modules require a source/purpose/timestamp module docstring.
- Register every logical change in `docs/change_registry.tsv`.
- Keep `repository_diagnostic`, `prompt_faithful`, `official_formal`, and
  `corrected_primary` behavior and outputs separate.
- Commit by gate using the prescribed message body and keep rollback through
  the `upstream-dialogxpert-7b35ec95` tag.

## Validation

- CPU tests and train/valid registry dry-runs must pass before model smoke.
- Offline model execution requires `HF_HUB_OFFLINE=1` and
  `TRANSFORMERS_OFFLINE=1`.
- Background jobs must follow `docs/contracts/LOGGING_AND_TMUX.md`.

