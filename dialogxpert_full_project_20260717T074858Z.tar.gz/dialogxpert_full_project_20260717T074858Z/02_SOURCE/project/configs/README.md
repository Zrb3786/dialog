# Configurations

All runtime configurations are immutable YAML files that include a behavior
track, explicit dataset split, asset paths/revisions, seed, and output root.
P0-P3 configurations must not contain or resolve test paths.

