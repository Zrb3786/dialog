"""Deterministic CPU tests for DialogXpert P1.5 corrected runtime.

Source: P1.5 external review findings and sealed-test execution policy.
Purpose: gate environment recovery on consensus, runtime, resume, and safety.
Created: 2026-07-16T07:53:00Z.
"""

from __future__ import annotations

import dataclasses
import copy
import inspect
import math
import random
import re
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import torch

from dialogxpert_repro.backend import (
    GenerationRecord,
    ScriptedBackend,
    default_role_generation_configs,
)
from dialogxpert_repro.checkpoint import (
    checkpoint_sha_path,
    load_checkpoint,
    save_checkpoint,
    sha256_file,
)
from dialogxpert_repro.episode import EpisodeConfig
from dialogxpert_repro.metrics import RunMetrics
from dialogxpert_repro.parsers import (
    StructuredOutputError,
    parse_coupled_emotion_response,
    parse_emotion_json,
)
from dialogxpert_repro.prior import (
    ActionPriorParseError,
    FormalCandidate,
    parse_prompt_faithful,
    project_official_formal,
)
from dialogxpert_repro.prompts import build_roleplay_messages, render_case_context
from dialogxpert_repro.qnet import FrozenBertEncoder, QMLP, masked_mean_pool
from dialogxpert_repro.registry import DATASETS, DatasetBlockedError, get_dataset, load_split
from dialogxpert_repro.rewards import (
    CriticSchemaFailure,
    aggregate_critic_outputs,
    decide_termination,
)
from dialogxpert_repro.rl import ReplayBuffer, bellman_target, masked_max, train_qnetwork
from dialogxpert_repro.runtime import DeterministicHashEncoder, run_episode
from dialogxpert_repro.state import initialize_state
from dialogxpert_repro.views import audience_case_view, build_planner_state_view
from dialogxpert_repro.protocols import PROTOCOLS
from dialogxpert_repro.safety import SealedTestAccessError, assert_safe_data_path
from dialogxpert_repro.task_logging import TaskLog


class SafetyAndRegistryTests(unittest.TestCase):
    def test_test_split_rejected_before_open(self):
        with mock.patch.object(Path, "open", side_effect=AssertionError("open called")):
            with self.assertRaises(SealedTestAccessError):
                load_split("esconv", "test")

    def test_test_path_rejected_before_resolve(self):
        with mock.patch.object(Path, "resolve", side_effect=AssertionError("resolve called")):
            with self.assertRaises(SealedTestAccessError):
                assert_safe_data_path("data/esc-test.txt", ".")

    def test_extes_blocked_before_open(self):
        with mock.patch.object(Path, "open", side_effect=AssertionError("open called")):
            with self.assertRaises(DatasetBlockedError):
                load_split("extes", "train")

    def test_train_valid_counts_and_metadata(self):
        expected = {
            ("esconv", "train"): 1040,
            ("esconv", "valid"): 130,
            ("cima", "train"): 908,
            ("cima", "valid"): 113,
            ("cb", "train"): 3290,
            ("cb", "valid"): 188,
            ("p4g", "train"): 866,
            ("p4g", "valid"): 50,
        }
        for key, count in expected.items():
            records = load_split(*key)
            self.assertEqual(len(records), count, key)
            self.assertEqual(records[0]["_dx_behavior_track"], "corrected_primary")
            self.assertEqual(records[0]["_dx_schema_version"], 3)
        self.assertFalse(get_dataset("cb").collaborative)

    def test_explicit_index_zero_is_stable(self):
        original = DATASETS["p4g"]
        DATASETS["p4g"] = dataclasses.replace(
            original,
            train_path="data/synthetic-train.json",
            loader=lambda path: [{"index": 0, "dialog": []}],
        )
        try:
            self.assertEqual(load_split("p4g", "train")[0]["_dx_case_id"], "p4g:train:0")
        finally:
            DATASETS["p4g"] = original


class CriticConsensusTests(unittest.TestCase):
    def setUp(self):
        self.spec = get_dataset("esconv")

    def aggregate(self, labels):
        return aggregate_critic_outputs(self.spec, labels, {})

    def test_one_solved_does_not_succeed(self):
        aggregation = self.aggregate(["solved"] + ["same"] * 9)
        outcome = decide_termination(
            self.spec, aggregation, turn_index=0, behavior_track="corrected_primary"
        )
        self.assertEqual(aggregation.majority_label, "same")
        self.assertFalse(outcome.done)

    def test_six_solved_succeeds_and_final_turn_wins(self):
        aggregation = self.aggregate(["solved"] * 6 + ["same"] * 4)
        outcome = decide_termination(
            self.spec,
            aggregation,
            turn_index=7,
            behavior_track="corrected_primary",
        )
        self.assertTrue(outcome.success)
        self.assertEqual(outcome.reason, "success")

    def test_tie_is_conservative_and_better_nonterminal(self):
        tie = self.aggregate(["solved"] * 5 + ["same"] * 5)
        self.assertEqual(tie.majority_label, "same")
        better = self.aggregate(["better"] * 6 + ["same"] * 4)
        self.assertFalse(
            decide_termination(
                self.spec, better, turn_index=0, behavior_track="corrected_primary"
            ).done
        )

    def test_min_valid_failure(self):
        with self.assertRaises(CriticSchemaFailure) as caught:
            self.aggregate(["same"] * 7 + ["invalid"] * 3)
        self.assertEqual(caught.exception.aggregation.requested_count, 10)
        self.assertEqual(caught.exception.aggregation.valid_count, 7)
        self.assertEqual(caught.exception.aggregation.invalid_count, 3)

    def test_cb_majority_and_median(self):
        aggregation = aggregate_critic_outputs(
            get_dataset("cb"),
            ["deal:10", "deal:12", "deal:14", "deal:16", "deal:18", "deal:20"]
            + ["no_deal"] * 4,
            {"seller_price": 10, "buyer_price": 20},
        )
        self.assertEqual(aggregation.majority_label, "deal")
        self.assertEqual(aggregation.deal_price_median, 15.0)
        self.assertTrue(
            decide_termination(
                get_dataset("cb"),
                aggregation,
                turn_index=0,
                behavior_track="corrected_primary",
            ).success
        )


class PriorAndPromptTests(unittest.TestCase):
    def test_prompt_parser_edges(self):
        actions = ["a", "b", "c", "d"]
        result = parse_prompt_faithful("1,4,2", actions, top_k=3)
        self.assertEqual(result.actions, ("a", "d", "b"))
        self.assertIsNone(result.probabilities)
        for value in ("", "1,2", "1,1,2", "0,1,2", "-1,2,3", "1,2,9", "x1,2,3"):
            with self.assertRaises(ActionPriorParseError, msg=value):
                parse_prompt_faithful(value, actions, top_k=3)

    def test_formal_probability_contract_and_no_id_zero(self):
        result = project_official_formal(
            [
                FormalCandidate("Question", -0.1),
                FormalCandidate("ask", -0.2),
                FormalCandidate("unknown continuation", -0.3),
            ],
            ["Question", "Other", "Fallback"],
            top_k=2,
            synonyms={"ask": "Question"},
            fallback_action="Other",
        )
        self.assertTrue(math.isclose(sum(result.matched_conditional_probabilities.values()), 1.0))
        self.assertTrue(
            math.isclose(
                sum(result.absolute_action_probabilities.values()) + result.unmatched_mass,
                1.0,
            )
        )
        self.assertTrue(math.isclose(sum(result.probabilities or ()), 1.0))
        self.assertTrue(all(action_id >= 1 for action_id in result.action_ids))

    def test_formal_unmatched_and_ambiguity_are_explicit(self):
        result = project_official_formal(
            [
                FormalCandidate("Question and Other", -0.1),
                FormalCandidate("Question", -0.2),
                FormalCandidate("Other", -0.3),
            ],
            ["Question", "Other"],
            top_k=2,
            fallback_action=None,
        )
        self.assertGreater(result.unmatched_mass, 0.0)
        self.assertIn("ambiguous:Question and Other", result.projection_failures)

    def test_dataset_specific_prompt_snapshots(self):
        for name in ("esconv", "cima", "cb", "p4g"):
            spec = get_dataset(name)
            case = load_split(name, "train")[0]
            context = render_case_context(spec, case, audience="system")
            critic = build_roleplay_messages(
                spec,
                case,
                "critic",
                [{"role": spec.user_role, "content": "hello"}],
            )
            if name == "esconv":
                self.assertIn("Emotion type:", context)
                self.assertIn("Situation:", context)
            elif name == "cima":
                self.assertIn(case["sentence"], context)
                self.assertNotIn(case["target"], context)
                self.assertIn(case["target"], "\n".join(item["content"] for item in critic))
            elif name == "cb":
                self.assertIn(str(case["buyer_price"]), context)
                self.assertNotIn(f"Seller desired/list price: {case['seller_price']}", context)
                self.assertIn(case["item_name"], context)
            elif name == "p4g":
                self.assertIn("Save the Children", context)
        with self.assertRaises(DatasetBlockedError):
            render_case_context(
                get_dataset("extes"),
                {"emotion_type": "unknown", "problem_type": "unknown", "situation": "schema only"},
                audience="system",
            )


class ParserAndRuntimeTests(unittest.TestCase):
    def test_strict_parsers(self):
        self.assertEqual(
            parse_emotion_json('{"raw":"Worried","normalized":"worry"}')["normalized"],
            "worry",
        )
        emotion, response = parse_coupled_emotion_response(
            "Emotion: worried\nResponse: I understand."
        )
        self.assertEqual(emotion["normalized"], "worried")
        self.assertEqual(response, "I understand.")
        for raw in (
            "Response: x\nEmotion: y",
            "Emotion: x\nEmotion: y\nResponse: z",
            "Emotion:\nResponse: z",
            '{"raw":"x","normalized":"y","extra":1}',
        ):
            with self.assertRaises(StructuredOutputError, msg=raw):
                if raw.startswith("{"):
                    parse_emotion_json(raw)
                else:
                    parse_coupled_emotion_response(raw)

    def test_blank_line_quarantine_regression_three_records(self):
        raw = (
            "Emotion: Understanding\n\nResponse: It sounds really challenging to feel "
            "overwhelmed by the increased workload and the shift in teaching methods. "
            "Can you share more about how these changes affected your confidence and motivation?"
        )
        for old_record in (raw, raw, raw):
            emotion, response = parse_coupled_emotion_response(old_record)
            self.assertEqual(emotion["normalized"], "understanding")
            self.assertTrue(response.startswith("It sounds"))

    def test_coupled_parser_rejects_extra_section(self):
        with self.assertRaises(StructuredOutputError):
            parse_coupled_emotion_response(
                "Emotion: calm\n\nResponse: okay\nReason: hidden explanation"
            )

    def _episode(self, critic_batches=None, track="corrected_primary"):
        spec = get_dataset("esconv")
        case = load_split("esconv", "train")[0]
        backend = ScriptedBackend(critic_batches=critic_batches)
        encoder = DeterministicHashEncoder(32)
        torch.manual_seed(7)
        online = QMLP(32)
        replay = ReplayBuffer(32, seed=7)
        metrics = RunMetrics(track, "esconv", "train", 7)
        result = run_episode(
            spec=spec,
            case=case,
            split="train",
            backend=backend,
            encoder=encoder,
            online_head=online,
            replay=replay,
            config=EpisodeConfig(
                behavior_track=track,
                protocol_name=(
                    "extended_prompt_faithful"
                    if track == "prompt_faithful" else "corrected_resolved_only"
                ),
                critic_prompt_variant=(
                    "critic_appendix_full_sentence_v1"
                    if track == "prompt_faithful" else "critic_compact_enum_v1"
                ),
            ),
            metrics=metrics,
        )
        return result, backend, replay, metrics, online, encoder, spec

    def test_corrected_call_order_and_transition_contract(self):
        result, backend, replay, metrics, _, _, spec = self._episode()
        self.assertEqual(backend.call_order[:2], ["emotion", "prior"])
        self.assertTrue(result.completed)
        self.assertEqual(len(replay), 2)
        transition = result.transitions[0]
        self.assertEqual(transition.behavior_track, "corrected_primary")
        self.assertEqual(transition.dataset, "esconv")
        self.assertEqual(transition.split, "train")
        self.assertEqual(len(transition.candidate_actions), 4)
        self.assertEqual(len(transition.action_texts), 4)
        self.assertEqual(len(set(transition.candidate_feature_hashes)), 4)
        self.assertEqual(transition.action_registry_hash, spec.action_registry_hash)
        self.assertIn("label_counts", transition.reward_aggregation)
        self.assertEqual(metrics.generate_invocations, len(backend.records))

    def test_failed_critic_batch_is_in_validity_denominator(self):
        result, _, _, metrics, _, _, _ = self._episode(
            [["same"] * 7 + ["invalid"] * 3]
        )
        self.assertTrue(result.quarantined)
        summary = metrics.summary()
        self.assertEqual(summary["critic_requested"], 10)
        self.assertEqual(summary["critic_valid"], 7)
        self.assertEqual(summary["critic_invalid"], 3)
        self.assertEqual(summary["critic_validity"], 0.7)

    def test_emotion_oov_rate_has_versioned_denominator(self):
        metrics = RunMetrics("corrected_primary", "esconv", "valid", 7)
        metrics.emotion_observations = 4
        metrics.emotion_oov = 1
        summary = metrics.summary()
        self.assertEqual(summary["emotion_oov_rate"], 0.25)
        self.assertEqual(summary["emotion_normalization_version"], "emotion-alias-v2")
        self.assertEqual(len(summary["emotion_normalization_sha256"]), 64)

    def test_next_turn_index_and_state_continuity(self):
        result, _, _, _, _, _, _ = self._episode()
        first, second = result.transitions
        self.assertEqual(first.next_planner_state_view["turn_index"], 1)
        self.assertEqual(second.planner_state_view, first.next_planner_state_view)
        self.assertEqual(second.state_text, first.next_state_text)

    def test_transition_excludes_privileged_q_fields(self):
        result, _, _, _, _, _, _ = self._episode()
        text = result.transitions[0].state_text
        for forbidden in ('"dialog"', '"strategy"', '"last_reward"', '"terminal_reason"', '"_dx_'):
            self.assertNotIn(forbidden, text)
        self.assertNotIn('"emotion_type"', text)

    def test_generation_records_persist_exact_prompts(self):
        _, backend, _, _, _, _, _ = self._episode([['solved'] * 10])
        self.assertTrue(backend.records)
        for record in backend.records:
            self.assertTrue(record.messages)
            self.assertEqual(len(record.prompt_sha256), 64)
            self.assertEqual(record.case_id, backend._episode_context["case_id"])
            self.assertIn("max_new_tokens", record.generation_config)

    def test_terminal_avoids_next_prior(self):
        result, backend, _, _, _, _, _ = self._episode([["solved"] * 10])
        self.assertTrue(result.success)
        self.assertEqual(backend.call_order.count("prior"), 1)
        self.assertEqual(result.transitions[0].next_candidate_actions, ())
        self.assertEqual(result.transitions[0].next_features.shape[0], 0)

    def test_prompt_faithful_keeps_coupled_generation(self):
        result, backend, _, _, _, _, _ = self._episode(track="prompt_faithful")
        self.assertTrue(result.completed)
        self.assertEqual(backend.call_order[0], "prior")
        self.assertNotEqual(backend.call_order[0], "emotion")
        self.assertTrue(result.transitions[0].emotion_snapshot == ())
        self.assertTrue(all(
            record.protocol_name == "extended_prompt_faithful"
            and record.protocol_hash == PROTOCOLS["extended_prompt_faithful"].sha256
            for record in backend.records
        ))
        prior = next(record for record in backend.records if record.role == "prior")
        self.assertEqual(prior.generation_config["top_p"], 1.0)
        self.assertIn("specialist in policy-planning for emotional support",
                      prior.canonical_prompt)
        system = next(record for record in backend.records if record.role == "system")
        self.assertIn("infer the patient's emotional state in one word",
                      system.canonical_prompt)

    def test_released_protocol_is_coupled_and_better_can_terminate(self):
        spec = get_dataset("esconv")
        case = load_split("esconv", "train")[0]
        backend = ScriptedBackend(critic_batches=[["better"] * 10])
        replay = ReplayBuffer(16, seed=7)
        result = run_episode(
            spec=spec, case=case, split="train", backend=backend,
            encoder=DeterministicHashEncoder(32), online_head=QMLP(32),
            replay=replay,
            config=EpisodeConfig(
                behavior_track="repository_diagnostic",
                protocol_name="released_code_compat",
                critic_prompt_variant="critic_released_code_v1",
            ),
        )
        self.assertTrue(result.success)
        self.assertEqual(backend.call_order[0], "prior")
        system_record = next(record for record in backend.records if record.role == "system")
        self.assertIn("Emotion:", system_record.raw_output)
        self.assertEqual(result.protocol_hash, PROTOCOLS["released_code_compat"].sha256)

    def test_no_legacy_env_or_network_dependency(self):
        import dialogxpert_repro.backend as backend_module
        import dialogxpert_repro.runtime as runtime_module

        source = inspect.getsource(runtime_module) + inspect.getsource(backend_module)
        self.assertIsNone(re.search(r"(?m)^\s*(?:from|import)\s+env\b", source))
        self.assertIsNone(re.search(r"(?m)^\s*(?:from|import)\s+fastchat\b", source))
        self.assertNotIn("snapshot_download", source)
        self.assertNotIn(".cuda()", source)


class CausalViewAndEncodingTests(unittest.TestCase):
    def test_future_gold_mutation_is_byte_invariant(self):
        spec = get_dataset("esconv")
        case = load_split("esconv", "train")[0]
        changed = copy.deepcopy(case)
        changed["dialog"] = [{"text": "FUTURE_SENTINEL", "strategy": "FUTURE"}]
        state_a = initialize_state(spec, case)
        state_b = initialize_state(spec, changed)
        text_a = build_planner_state_view(spec, case, state_a).canonical_text()
        text_b = build_planner_state_view(spec, changed, state_b).canonical_text()
        self.assertEqual(text_a.encode(), text_b.encode())
        encoder = DeterministicHashEncoder(16)
        self.assertTrue(torch.equal(
            encoder.encode_pairs([text_a], ["Question"]).features,
            encoder.encode_pairs([text_b], ["Question"]).features,
        ))

    def test_esconv_runs_without_raw_dialog(self):
        spec = get_dataset("esconv")
        case = dict(load_split("esconv", "train")[0])
        case.pop("dialog", None)
        state = initialize_state(spec, case)
        self.assertNotIn("dialog", build_planner_state_view(spec, case, state).as_dict())

    def test_cima_audience_target_is_critic_only(self):
        spec = get_dataset("cima")
        case = load_split("cima", "train")[0]
        for role in ("planner", "policy", "system", "user", "emotion"):
            self.assertNotIn("target", audience_case_view(spec, case, audience=role))
        self.assertEqual(audience_case_view(spec, case, audience="critic")["target"], case["target"])

    def test_cb_audience_targets_are_role_scoped(self):
        spec = get_dataset("cb")
        case = load_split("cb", "train")[0]
        planner = audience_case_view(spec, case, audience="planner")
        seller = audience_case_view(spec, case, audience="user")
        critic = audience_case_view(spec, case, audience="critic")
        self.assertIn("buyer_price", planner)
        self.assertNotIn("seller_price", planner)
        self.assertIn("seller_price", seller)
        self.assertNotIn("buyer_price", seller)
        self.assertTrue({"buyer_price", "seller_price"}.issubset(critic))

    def test_p4g_hidden_case_fields_are_empty(self):
        spec = get_dataset("p4g")
        case = load_split("p4g", "valid")[0]
        self.assertEqual(audience_case_view(spec, case, audience="planner"), {})

    def test_hash_encoder_distinguishes_four_actions(self):
        encoded = DeterministicHashEncoder(32).encode_pairs(
            ["same causal state"] * 4,
            ["Question", "Information", "Reflection", "Suggestion"],
        )
        self.assertEqual(len(set(encoded.feature_hashes)), 4)
        self.assertTrue(all(stat["action_preserved"] for stat in encoded.token_stats))

    def test_role_specific_generation_defaults(self):
        configs = default_role_generation_configs()
        self.assertFalse(configs["emotion"].do_sample)
        self.assertTrue(configs["prior"].do_sample)
        self.assertTrue(configs["critic"].do_sample)
        self.assertEqual(configs["critic"].num_return_sequences, 10)
        self.assertEqual(configs["system"].max_new_tokens, 100)

    def test_unique_quarantine_case_ids(self):
        metrics = RunMetrics("prompt_faithful", "esconv", "valid", 7)
        metrics.quarantined_case_ids.extend(["a", "a", "b"])
        self.assertEqual(metrics.summary()["quarantined_cases"], 2)


class BertPairEncodingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.encoder = FrozenBertEncoder(
            "/data1/zhangruibo/models/hf_cache/git_lfs_tmp_20260708_164346/bert-base-uncased",
            device="cpu",
            pooling="cls",
            max_length=64,
        )

    def test_only_first_retains_actions_and_distinguishes_token_ids(self):
        state = "very long causal state " * 300
        result = self.encoder.encode_pairs(
            [state] * 4,
            ["Question", "Information", "Reflection of feelings", "Providing Suggestions"],
        )
        self.assertTrue(all(stat["action_preserved"] for stat in result.token_stats))
        self.assertTrue(all(stat["truncated_state_tokens"] > 0 for stat in result.token_stats))
        self.assertEqual(len({stat["input_ids_sha256"] for stat in result.token_stats}), 4)
        self.assertGreaterEqual(len(set(result.feature_hashes)), 2)

    def test_turn_change_changes_pair_feature(self):
        result = self.encoder.encode_pairs(
            ['{"turn_index":0,"history":"hello"}', '{"turn_index":1,"history":"hello there"}'],
            ["Question", "Question"],
        )
        self.assertNotEqual(result.feature_hashes[0], result.feature_hashes[1])

    def test_masked_mean_ablation_uses_same_pair_contract(self):
        original = self.encoder.pooling
        self.encoder.pooling = "masked_mean"
        try:
            result = self.encoder.encode_pairs(["state"] * 2, ["Question", "Information"])
        finally:
            self.encoder.pooling = original
        self.assertEqual(len(set(result.feature_hashes)), 2)
        self.assertTrue(all(stat["pooling"] == "masked_mean" for stat in result.token_stats))


class RLMetricCheckpointLoggingTests(unittest.TestCase):
    def test_mask_pool_bellman_and_terminal_empty_next(self):
        hidden = torch.tensor([[[1.0, 1.0], [100.0, 100.0], [3.0, 3.0]]])
        pooled = masked_mean_pool(hidden, torch.tensor([[1, 0, 1]]))
        self.assertTrue(torch.equal(pooled, torch.tensor([[2.0, 2.0]])))
        values = torch.tensor([[1.0, 99.0], [2.0, 3.0]])
        mask = torch.tensor([[True, False], [False, False]])
        target = bellman_target(
            torch.tensor([1.0, 1.0]),
            torch.tensor([False, True]),
            values,
            mask,
            gamma=0.999,
        )
        self.assertTrue(torch.allclose(target, torch.tensor([1.999, 1.0])))
        self.assertEqual(masked_max(values[:1], mask[:1]).tolist(), [1.0])

    def test_replay_sampling_contract(self):
        result, _, replay, _, _, _, _ = ParserAndRuntimeTests()._episode()
        self.assertEqual(len(result.transitions), 2)
        with self.assertRaises(ValueError):
            replay.sample(3, with_replacement=False)
        first = [item.turn_index for item in replay.sample(4)]
        state = replay.state_dict()
        restored = ReplayBuffer.from_state_dict(state)
        second_a = [item.turn_index for item in replay.sample(4)]
        second_b = [item.turn_index for item in restored.sample(4)]
        self.assertEqual(second_a, second_b)
        self.assertEqual(first.__len__(), 4)

    def test_metrics_denominators(self):
        metrics = RunMetrics("corrected_primary", "esconv", "valid", 7)
        metrics.attempted_episodes = 2
        metrics.eligible_episodes = 1
        metrics.completed_episodes = 1
        metrics.solved_episodes = 1
        metrics.failed_episodes = 0
        metrics.quarantined_episodes = 1
        metrics.total_turns = 2
        metrics.completed_turns = 2
        metrics.total_reward = 1.0
        metrics.completed_reward = 1.5
        summary = metrics.summary()
        self.assertEqual(summary["SR_attempted"], 0.5)
        self.assertEqual(summary["SR_eligible"], 1.0)
        self.assertEqual(summary["AT_attempted"], 1.0)
        self.assertEqual(summary["AT_completed"], 2.0)

    def test_role_metrics_use_sequence_and_invocation_denominators(self):
        metrics = RunMetrics("corrected_primary", "esconv", "valid", 7)
        base = dict(
            role="critic", case_id="c", split="valid", track="corrected_primary",
            turn=0, seed=7, attempt=1, messages=({"role": "user", "content": "x"},),
            canonical_prompt="x", prompt_sha256="0" * 64, generation_config={},
            prompt_tokens=3, completion_tokens=1, raw_output="same", parse_status="PASS",
        )
        metrics.record_generation_records([
            GenerationRecord(invocation=1, sequence_index=i, **base) for i in range(10)
        ])
        summary = metrics.summary()
        self.assertEqual(summary["generation_invocations_by_role"]["critic"], 1)
        self.assertEqual(summary["returned_sequences_by_role"]["critic"], 10)
        self.assertEqual(summary["unique_outputs_by_role"]["critic"], 1)

    def test_prior_failure_denominator_is_prior_sequences(self):
        metrics = RunMetrics("corrected_primary", "esconv", "valid", 7)
        metrics.prior_parse_failures = 1
        metrics.returned_sequences_by_role = {"prior": 4, "critic": 100}
        self.assertEqual(metrics.summary()["prior_parse_failure_rate"], 0.25)

    def test_invalid_prior_attempt_is_counted_before_successful_retry(self):
        metrics = RunMetrics("corrected_primary", "esconv", "valid", 7)
        base = dict(
            role="prior", case_id="c", split="valid", track="corrected_primary",
            turn=0, seed=7, messages=({"role": "user", "content": "x"},),
            canonical_prompt="x", prompt_sha256="0" * 64, generation_config={},
            prompt_tokens=3, completion_tokens=1, raw_output="bad",
        )
        metrics.record_generation_records([
            GenerationRecord(invocation=1, sequence_index=0, attempt=1,
                             parse_status="FAIL:bad", **base),
            GenerationRecord(invocation=2, sequence_index=0, attempt=2,
                             parse_status="PASS", **(base | {"raw_output": "1,2,3,4"})),
        ])
        self.assertEqual(metrics.prior_parse_failures, 1)
        self.assertEqual(metrics.summary()["prior_parse_failure_rate"], 0.5)

    def test_old_replay_schema_rejected(self):
        with self.assertRaises(ValueError):
            ReplayBuffer.from_state_dict({
                "capacity": 1, "items": [], "sample_with_replacement": True,
                "sampler_rng_state": random.Random(0).getstate(), "sample_count": 0,
            })

    def test_old_checkpoint_format_rejected(self):
        online = QMLP(2)
        target = QMLP(2)
        optimizer = torch.optim.AdamW(online.parameters(), lr=1e-3)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "old.pt"
            save_checkpoint(
                path,
                online_head=online,
                target_head=target,
                optimizer=optimizer,
                replay=ReplayBuffer(1),
                counters={},
                behavior_track="corrected_primary",
                registry_version=2,
                configs={},
                manifests={},
                metrics={},
                code_state={"commit": "unit", "dirty": False},
            )
            payload = torch.load(path, map_location="cpu", weights_only=False)
            payload["format_version"] = 2
            torch.save(payload, path)
            checkpoint_sha_path(path).write_text(
                f"{sha256_file(path)}  {path.name}\n", encoding="utf-8"
            )
            with self.assertRaisesRegex(ValueError, "format version mismatch"):
                load_checkpoint(
                    path,
                    online_head=QMLP(2),
                    target_head=QMLP(2),
                    optimizer=torch.optim.AdamW(QMLP(2).parameters(), lr=1e-3),
                    expected_behavior_track="corrected_primary",
                    expected_manifests={},
                    expected_registry_version=2,
                    expected_configs={},
                    expected_code_state={"commit": "unit", "dirty": False},
                    trusted_local_only=True,
                )

    def test_checkpoint_deterministic_next_update_and_trust_gate(self):
        _, _, replay, _, online, encoder, spec = ParserAndRuntimeTests()._episode()
        target = QMLP(32)
        target.load_state_dict(online.state_dict())
        optimizer = torch.optim.AdamW(online.parameters(), lr=1e-3)
        configs = {"gamma": 0.999, "tau": 0.005}
        manifests = {
            "encoder": encoder.manifest,
            "action_registry_hash": spec.action_registry_hash,
            "model": {"backend": "scripted"},
        }
        code_state = {"commit": "unit", "dirty": False}
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "checkpoint.pt"
            save_checkpoint(
                path,
                online_head=online,
                target_head=target,
                optimizer=optimizer,
                replay=replay,
                counters={"update": 0},
                behavior_track="corrected_primary",
                registry_version=2,
                configs=configs,
                manifests=manifests,
                metrics={},
                code_state=code_state,
            )
            with self.assertRaises(ValueError):
                load_checkpoint(
                    path,
                    online_head=QMLP(32),
                    target_head=QMLP(32),
                    optimizer=torch.optim.AdamW(QMLP(32).parameters(), lr=1e-3),
                    expected_behavior_track="corrected_primary",
                    expected_manifests=manifests,
                    expected_registry_version=2,
                    expected_configs=configs,
                    expected_code_state=code_state,
                )

            def next_update():
                q = QMLP(32)
                t = QMLP(32)
                opt = torch.optim.AdamW(q.parameters(), lr=1e-3)
                payload = load_checkpoint(
                    path,
                    online_head=q,
                    target_head=t,
                    optimizer=opt,
                    expected_behavior_track="corrected_primary",
                    expected_manifests=manifests,
                    expected_registry_version=2,
                    expected_configs=configs,
                    expected_code_state=code_state,
                    trusted_local_only=True,
                )
                batch = payload["replay_buffer"].sample(2)
                loss = train_qnetwork(
                    batch, opt, q, t, "cpu", gamma=0.999, tau=0.005
                )
                return loss, {key: value.clone() for key, value in q.state_dict().items()}

            loss_a, state_a = next_update()
            loss_b, state_b = next_update()
            self.assertEqual(loss_a, loss_b)
            self.assertTrue(
                all(torch.equal(state_a[key], state_b[key]) for key in state_a)
            )

    def test_tasklog_duplicate_and_heartbeat_failure(self):
        with tempfile.TemporaryDirectory() as directory:
            first = TaskLog(directory, "unit", "same")
            second = TaskLog(
                directory,
                "unit",
                "same",
                context={
                    "commit": "unit",
                    "track": "corrected_primary",
                    "dataset": "esconv",
                    "split": "train",
                    "model_path": "scripted",
                    "model_hash": "unit",
                    "gpu": "none",
                    "tmux": "none",
                },
            )
            self.assertEqual(len(second.logger.handlers), 2)
            stop, thread = second.start_heartbeat(
                lambda: (_ for _ in ()).throw(RuntimeError("boom")),
                interval_seconds=1,
            )
            thread.join(3)
            self.assertFalse(thread.is_alive())
            self.assertIn(
                "heartbeat_failed",
                (second.directory / "status.json").read_text(encoding="utf-8"),
            )
            stop.set()
            second.write_command("python -m unit")
            second.write_environment({"offline": 1})
            second.finalize_artifact_manifest()
            self.assertTrue((second.directory / "command.sh").is_file())
            self.assertIn("status.json", (second.directory / "artifact_manifest.tsv").read_text())
            first.close()
            second.close()


if __name__ == "__main__":
    unittest.main()
