"""Offline CPU gates for P3.6 storage, causal state, and learning contracts."""

from __future__ import annotations

import tempfile
import unittest
import copy
import json
from pathlib import Path

import torch

from dialogxpert_repro.checkpoint import load_checkpoint, save_checkpoint
from dialogxpert_repro.encoding import tensor_storage_metadata
from dialogxpert_repro.qnet import FrozenBertEncoder, QMLP
from dialogxpert_repro.rl import ReplayBuffer
from dialogxpert_repro.registry import get_dataset, load_split
from dialogxpert_repro.state import EmotionState, initialize_state, make_emotion_state
from dialogxpert_repro.state_serializer import serialize_planner_state
from dialogxpert_repro.views import build_planner_state_view
from dialogxpert_repro.protocols import PROTOCOLS
from dialogxpert_repro.prompts import build_policy_messages, build_roleplay_messages
from dialogxpert_repro.rewards import aggregate_critic_outputs
from dialogxpert_repro.seeding import functional_seed
from dialogxpert_repro.known_mdp import run_toy_bandit, run_two_step


BERT_PATH = Path(
    "/data1/zhangruibo/models/hf_cache/"
    "git_lfs_tmp_20260708_164346/bert-base-uncased"
)


class CompactStorageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.encoder = FrozenBertEncoder(BERT_PATH, pooling="cls", max_length=64)

    def test_cls_batch_owns_only_logical_storage(self) -> None:
        result = self.encoder.encode_pairs(
            ["long causal state " * 300] * 4,
            ["Question", "Information", "Reflection of feelings", "Providing Suggestions"],
        )
        batch = tensor_storage_metadata(result.features)
        self.assertEqual(batch["storage_bytes"], batch["logical_bytes"])
        self.assertTrue(batch["is_contiguous"])
        for feature in result.features:
            compact = feature.contiguous().clone()
            metadata = tensor_storage_metadata(compact)
            self.assertEqual(metadata["storage_bytes"], metadata["logical_bytes"])

    def test_thirty_transition_checkpoint_is_under_ten_mib(self) -> None:
        # Importing this helper executes only the scripted train-split fixture path.
        from tests.test_core import ParserAndRuntimeTests

        result, _, _, _, online, encoder, spec = ParserAndRuntimeTests()._episode()
        replay = ReplayBuffer(64, seed=17)
        for index in range(30):
            transition = result.transitions[index % len(result.transitions)]
            replay.append(transition)
        for transition in replay._data:
            for name in ("candidate_features", "selected_feature", "next_features"):
                metadata = tensor_storage_metadata(getattr(transition, name))
                self.assertEqual(metadata["storage_bytes"], metadata["logical_bytes"])
        target = QMLP(32)
        target.load_state_dict(online.state_dict())
        optimizer = torch.optim.AdamW(online.parameters(), lr=1e-3)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "thirty.pt"
            save_checkpoint(
                path,
                online_head=online,
                target_head=target,
                optimizer=optimizer,
                replay=replay,
                counters={"episode": 30, "update": 0},
                behavior_track="corrected_primary",
                registry_version=3,
                configs={"unit": "compact-storage"},
                manifests={"encoder": encoder.manifest,
                           "action_registry_hash": spec.action_registry_hash},
                metrics={},
                code_state={"commit": "unit", "dirty": False},
            )
            self.assertLess(path.stat().st_size, 10 * 1024 * 1024)


class CausalSerializationTests(unittest.TestCase):
    def test_identity_and_q_text_ignore_future_gold_mutation(self) -> None:
        spec = get_dataset("esconv")
        case = load_split("esconv", "train")[0]
        changed = copy.deepcopy(case)
        changed["dialog"] = [{"text": "FUTURE_SENTINEL", "strategy": "FUTURE"}]
        state_a = initialize_state(spec, case)
        state_b = initialize_state(spec, changed)
        text_a = serialize_planner_state(build_planner_state_view(spec, case, state_a)).text
        text_b = serialize_planner_state(build_planner_state_view(spec, changed, state_b)).text
        self.assertEqual(case["_dx_case_id"], "esconv:train:0")
        self.assertEqual(text_a, text_b)
        self.assertNotIn(case["_dx_case_id"], text_a)
        self.assertNotIn("case_id", text_a)

    def test_eight_turn_budget_preserves_context_current_user_and_emotion(self) -> None:
        spec = get_dataset("esconv")
        case = dict(load_split("esconv", "train")[0])
        case["situation"] = "CRITICAL_CASE_CONTEXT"
        state = initialize_state(spec, case)
        state.conversation.clear()
        for index in range(8):
            state.append("Therapist", f"OLD_SYSTEM_{index}_" + "x" * 120)
            state.append("Patient", f"OLD_USER_{index}_" + "y" * 120)
        state.append("Patient", "CURRENT_USER_SENTINEL")
        emotion, _ = make_emotion_state(
            {"raw": "Concerned because of long raw utterance", "normalized": "concerned"},
            state,
            tracker_variant="tracker_text_only",
        )
        state.emotion_history.append(emotion)
        encoder = FrozenBertEncoder(BERT_PATH, pooling="cls", max_length=256)
        action_tokens = len(encoder.tokenizer(
            "Providing Suggestions", add_special_tokens=False
        )["input_ids"])
        reserve = action_tokens + 3
        result = serialize_planner_state(
            build_planner_state_view(spec, case, state),
            tokenizer=encoder.tokenizer,
            max_state_tokens=encoder.max_length - reserve,
            reserve_action_tokens=reserve,
        )
        self.assertIn("CRITICAL_CASE_CONTEXT", result.text)
        self.assertIn("CURRENT_USER_SENTINEL", result.text)
        self.assertIn('"label":"concerned"', result.text)
        self.assertTrue(result.audit["dropped_turn_ids"])
        self.assertEqual(result.audit["truncation_reason"], "oldest_complete_turns")
        self.assertTrue(result.audit["token_budget_enforced"])
        self.assertLessEqual(result.audit["serialized_state_tokens"],
                             result.audit["max_state_tokens"])

    def test_bert_right_truncation_keeps_critical_prefix_and_action(self) -> None:
        spec = get_dataset("esconv")
        case = dict(load_split("esconv", "train")[0])
        case["situation"] = "criticalcontextsentinel"
        state = initialize_state(spec, case)
        state.conversation.clear()
        state.append("Patient", "currentusersentinel")
        emotion, _ = make_emotion_state(
            {"raw": "concerned", "normalized": "concerned"}, state,
            tracker_variant="tracker_text_only",
        )
        state.emotion_history.append(emotion)
        for index in range(20):
            state.conversation.insert(0, {
                "role": "Therapist", "content": f"oldturn{index} " + "old " * 80
            })
        encoder = FrozenBertEncoder(BERT_PATH, pooling="cls", max_length=256)
        action = "Providing Suggestions"
        reserve = len(encoder.tokenizer(
            action, add_special_tokens=False
        )["input_ids"]) + 3
        serialized = serialize_planner_state(
            build_planner_state_view(spec, case, state),
            tokenizer=encoder.tokenizer,
            max_state_tokens=encoder.max_length - reserve,
            reserve_action_tokens=reserve,
        )
        text = serialized.text
        encoded = encoder.encode_pairs([text], [action])
        decoded = encoder.tokenizer.decode(encoded.token_stats[0]["input_ids"])
        compact = decoded.replace(" ", "")
        self.assertIn("criticalcontextsentinel", compact)
        self.assertIn("currentusersentinel", compact)
        self.assertIn("concerned", decoded)
        self.assertTrue(encoded.token_stats[0]["action_preserved"])
        self.assertEqual(encoded.token_stats[0]["truncated_state_tokens"], 0)
        self.assertLessEqual(serialized.audit["serialized_state_tokens"],
                             serialized.audit["max_state_tokens"])

    def test_planner_emotion_has_no_raw_or_source_text(self) -> None:
        spec = get_dataset("esconv")
        case = load_split("esconv", "train")[0]
        state = initialize_state(spec, case)
        emotion, oov = make_emotion_state(
            {"raw": "THE WHOLE RAW MODEL OUTPUT", "normalized": "mystery mood"},
            state,
            tracker_variant="tracker_text_only",
        )
        self.assertTrue(oov)
        self.assertEqual(emotion.label, "mystery mood")
        state.emotion_history.append(emotion)
        payload = build_planner_state_view(spec, case, state).as_dict()
        encoded = json.dumps(payload)
        self.assertNotIn("THE WHOLE RAW MODEL OUTPUT", encoded)
        self.assertNotIn('"raw"', encoded)
        self.assertNotIn('"source_text"', encoded)
        self.assertNotIn("source_text_sha256", encoded)
        self.assertNotIn("source_role", encoded)

    def test_emotion_alias_v2_retains_unknown_and_canonicalizes_required_pairs(self) -> None:
        from dialogxpert_repro.state import normalize_emotion_label

        expected = {
            "anxious": "anxiety",
            "anxiety": "anxiety",
            "frustrated": "frustration",
            "frustration": "frustration",
            "depressed": "depression",
            "depression": "depression",
        }
        for raw, canonical in expected.items():
            self.assertEqual(normalize_emotion_label(raw), (canonical, False))
        self.assertEqual(normalize_emotion_label("Protective Anger"),
                         ("protective anger", True))

    def test_duplicate_case_situation_is_retained_once_by_current_user_reference(self) -> None:
        spec = get_dataset("esconv")
        case = load_split("esconv", "train")[0]
        state = initialize_state(spec, case)
        view = build_planner_state_view(
            spec, case, state, emotion_tracker_variant="tracker_text_only"
        )
        result = serialize_planner_state(view, max_chars=6000)
        self.assertEqual(result.text.count(case["situation"]), 1)
        self.assertEqual(
            result.audit["case_context_fields_deduplicated_to_current_user"],
            ["situation"],
        )

    def test_tracker_variants_are_explicit(self) -> None:
        from dialogxpert_repro.episode import EpisodeConfig

        variants = {
            "corrected_case_oracle_ablation": "tracker_case_oracle",
            "corrected_resolved_only": "tracker_text_only",
            "corrected_no_emotion_ablation": "no_emotion",
        }
        for protocol_name, variant in variants.items():
            self.assertEqual(EpisodeConfig(
                protocol_name=protocol_name,
                emotion_tracker_variant=variant,
            ).emotion_tracker_variant, variant)
        with self.assertRaises(ValueError):
            EpisodeConfig(emotion_tracker_variant="implicit")

    def test_text_only_and_no_emotion_hide_gold_initial_emotion_from_q_and_prior(self) -> None:
        spec = get_dataset("esconv")
        case = load_split("esconv", "train")[0]
        state = initialize_state(spec, case)
        oracle = build_planner_state_view(
            spec, case, state, emotion_tracker_variant="tracker_case_oracle"
        ).as_dict()
        text_only = build_planner_state_view(
            spec, case, state, emotion_tracker_variant="tracker_text_only"
        ).as_dict()
        no_emotion = build_planner_state_view(
            spec, case, state, emotion_tracker_variant="no_emotion",
            include_emotion=False,
        ).as_dict()
        self.assertEqual(oracle["public_case_context"]["emotion_type"],
                         case["emotion_type"])
        self.assertNotIn("emotion_type", text_only["public_case_context"])
        self.assertNotIn("emotion_type", no_emotion["public_case_context"])
        self.assertEqual(no_emotion["emotion_history"], ())
        options = "\n".join(
            f"{i}. {name}: {description}"
            for i, (name, description) in enumerate(spec.action_inventory.items(), 1)
        )
        prior = build_policy_messages(
            spec, state.conversation, [], options, top_k=4, case=case,
            prompt_variant="dataset_specific_corrected_v1",
            emotion_tracker_variant="tracker_text_only",
        )
        self.assertNotIn(f"Emotion type: {case['emotion_type']}",
                         "\n".join(item["content"] for item in prior))


class ProtocolAndRNGTests(unittest.TestCase):
    def test_protocols_have_distinct_stable_hashes(self) -> None:
        self.assertTrue({
            "released_code_compat", "extended_prompt_faithful",
            "corrected_resolved_only",
        }.issubset(PROTOCOLS))
        self.assertEqual(len({protocol.sha256 for protocol in PROTOCOLS.values()}),
                         len(PROTOCOLS))
        required = {
            "prior_variant", "emotion_tracker_variant", "system_prompt_variant",
            "user_prompt_variant", "critic_prompt_variant", "critic_sampling",
            "reward_aggregation", "termination_policy", "q_state_variant",
            "pooling", "epsilon_schedule", "generation_seed_policy",
        }
        self.assertTrue(all(required.issubset(vars(protocol))
                            for protocol in PROTOCOLS.values()))

    def test_appendix_policy_system_and_user_prompts_are_independently_routed(self) -> None:
        spec = get_dataset("esconv")
        case = load_split("esconv", "train")[0]
        state = initialize_state(spec, case)
        options = "\n".join(
            f"{i}. {name}: {description}"
            for i, (name, description) in enumerate(spec.action_inventory.items(), 1)
        )
        policy = build_policy_messages(
            spec, state.conversation, [], options, top_k=4, case=case,
            prompt_variant="esconv_appendix_policy_exact_v1",
        )
        system = build_roleplay_messages(
            spec, case, "system", state.conversation, [], "Question",
            coupled_emotion=True,
            system_prompt_variant="esconv_appendix_system_exact_v1",
        )
        user = build_roleplay_messages(
            spec, case, "user", state.conversation,
            user_prompt_variant="esconv_appendix_user_exact_v1",
        )
        self.assertIn("specialist in policy-planning for emotional support", policy[0]["content"])
        self.assertIn("Choose the TOP 4", policy[1]["content"])
        self.assertIn("infer the patient's emotional state in one word", system[1]["content"])
        self.assertIn(spec.action_inventory["Question"], system[1]["content"])
        self.assertIn(f"related to {case['emotion_type']} regarding {case['problem_type']}",
                      user[0]["content"])

    def test_appendix_esconv_critic_uses_full_sentences(self) -> None:
        spec = get_dataset("esconv")
        case = load_split("esconv", "train")[0]
        state = initialize_state(spec, case)
        messages = build_roleplay_messages(
            spec, case, "critic", state.conversation,
            critic_variant="critic_appendix_full_sentence_v1",
        )
        prompt = "\n".join(message["content"] for message in messages)
        self.assertIn("No, but the patient feels somewhat better.", prompt)
        self.assertIn("Yes, the patient's emotional issues have been resolved.", prompt)
        aggregation = aggregate_critic_outputs(
            spec, ["No, but the patient feels somewhat better."] * 10, case
        )
        self.assertEqual(aggregation.majority_label, "better")

    def test_protocol_binding_rejects_silent_critic_or_emotion_overrides(self) -> None:
        from dialogxpert_repro.episode import EpisodeConfig

        with self.assertRaisesRegex(ValueError, "critic prompt"):
            EpisodeConfig(critic_prompt_variant="critic_appendix_full_sentence_v1")
        with self.assertRaisesRegex(ValueError, "emotion tracker"):
            EpisodeConfig(emotion_tracker_variant="no_emotion")

    def test_no_emotion_runtime_has_no_tracker_or_q_emotion(self) -> None:
        from dialogxpert_repro.backend import ScriptedBackend
        from dialogxpert_repro.episode import EpisodeConfig
        from dialogxpert_repro.runtime import DeterministicHashEncoder, run_episode

        spec = get_dataset("esconv")
        case = load_split("esconv", "train")[0]
        backend = ScriptedBackend(seed=23, critic_batches=[["solved"] * 10])
        result = run_episode(
            spec=spec, case=case, split="train", backend=backend,
            encoder=DeterministicHashEncoder(32), online_head=QMLP(32),
            replay=ReplayBuffer(16, seed=23),
            config=EpisodeConfig(
                protocol_name="corrected_no_emotion_ablation",
                emotion_tracker_variant="no_emotion",
                seed=23,
            ),
        )
        self.assertNotIn("emotion", backend.call_order)
        self.assertEqual(result.transitions[0].planner_state_view["emotion_history"], ())
        self.assertNotIn('"emotion_type"', result.transitions[0].state_text)

    def test_episode_seed_is_order_independent_and_episode_specific(self) -> None:
        common = dict(global_seed=7, phase="train", case_id="esconv:train:0",
                      turn=1, role="critic", attempt=1, sequence_index=0)
        first = functional_seed(episode_id=3, **common)
        self.assertEqual(first, functional_seed(episode_id=3, **common))
        self.assertNotEqual(first, functional_seed(episode_id=4, **common))
        self.assertNotEqual(
            functional_seed(7, phase="train", episode_id=3,
                            case_id="esconv:train:0", turn=1, role="critic"),
            functional_seed(7, phase="valid", episode_id=3,
                            case_id="esconv:train:0", turn=1, role="critic"),
        )

    def test_full_episode_replay_from_address_is_exact(self) -> None:
        from tests.test_core import ParserAndRuntimeTests
        from dialogxpert_repro.backend import ScriptedBackend
        from dialogxpert_repro.metrics import RunMetrics
        from dialogxpert_repro.qnet import QMLP
        from dialogxpert_repro.runtime import DeterministicHashEncoder, run_episode
        from dialogxpert_repro.episode import EpisodeConfig

        spec = get_dataset("esconv")
        case = load_split("esconv", "train")[0]
        torch.manual_seed(11)
        head = QMLP(32)

        def execute():
            backend = ScriptedBackend(seed=17)
            replay = ReplayBuffer(32, seed=17)
            result = run_episode(
                spec=spec, case=case, split="train", backend=backend,
                encoder=DeterministicHashEncoder(32), online_head=head,
                replay=replay,
                config=EpisodeConfig(seed=17, episode_id=9),
                metrics=RunMetrics("corrected_primary", "esconv", "train", 17),
            )
            return result, backend

        result_a, backend_a = execute()
        result_b, backend_b = execute()
        self.assertEqual([record.seed for record in backend_a.records],
                         [record.seed for record in backend_b.records])
        self.assertEqual([item.selected_action for item in result_a.transitions],
                         [item.selected_action for item in result_b.transitions])
        self.assertEqual([item.candidate_feature_hashes for item in result_a.transitions],
                         [item.candidate_feature_hashes for item in result_b.transitions])

    def test_checkpoint_resume_next_episode_is_exact(self) -> None:
        from dialogxpert_repro.backend import ScriptedBackend
        from dialogxpert_repro.episode import EpisodeConfig
        from dialogxpert_repro.metrics import RunMetrics
        from dialogxpert_repro.runtime import DeterministicHashEncoder, run_episode

        spec = get_dataset("esconv")
        cases = load_split("esconv", "train")[:2]
        encoder = DeterministicHashEncoder(32)
        torch.manual_seed(29)
        online = QMLP(32)
        target = QMLP(32)
        target.load_state_dict(online.state_dict())
        optimizer = torch.optim.AdamW(online.parameters(), lr=1e-3)
        replay = ReplayBuffer(64, seed=29)
        continuous_backend = ScriptedBackend(seed=29)

        run_episode(
            spec=spec, case=cases[0], split="train", backend=continuous_backend,
            encoder=encoder, online_head=online, replay=replay,
            config=EpisodeConfig(seed=29, episode_id=0),
            metrics=RunMetrics("corrected_primary", "esconv", "train", 29),
        )
        configs = {"unit": "full-episode-resume"}
        manifests = {"encoder": encoder.manifest,
                     "action_registry_hash": spec.action_registry_hash}
        code_state = {"commit": "unit", "dirty": False}
        resume_contract = {
            "episode_sampler_state": {"strategy": "fixed_prefix", "position": 1},
            "next_episode_id": 1,
            "sampling_rng_state": replay.state_dict()["sampler_rng_state"],
            "epsilon_schedule": {"type": "constant", "value": 0.0},
            "backend_seed_protocol": "episode-addressable-v1",
            "target_update_count": 0,
            "validation_schedule": {"type": "none"},
        }
        with tempfile.TemporaryDirectory() as directory:
            checkpoint = Path(directory) / "resume.pt"
            save_checkpoint(
                checkpoint, online_head=online, target_head=target,
                optimizer=optimizer, replay=replay,
                counters={"episode": 1, "update": 0},
                behavior_track="corrected_primary", registry_version=3,
                configs=configs, manifests=manifests, metrics={},
                code_state=code_state, episode_resume=resume_contract,
            )
            reference_start = len(continuous_backend.records)
            reference = run_episode(
                spec=spec, case=cases[1], split="train", backend=continuous_backend,
                encoder=encoder, online_head=online, replay=replay,
                config=EpisodeConfig(seed=29, episode_id=1),
                metrics=RunMetrics("corrected_primary", "esconv", "train", 29),
            )

            restored_online = QMLP(32)
            restored_target = QMLP(32)
            restored_optimizer = torch.optim.AdamW(restored_online.parameters(), lr=1e-3)
            payload = load_checkpoint(
                checkpoint, online_head=restored_online, target_head=restored_target,
                optimizer=restored_optimizer,
                expected_behavior_track="corrected_primary",
                expected_manifests=manifests, expected_registry_version=3,
                expected_configs=configs, expected_code_state=code_state,
                trusted_local_only=True,
            )
            self.assertEqual(payload["episode_resume"], resume_contract)
            resumed_backend = ScriptedBackend(seed=29)
            resumed = run_episode(
                spec=spec, case=cases[1], split="train", backend=resumed_backend,
                encoder=encoder, online_head=restored_online,
                replay=payload["replay_buffer"],
                config=EpisodeConfig(
                    seed=29,
                    episode_id=payload["episode_resume"]["next_episode_id"],
                ),
                metrics=RunMetrics("corrected_primary", "esconv", "train", 29),
            )

        reference_records = continuous_backend.records[reference_start:]
        self.assertEqual(
            [(r.seed, r.prompt_sha256, r.raw_output) for r in reference_records],
            [(r.seed, r.prompt_sha256, r.raw_output) for r in resumed_backend.records],
        )
        self.assertEqual(
            [(t.selected_action, t.selection_random_draw, t.candidate_feature_hashes)
             for t in reference.transitions],
            [(t.selected_action, t.selection_random_draw, t.candidate_feature_hashes)
             for t in resumed.transitions],
        )
        self.assertEqual(
            [t.candidate_q_values for t in reference.transitions],
            [t.candidate_q_values for t in resumed.transitions],
        )

    def test_validation_interleaving_does_not_change_train_episode(self) -> None:
        from dialogxpert_repro.backend import ScriptedBackend
        from dialogxpert_repro.episode import EpisodeConfig
        from dialogxpert_repro.runtime import DeterministicHashEncoder, run_episode

        spec = get_dataset("esconv")
        train_case = load_split("esconv", "train")[4]
        valid_case = load_split("esconv", "valid")[0]
        torch.manual_seed(31)
        head = QMLP(32)
        encoder = DeterministicHashEncoder(32)

        direct_backend = ScriptedBackend(seed=31)
        direct = run_episode(
            spec=spec, case=train_case, split="train", backend=direct_backend,
            encoder=encoder, online_head=head, replay=ReplayBuffer(32, seed=31),
            config=EpisodeConfig(seed=31, episode_id=4),
        )
        interleaved_backend = ScriptedBackend(seed=31)
        run_episode(
            spec=spec, case=valid_case, split="valid", backend=interleaved_backend,
            encoder=encoder, online_head=head, replay=ReplayBuffer(32, seed=31),
            config=EpisodeConfig(seed=31, episode_id=90),
        )
        train_start = len(interleaved_backend.records)
        interleaved = run_episode(
            spec=spec, case=train_case, split="train", backend=interleaved_backend,
            encoder=encoder, online_head=head, replay=ReplayBuffer(32, seed=31),
            config=EpisodeConfig(seed=31, episode_id=4),
        )
        interleaved_records = interleaved_backend.records[train_start:]
        self.assertEqual(
            [(r.seed, r.prompt_sha256, r.raw_output) for r in direct_backend.records],
            [(r.seed, r.prompt_sha256, r.raw_output) for r in interleaved_records],
        )
        self.assertEqual(
            [(t.selected_action, t.selection_random_draw, t.candidate_feature_hashes)
             for t in direct.transitions],
            [(t.selected_action, t.selection_random_draw, t.candidate_feature_hashes)
             for t in interleaved.transitions],
        )


class KnownMDPTests(unittest.TestCase):
    def test_four_action_bandit_converges_across_seeds(self) -> None:
        results = [run_toy_bandit(seed) for seed in (3, 17, 101, 509)]
        self.assertTrue(all(result.converged for result in results))
        self.assertTrue(all(result.selected_action == "a3" for result in results))

    def test_two_step_prefers_delayed_reward_across_seeds(self) -> None:
        results = [run_two_step(seed) for seed in (3, 17, 101, 509)]
        self.assertTrue(all(result.converged for result in results))
        self.assertTrue(all(result.selected_action == "advance" for result in results))
        self.assertTrue(all(result.q_values["s0"][1] > result.q_values["s0"][0]
                            for result in results))

    def test_reward_shuffle_negative_control_changes_policy(self) -> None:
        normal = run_two_step(17)
        shuffled = run_two_step(17, reward_shuffle=True)
        self.assertEqual(normal.selected_action, "advance")
        self.assertEqual(shuffled.selected_action, "short")
        self.assertTrue(shuffled.converged)


if __name__ == "__main__":
    unittest.main()
