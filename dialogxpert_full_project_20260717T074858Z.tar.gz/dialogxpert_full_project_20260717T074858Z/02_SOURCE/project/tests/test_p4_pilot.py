"""Offline fail-closed tests for the bounded P4-A harness (no pilot execution)."""

from __future__ import annotations

import json
import tempfile
import unittest
from dataclasses import asdict
from pathlib import Path

from dialogxpert_repro.backend import ScriptedBackend
from dialogxpert_repro.metrics import RunMetrics
from dialogxpert_repro.p4_pilot import (
    HardStopMonitor,
    P4APilotRunner,
    PilotConfig,
    fixed_validation_contract,
    require_gate_authorization,
    require_single_gpu,
    load_phase_a_gate_artifact,
)
from dialogxpert_repro.p4_pilot import module_sha256
from dialogxpert_repro.registry import get_dataset, load_split
from dialogxpert_repro.runtime import DeterministicHashEncoder
from dialogxpert_repro.safety import SealedTestAccessError
from dialogxpert_repro.seeding import functional_seed


class P4PilotHarnessTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.spec = get_dataset("esconv")
        cls.train = load_split("esconv", "train")[:24]
        cls.valid = load_split("esconv", "valid")[:20]

    def config(self, arm: str = "A2", **changes):
        ids, seeds = fixed_validation_contract(self.valid, 7)
        values = {
            "arm": arm, "learning_rate": 1e-4,
            "fixed_validation_case_ids": ids,
            "fixed_validation_seeds": seeds,
        }
        values.update(changes)
        return PilotConfig(**values)

    def runner(self, config=None, directory=None, backend=None, **kwargs):
        return P4APilotRunner(
            repo_root=Path(__file__).resolve().parents[1],
            output_dir=directory or Path(tempfile.gettempdir()) / "dx-p4-unit",
            spec=self.spec, train_cases=self.train, valid_cases=self.valid,
            backend=backend or ScriptedBackend(seed=7),
            encoder=DeterministicHashEncoder(32), config=config or self.config(),
            device="cpu", **kwargs,
        )

    def test_config_hash_rejects_drift(self):
        config = self.config()
        envelope = config.state_dict()
        self.assertEqual(PilotConfig.from_state_dict(envelope), config)
        envelope["config"]["learning_rate"] = 1e-6
        with self.assertRaises(ValueError):
            PilotConfig.from_state_dict(envelope)

    def test_epsilon_endpoints_and_checkpoint_schedule(self):
        config = self.config()
        self.assertEqual(config.epsilon(0), 1.0)
        self.assertAlmostEqual(config.epsilon(19), 0.1)
        runner = self.runner(config)
        self.assertFalse(runner.checkpoint_due)
        runner.state.next_train_episode_id = 5
        self.assertTrue(runner.checkpoint_due)
        self.assertEqual(config.bert_device, "cuda:0")
        values = asdict(config)
        values["bert_device"] = "cuda:1"
        with self.assertRaises(ValueError):
            PilotConfig(**values)

    def test_gate_authorization_is_exact(self):
        with self.assertRaises(PermissionError):
            require_gate_authorization("P4_A_NOT_AUTHORIZED_BY_GATE")
        require_gate_authorization("P4_A_AUTHORIZED_BY_GATE")
        require_single_gpu("cuda:0", "3")
        for device, visible in (("cuda:1", "3"), ("cuda:0", ""),
                                ("cuda:0", "2,3")):
            with self.assertRaises(RuntimeError):
                require_single_gpu(device, visible)

    def test_a0_prior_only_has_no_q_update(self):
        runner = self.runner(self.config("A0"))
        record = runner.run_train_episode(0)
        self.assertIsNone(record["loss"])
        self.assertEqual(runner.state.q_update_count, 0)
        self.assertEqual(runner.state.target_sync_count, 0)
        self.assertTrue(all(
            item["selected_action_index"] == 0 for item in record["transitions"]
        ))

    def test_a3_has_all_eight_q_values_and_no_prior_call(self):
        backend = ScriptedBackend(seed=7)
        runner = self.runner(self.config("A3"), backend=backend)
        record = runner.run_train_episode(0)
        self.assertTrue(all(len(item["all_q"]) == 8 for item in record["transitions"]))
        self.assertNotIn("prior", backend.call_order)
        self.assertEqual(runner.config.protocol_name, "corrected_all8_q_pilot")

    def test_each_q_update_performs_one_preregistered_target_soft_sync(self):
        runner = self.runner()
        target_before = module_sha256(runner.target)
        runner.run_train_episode(0)
        self.assertEqual(runner.config.target_tau, 0.005)
        self.assertEqual(runner.state.q_update_count, 1)
        self.assertEqual(runner.state.target_sync_count, 1)
        self.assertNotEqual(target_before, module_sha256(runner.target))

    def test_validation_cannot_mutate_train_state(self):
        runner = self.runner()
        runner.run_train_episode(0)
        before = runner._train_invariant_snapshot()
        records = runner.run_validation_block()
        self.assertEqual(len(records), 20)
        self.assertEqual(before, runner._train_invariant_snapshot())

    def test_inserted_validation_does_not_change_next_train_episode(self):
        with_validation = self.runner()
        without_validation = self.runner()
        with_validation.run_train_episode(0)
        without_validation.run_train_episode(0)
        with_validation.run_validation_block()
        left = with_validation.run_train_episode(1)
        right = without_validation.run_train_episode(1)
        keep = ("case_id", "termination", "cumulative_reward", "transitions",
                "loss", "online_before", "online_after")
        self.assertEqual({key: left[key] for key in keep},
                         {key: right[key] for key in keep})

    def test_phase_b_requires_matching_phase_a_pass(self):
        ids, seeds = fixed_validation_contract(self.valid, 7)
        phase_b = PilotConfig(
            arm="A2", learning_rate=1e-4, phase="B", train_episodes=50,
            fixed_validation_case_ids=ids, fixed_validation_seeds=seeds,
        )
        with self.assertRaises(PermissionError):
            self.runner(phase_b)
        runner = self.runner(phase_b, phase_a_authorization={
            "phase_b_authorized": True, "arm": "A2",
            "learning_rate": 1e-4, "global_seed": 7,
            "phase_a_config": self.config("A2").state_dict(),
        })
        self.assertEqual(runner.config.phase, "B")

    def test_rate_threshold_boundaries(self):
        acceptable = RunMetrics("corrected_primary", "esconv", "train", 7)
        acceptable.returned_sequences_by_role["prior"] = 10
        acceptable.prior_parse_failures = 1
        acceptable.critic_requested = 10
        acceptable.critic_valid = 8
        self.assertFalse(HardStopMonitor().check_rates(acceptable).stop)
        unacceptable = RunMetrics("corrected_primary", "esconv", "train", 7)
        unacceptable.returned_sequences_by_role["prior"] = 100
        unacceptable.returned_sequences_by_role["system"] = 100
        unacceptable.prior_parse_failures = 11
        self.assertEqual(
            HardStopMonitor().check_rates(unacceptable).code,
            "prior_parse_failure_rate",
        )

    def test_twentieth_identical_reward_triggers(self):
        monitor = HardStopMonitor()
        for _ in range(19):
            monitor.reward_windows["train"].append(0.5)
        # The transition gate is separately tested by runtime tests; here isolate boundary state.
        monitor.reward_windows["train"].append(0.5)
        monitor.reward_windows["train"] = monitor.reward_windows["train"][-20:]
        if len(set(monitor.reward_windows["train"])) == 1:
            decision = monitor._trigger("reward_constant_20", reward=0.5)
        self.assertTrue(decision.stop)

    def test_operational_and_checkpoint_boundaries(self):
        monitor = HardStopMonitor()
        self.assertFalse(monitor.check_operational(
            disk_free=100, disk_reserve=100, heartbeat_age_seconds=120
        ).stop)
        self.assertEqual(HardStopMonitor().check_operational(
            disk_free=99, disk_reserve=100
        ).code, "disk_reserve")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "checkpoint.pt"
            path.write_bytes(b"x" * 25)
            self.assertFalse(HardStopMonitor().check_checkpoint(path, 25).stop)
            self.assertEqual(HardStopMonitor().check_checkpoint(path, 24).code,
                             "checkpoint_too_large")

    def test_all_role_parse_boundary_and_validation_guard(self):
        acceptable = RunMetrics("corrected_primary", "esconv", "valid", 7)
        acceptable.returned_sequences_by_role["system"] = 10
        acceptable.invalid_parses_by_role["system"] = 1
        self.assertFalse(HardStopMonitor().check_rates(acceptable).stop)
        rejected = RunMetrics("corrected_primary", "esconv", "valid", 7)
        rejected.returned_sequences_by_role["user"] = 10
        rejected.invalid_parses_by_role["user"] = 2
        self.assertEqual(HardStopMonitor().check_rates(rejected).code,
                         "all_generation_parse_failure_rate")
        runner = self.runner()
        for parameter in runner.online.parameters():
            parameter.data.zero_()
        records = runner.run_validation_block(label="baseline")
        self.assertLess(len(records), 20)
        self.assertEqual(runner.monitor.first_trigger.code, "zero_q_variance")

    def test_oom_third_event_and_aggregate_metrics(self):
        self.assertEqual(
            HardStopMonitor().record_oom(fail_closed_first=True).code,
            "gpu_oom_fail_closed_first",
        )
        monitor = HardStopMonitor()
        self.assertFalse(monitor.record_oom().stop)
        self.assertFalse(monitor.record_oom().stop)
        self.assertEqual(monitor.record_oom().code, "gpu_oom_three_times")
        runner = self.runner()
        runner.run_validation_block(label="baseline")
        runner.run_train_episode(0)
        runner.run_validation_block(label="post")
        report = runner.aggregate_report()
        self.assertEqual(report["validation_baseline"]["episodes"], 20)
        self.assertEqual(report["validation_post"]["episodes"], 20)
        for split in ("train", "validation_baseline", "validation_post"):
            self.assertIn("SR_better_or_solved", report[split])
            self.assertIn("strategy_selection", report[split])
            self.assertIn("q_reward_pairs", report[split])

    def test_validation_seeds_and_train_schedule_are_shared_across_arms(self):
        a0 = self.config("A0")
        a3 = self.config("A3")
        self.assertEqual(a0.fixed_validation_seeds, a3.fixed_validation_seeds)
        left = self.runner(a0)
        right = self.runner(a3)
        self.assertEqual(
            [left._case(self.train, index, "train")["_dx_case_id"] for index in range(20)],
            [right._case(self.train, index, "train")["_dx_case_id"] for index in range(20)],
        )
        left.run_validation_block(label="baseline")
        right.run_validation_block(label="baseline")
        expected = functional_seed(
            a0.fixed_validation_seeds[0], phase="valid", episode_id=0,
            case_id="esconv:valid:0", turn=0, role="emotion",
            rollout_id="p4a-shared-valid",
        )
        self.assertEqual(
            next(record.seed for record in left.backend.records
                 if record.episode_id == 0 and record.role == "emotion"),
            expected,
        )
        def shared(records):
            return [
                (record.episode_id, record.turn, record.role, record.seed)
                for record in records if record.role != "prior"
            ]
        self.assertEqual(shared(left.backend.records), shared(right.backend.records))

    def test_released_runtime_success_is_not_strict_solved(self):
        runner = self.runner(self.config("A1"))
        record = {
            "success": True, "cumulative_reward": 0.5, "wall_seconds": 1.0,
            "transitions": [{
                "candidate_actions": ["Question", "Others"],
                "selected_action": "Question", "all_q": [0.2, 0.1],
                "selected_action_index": 0, "reward": 0.5, "turn": 0,
                "critic": {"majority_label": "better"},
            }],
        }
        aggregate = runner._aggregate_records([record], None)
        self.assertEqual(aggregate["SR_better_or_solved"], 1.0)
        self.assertEqual(aggregate["SR_solved_only"], 0.0)
        self.assertEqual(aggregate["SR_runtime_protocol_success"], 1.0)

    def test_phase_a_gate_requires_and_accepts_complete_evidence(self):
        runner = self.runner()
        template = {
            "success": False, "cumulative_reward": -0.5,
            "transitions": [{"reward": -0.5}],
        }
        runner.state.episode_records = [
            {**template, "transitions": [{"reward": float(index % 2)}]}
            for index in range(20)
        ]
        runner.state.baseline_validation_records = [dict(template) for _ in range(20)]
        runner.state.validation_records = [dict(template) for _ in range(20)]
        runner.state.next_train_episode_id = 20
        runner.state.validation_isolation_passed = True
        runner.state.resume_probe_passed = True
        runner.state.checkpoints_written = 4
        runner.state.update_losses = [0.1]
        runner.state.gradient_norms = [0.2]
        runner.state.q_update_count = 20
        runner.state.target_sync_count = 20
        runner.valid_metrics = RunMetrics("corrected_primary", "esconv", "valid", 7)
        for metrics in (runner.train_metrics, runner.valid_metrics):
            metrics.critic_requested = 10
            metrics.critic_valid = 10
        gate = runner.phase_a_gate()
        self.assertTrue(gate["phase_b_authorized"], gate["reasons"])
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "phase_a_gate.json"
            path.write_text(json.dumps({
                "artifact_type": "p4_a_phase_a_gate_v1",
                "pilot_status": "COMPLETE",
                "pilot_config": runner.config.state_dict(),
                "gate": gate,
            }), encoding="utf-8")
            self.assertEqual(load_phase_a_gate_artifact(path), gate)
            payload = json.loads(path.read_text())
            payload["pilot_status"] = "STOPPED"
            path.write_text(json.dumps(payload), encoding="utf-8")
            with self.assertRaises(PermissionError):
                load_phase_a_gate_artifact(path)

    def test_phase_b_migrates_exact_episode_twenty_boundary(self):
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            code_state = {"commit": "unit", "dirty": False}
            phase_a = self.config("A2")
            source = self.runner(phase_a, directory=directory / "a")
            source.state.next_train_episode_id = 20
            checkpoint = source.save(
                directory / "phase-a-20.pt", code_state=code_state,
                task_log_run_id="unit",
            )
            ids, seeds = fixed_validation_contract(self.valid, 7)
            phase_b = PilotConfig(
                arm="A2", learning_rate=1e-4, phase="B", train_episodes=50,
                fixed_validation_case_ids=ids, fixed_validation_seeds=seeds,
            )
            authorization = {
                "phase_b_authorized": True, "arm": "A2",
                "learning_rate": 1e-4, "global_seed": 7,
                "phase_a_config": phase_a.state_dict(),
            }
            resumed = self.runner(
                phase_b, directory=directory / "b",
                phase_a_authorization=authorization,
            )
            resumed.restore_phase_b(checkpoint, expected_code_state=code_state)
            self.assertEqual(resumed.state.next_train_episode_id, 20)
            self.assertEqual(phase_b.epsilon(20), 0.1)

    def test_checkpoint_restores_complete_next_episode(self):
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            code_state = {"commit": "unit", "dirty": False}
            uninterrupted = self.runner(directory=directory / "a")
            uninterrupted.run_train_episode(0)
            checkpoint = uninterrupted.save(
                directory / "episode-0001.pt", code_state=code_state,
                task_log_run_id="unit",
            )
            resumed = self.runner(directory=directory / "b")
            resumed.restore(checkpoint, expected_code_state=code_state)
            left = uninterrupted.run_train_episode(1)
            right = resumed.run_train_episode(1)
            for key in ("case_id", "transitions", "loss", "online_after"):
                self.assertEqual(left[key], right[key])

    def test_test_split_fails_before_open(self):
        with self.assertRaises(SealedTestAccessError):
            load_split("esconv", "test")


if __name__ == "__main__":
    unittest.main()
