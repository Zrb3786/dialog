"""Safe replacement for the upstream auto-test training entry point."""

# DX-REPRO CHANGE 2026-07-16T06:28:17Z [DX-P1-020]
# Upstream: 7b35ec95, train_model.py:1-261 (module entry point)
# Reason: upstream imported undeclared chip, swallowed failures, and repeatedly evaluated test.
# Behavior: refuse legacy training and direct users to explicit split-safe scripts.


def main() -> int:
    raise SystemExit(
        "Legacy train_model.py is disabled on the corrected branch. "
        "Use scripts/run_esconv_smoke.sh or an explicit train/valid command; test remains sealed."
    )


if __name__ == "__main__":
    main()
