"""Safe future-command dispatcher for registered DialogXpert datasets.

Source: P0-P3 execution contract section 10.
Purpose: expose registry-based commands without manual source edits or test access.
Created: 2026-07-16T07:01:00Z.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

from dialogxpert_repro.registry import DatasetBlockedError, get_dataset, load_split


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("dataset")
    parser.add_argument("mode", choices=("smoke", "train", "valid", "final-test"))
    parser.add_argument("--track", default="corrected_primary")
    args = parser.parse_args()
    spec = get_dataset(args.dataset)

    if args.mode == "final-test":
        # DX-REPRO(P0): a token and frozen manifest are necessary but never
        # sufficient here; this P0-P3 branch deliberately has no test opener.
        supplied = bool(os.environ.get("DX_TEST_AUTH_TOKEN") and os.environ.get("DX_TEST_MANIFEST"))
        raise SystemExit(
            "BLOCKED: sealed final-test execution is not implemented on this branch; "
            f"authorization_material_supplied={supplied}"
        )

    try:
        if args.mode in {"train", "valid"}:
            records = load_split(spec.name, args.mode, behavior_track=args.track)
            result = {
                "dataset": spec.name,
                "mode": f"{args.mode}_dry_run_only",
                "track": args.track,
                "count": len(records),
                "status": "PASS",
            }
        else:
            train = load_split(spec.name, "train", behavior_track=args.track)
            valid = load_split(spec.name, "valid", behavior_track=args.track)
            result = {
                "dataset": spec.name,
                "mode": "smoke_preflight_only",
                "track": args.track,
                "train_case_ids": [item["_dx_case_id"] for item in train[:2]],
                "valid_case_ids": [item["_dx_case_id"] for item in valid[:3]],
                "status": "READY_NOT_EXECUTED",
            }
    except DatasetBlockedError as exc:
        result = {"dataset": spec.name, "mode": args.mode, "status": "BLOCKED", "reason": str(exc)}
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
