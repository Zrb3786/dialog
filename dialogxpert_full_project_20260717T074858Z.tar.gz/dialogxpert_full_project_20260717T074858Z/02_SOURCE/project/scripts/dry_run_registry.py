"""Train/valid-only dataset registry dry-run.

Source: P1 dataset acceptance requirements.
Purpose: verify safe counts, prompts, roles, and explicit ExTES blocking.
Created: 2026-07-16T06:28:17Z.
"""

from __future__ import annotations

import json

from dialogxpert_repro.registry import DATASETS, DatasetBlockedError, load_split


def main() -> None:
    result = {}
    for name in ("esconv", "cima", "cb", "p4g", "extes"):
        spec = DATASETS[name]
        if spec.blocked_reason:
            try:
                load_split(name, "train")
            except DatasetBlockedError as exc:
                result[name] = {"status": "BLOCKED", "reason": str(exc)}
            continue
        result[name] = {
            "status": "PASS",
            "train_count": len(load_split(name, "train")),
            "valid_count": len(load_split(name, "valid")),
            "actions": len(spec.action_inventory),
            "roles": [spec.system_role, spec.user_role],
            "critic_prompt": spec.critic_prompt,
        }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

