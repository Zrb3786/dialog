"""Resumable, revision-frozen background model downloader.

Source: P2 asset policy and approved Qwen2.5-14B execution instruction.
Purpose: stage one provider, enforce disk reserve, verify, and atomically publish.
Created: 2026-07-16T06:28:17Z.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import time
from pathlib import Path

from huggingface_hub import snapshot_download

from dialogxpert_repro.task_logging import TaskLog, utc_now
from scripts.verify_model_asset import verify_asset


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-id", required=True)
    parser.add_argument("--revision", required=True)
    parser.add_argument("--target", required=True)
    parser.add_argument("--provider", required=True)
    parser.add_argument("--estimated-gib", type=float, required=True)
    parser.add_argument("--reserve-gib", type=float, default=50.0)
    parser.add_argument("--root", required=True)
    parser.add_argument("--timestamp", required=True)
    parser.add_argument("--tmux-session", required=True)
    args = parser.parse_args()

    task = TaskLog(args.root, "model_download", args.timestamp)
    target = Path(args.target)
    staging = target.with_name(
        f"{target.name}.partial.{args.revision[:12]}.{args.provider.replace('/', '_')}"
    )
    state = {"stage": "preflight", "tmux_session": args.tmux_session, "gpu_id": "none"}
    stop, heartbeat = task.start_heartbeat(lambda: dict(state))
    try:
        free = shutil.disk_usage(target.parent).free
        required = int((args.reserve_gib + 1.10 * args.estimated_gib) * 1024**3)
        if free < required:
            raise RuntimeError(f"disk reserve failed: free={free} required={required}")
        if target.exists():
            raise RuntimeError(f"final target already exists: {target}")
        staging.mkdir(parents=True, exist_ok=True)
        marker = staging / ".dx-download.json"
        expected_marker = {
            "repo_id": args.repo_id,
            "revision": args.revision,
            "provider": args.provider,
        }
        if marker.exists() and json.loads(marker.read_text(encoding="utf-8")) != expected_marker:
            raise RuntimeError("staging directory belongs to a different provider/revision")
        marker.write_text(json.dumps(expected_marker, indent=2, sort_keys=True), encoding="utf-8")
        task.write_environment(
            {
                **expected_marker,
                "endpoint": os.environ.get("HF_ENDPOINT", ""),
                "python": os.sys.executable,
                "target": target,
            }
        )
        task.write_status(status="RUNNING", stage="download", pid=os.getpid(), target=str(target))
        state["stage"] = "download"
        last_error: Exception | None = None
        for attempt in range(1, 4):
            try:
                task.logger.info("download attempt=%s repo=%s revision=%s", attempt, args.repo_id, args.revision)
                snapshot_download(
                    repo_id=args.repo_id,
                    revision=args.revision,
                    local_dir=staging,
                    max_workers=4,
                )
                # DX-REPRO(P2): some Hub clients return an existing local_dir
                # after a transport failure. Treat an incomplete snapshot as a
                # retryable download error rather than proceeding to publish.
                verify_asset(staging, full_hash=False)
                last_error = None
                break
            except Exception as exc:
                last_error = exc
                task.logger.exception("download attempt %s failed", attempt)
                if attempt < 3:
                    time.sleep(15 * attempt)
        if last_error is not None:
            raise last_error
        state["stage"] = "verify"
        task.write_status(status="RUNNING", stage="verify", pid=os.getpid(), target=str(target))
        manifest = verify_asset(staging, full_hash=True)
        complete = {
            **expected_marker,
            "completed_at": utc_now(),
            "manifest": manifest,
        }
        (staging / ".complete.json").write_text(
            json.dumps(complete, indent=2, sort_keys=True), encoding="utf-8"
        )
        staging.replace(target)
        with (task.directory / "artifact_manifest.tsv").open("a", encoding="utf-8") as handle:
            for record in manifest["shards"]:
                handle.write(
                    f"{target / record['name']}\t{record['size']}\t{record['sha256']}\tPASS\n"
                )
        state["stage"] = "complete"
        task.write_status(status="COMPLETE", stage="complete", pid=os.getpid(), target=str(target))
        task.logger.info("download complete target=%s", target)
    except Exception as exc:
        state["stage"] = "failed"
        task.write_status(status="FAILED", stage="failed", pid=os.getpid(), error=repr(exc))
        task.logger.exception("model download failed")
        raise
    finally:
        stop.set()
        heartbeat.join(timeout=5)


if __name__ == "__main__":
    main()
