#!/usr/bin/env python3
"""Observable offline-local P3.6 critic and prior audit entry point."""

from __future__ import annotations

import argparse
import os
import shlex
import sys

import torch

from dialogxpert_repro.calibration import run_critic_calibration
from dialogxpert_repro.prior_audit import run_prior_coverage_audit
from dialogxpert_repro.smoke import run_p3_5_live_semantic_suite
from dialogxpert_repro.task_logging import TaskLog


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("kind", choices=("critic", "prior", "live"))
    parser.add_argument("--repo-root", required=True)
    parser.add_argument("--timestamp", required=True)
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--bert-path")
    parser.add_argument("--calibration-result")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--tmux-session", required=True)
    args = parser.parse_args()
    task = f"p3_6_{args.kind}_audit"
    log = TaskLog(
        args.repo_root, task, args.timestamp,
        context={"kind": args.kind, "pid": os.getpid(), "device": args.device,
                 "tmux_session": args.tmux_session},
    )
    argv = " ".join(shlex.quote(value) for value in sys.argv)
    inner = (
        f"cd {shlex.quote(args.repo_root)} && export "
        f"CUDA_VISIBLE_DEVICES={shlex.quote(os.environ.get('CUDA_VISIBLE_DEVICES', ''))} "
        "HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONPATH=. PYTHONUNBUFFERED=1 && "
        f"{shlex.quote(sys.executable)} {argv} >> "
        f"{shlex.quote(str(log.directory / 'stdout.log'))} 2>> "
        f"{shlex.quote(str(log.directory / 'stderr.log'))}"
    )
    log.write_command(
        f"tmux new-session -d -s {shlex.quote(args.tmux_session)} {shlex.quote(inner)}"
    )
    log.write_environment({
        "python": sys.executable,
        "torch": torch.__version__,
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES", ""),
        "hf_hub_offline": os.environ.get("HF_HUB_OFFLINE", ""),
        "transformers_offline": os.environ.get("TRANSFORMERS_OFFLINE", ""),
        "model_path": args.model_path,
        "bert_path": args.bert_path or "not-used",
    })
    progress = {
        "stage": "initializing",
        "episode": "not_applicable_audit",
        "turn": "not_applicable_audit",
        "q_updates": 0,
        "replay_size": 0,
        "phase": args.kind,
        "gpu_memory_allocated": 0,
        "last_reward": "not_applicable_audit",
        "last_loss": "not_applicable_audit",
        "parse_failures": 0,
    }
    def heartbeat_state():
        values = dict(progress)
        if torch.cuda.is_available():
            values["gpu_memory_allocated"] = int(torch.cuda.memory_allocated())
        return values
    stop, heartbeat = log.start_heartbeat(heartbeat_state, interval_seconds=60)
    log.write_status(status="RUNNING", stage="initializing")
    try:
        progress["stage"] = "model_audit"
        output = log.directory / "artifacts"
        if args.kind == "critic":
            result = run_critic_calibration(
                output_dir=output, model_path=args.model_path, device=args.device
            )
        elif args.kind == "prior":
            if not args.bert_path:
                raise ValueError("--bert-path is required for prior audit")
            result = run_prior_coverage_audit(
                output_dir=output, model_path=args.model_path,
                bert_path=args.bert_path, device=args.device,
            )
        else:
            if not args.bert_path or not args.calibration_result:
                raise ValueError("--bert-path and --calibration-result are required for live")
            result = run_p3_5_live_semantic_suite(
                repo_root=args.repo_root, output_dir=output,
                model_path=args.model_path, bert_path=args.bert_path,
                calibration_result=args.calibration_result, device=args.device,
                progress_callback=lambda values: progress.update(values),
            )
        progress["stage"] = "complete"
        log.write_status(status="COMPLETE", stage="complete",
                         result_status=result["status"])
    except Exception as exc:
        progress["stage"] = "failed"
        log.logger.exception("P3.6 audit failed")
        log.write_status(status="FAILED", stage="failed", error=repr(exc))
        raise
    finally:
        stop.set()
        heartbeat.join(5)
        log.finalize_artifact_manifest()
        log.flush()
        log.close()


if __name__ == "__main__":
    main()
