#!/usr/bin/env python3
"""Create the preregistered P4-A config envelopes without starting a pilot."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from dialogxpert_repro.p4_pilot import PilotConfig, fixed_validation_contract
from dialogxpert_repro.registry import load_split


ARMS_AND_LRS = (
    ("A0", 1e-4),
    ("A1", 1e-6),
    ("A1", 1e-4),
    ("A2", 1e-6),
    ("A2", 1e-4),
    ("A3", 1e-4),
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    root = Path(args.repo_root).resolve()
    output = Path(args.output_dir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    valid = load_split("esconv", "valid", repo_root=root)[:20]
    registry = []
    for arm, learning_rate in ARMS_AND_LRS:
        ids, seeds = fixed_validation_contract(valid, 7)
        for phase, episodes in (("A", 20), ("B", 50)):
            config = PilotConfig(
                arm=arm, learning_rate=learning_rate,
                phase=phase, train_episodes=episodes,
                fixed_validation_case_ids=ids,
                fixed_validation_seeds=seeds,
            )
            suffix = "1e-6" if learning_rate == 1e-6 else "1e-4"
            path = output / f"phase_{phase.lower()}_{arm.lower()}_lr_{suffix}.json"
            payload = json.dumps(config.state_dict(), indent=2, sort_keys=True) + "\n"
            path.write_text(payload, encoding="utf-8")
            registry.append({
                "phase": phase, "arm": arm, "learning_rate": learning_rate,
                "path": path.name, "pilot_config_sha256": config.sha256,
                "file_sha256": hashlib.sha256(payload.encode("utf-8")).hexdigest(),
            })
    (output / "registry.json").write_text(
        json.dumps({"status": "PREREGISTERED_NOT_AUTHORIZED", "configs": registry},
                   indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
