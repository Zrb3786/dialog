"""CLI for scripted and local-Qwen bounded P3 smoke.

Source: P1.5/P3 execution contract.
Purpose: provide one real corrected runtime entry point and checkpoint verifier.
Created: 2026-07-16T08:02:00Z.
"""

from __future__ import annotations

import argparse

from dialogxpert_repro.calibration import run_critic_calibration

from dialogxpert_repro.smoke import (
    run_live_suite,
    run_p3_5_live_semantic_suite,
    run_scripted_suite,
    verify_checkpoint_next_update,
    write_json,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)
    scripted = subparsers.add_parser("scripted")
    scripted.add_argument("--repo-root", required=True)
    scripted.add_argument("--output", required=True)
    live = subparsers.add_parser("live")
    live.add_argument("--repo-root", required=True)
    live.add_argument("--timestamp", required=True)
    live.add_argument("--model-path", required=True)
    live.add_argument("--bert-path", required=True)
    live.add_argument("--device", default="cuda:0")
    verify = subparsers.add_parser("verify-checkpoint")
    verify.add_argument("--checkpoint", required=True)
    verify.add_argument("--contract", required=True)
    verify.add_argument("--output", required=True)
    # DX-REPRO CHANGE 2026-07-17T02:51:00Z [DX-P3_5-014]
    # Base: 6ea4d579, scripts/run_p3_smoke.py:main
    # Reason: old live smoke could not isolate critic calibration from Q updates.
    # Behavior: expose a bounded local-only C0/C1/C2 calibration entry point.
    calibration = subparsers.add_parser("critic-calibration")
    calibration.add_argument("--output", required=True)
    calibration.add_argument("--model-path", required=True)
    calibration.add_argument("--device", default="cuda:0")
    # DX-REPRO CHANGE 2026-07-17T02:54:00Z [DX-P3_5-015]
    # Base: 6ea4d579, scripts/run_p3_smoke.py:main
    # Reason: P3.5 needs a corrected-only calibrated semantic live gate.
    # Behavior: expose 5+5 CLS smoke plus masked-mean ablation.
    semantic = subparsers.add_parser("p3-5-live")
    semantic.add_argument("--repo-root", required=True)
    semantic.add_argument("--output", required=True)
    semantic.add_argument("--model-path", required=True)
    semantic.add_argument("--bert-path", required=True)
    semantic.add_argument("--calibration-result", required=True)
    semantic.add_argument("--device", default="cuda:0")
    args = parser.parse_args()
    if args.command == "scripted":
        run_scripted_suite(args.repo_root, args.output)
    elif args.command == "live":
        run_live_suite(
            repo_root=args.repo_root,
            timestamp=args.timestamp,
            model_path=args.model_path,
            bert_path=args.bert_path,
            device=args.device,
        )
    elif args.command == "verify-checkpoint":
        write_json(
            args.output,
            verify_checkpoint_next_update(args.checkpoint, args.contract),
        )
    elif args.command == "critic-calibration":
        run_critic_calibration(
            output_dir=args.output,
            model_path=args.model_path,
            device=args.device,
        )
    else:
        run_p3_5_live_semantic_suite(
            repo_root=args.repo_root,
            output_dir=args.output,
            model_path=args.model_path,
            bert_path=args.bert_path,
            calibration_result=args.calibration_result,
            device=args.device,
        )


if __name__ == "__main__":
    main()
