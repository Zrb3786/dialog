"""Verify a local Hugging Face-style model asset without loading weights.

Source: P2 model-asset policy.
Purpose: check required metadata, index-to-shard completeness, sizes, and hashes.
Created: 2026-07-16T06:28:17Z.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


REQUIRED = (
    "config.json",
    "tokenizer_config.json",
    "model.safetensors.index.json",
    "LICENSE",
    "README.md",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_asset(path: str | Path, *, full_hash: bool = False) -> dict[str, Any]:
    root = Path(path)
    missing = [name for name in REQUIRED if not (root / name).is_file()]
    if missing:
        raise RuntimeError(f"missing required model files: {missing}")
    index = json.loads((root / "model.safetensors.index.json").read_text(encoding="utf-8"))
    shards = sorted(set(index["weight_map"].values()))
    shard_records = []
    for name in shards:
        shard = root / name
        if not shard.is_file() or shard.stat().st_size <= 0:
            raise RuntimeError(f"missing or empty shard: {name}")
        shard_records.append(
            {
                "name": name,
                "size": shard.stat().st_size,
                "sha256": sha256(shard) if full_hash else None,
            }
        )
    metadata = {}
    for name in REQUIRED + ("generation_config.json", "tokenizer.json", "vocab.json", "merges.txt"):
        file = root / name
        if file.is_file():
            metadata[name] = {"size": file.stat().st_size, "sha256": sha256(file)}
    return {
        "path": str(root.resolve()),
        "status": "PASS",
        "shards": shard_records,
        "metadata": metadata,
        "total_shard_size": sum(record["size"] for record in shard_records),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("path")
    parser.add_argument("--full-hash", action="store_true")
    args = parser.parse_args()
    print(json.dumps(verify_asset(args.path, full_hash=args.full_hash), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

