#!/usr/bin/env bash
set -euo pipefail

ROOT="/data1/zhangruibo/projects/dialog/dialogxpert"
PYTHON="/data1/zhangruibo/conda_envs/dialogxpert_qwen_v2/bin/python"
MODEL="/data1/zhangruibo/models/Qwen2.5-7B-Instruct"
BERT="/data1/zhangruibo/models/hf_cache/git_lfs_tmp_20260708_164346/bert-base-uncased"
SESSION="dx_esconv_7b_smoke"
GPU="${1:?usage: tmux_live_esconv.sh <physical-gpu-id> [UTC timestamp]}"
TIMESTAMP="${2:-$(date -u +%Y%m%dT%H%M%SZ)}"
LOG_DIR="$ROOT/logs/esconv_smoke/$TIMESTAMP"

if tmux has-session -t "$SESSION" 2>/dev/null; then
  echo "tmux session already exists: $SESSION" >&2
  exit 2
fi
FREE_MIB="$(nvidia-smi --id="$GPU" --query-gpu=memory.free --format=csv,noheader,nounits | tr -d ' ')"
if (( FREE_MIB < 56320 )); then
  echo "BLOCKED: GPU $GPU has ${FREE_MIB} MiB free; BF16 gate requires 56320 MiB" >&2
  exit 3
fi
mkdir -p "$LOG_DIR"
COMMAND="CUDA_VISIBLE_DEVICES=$GPU HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONPATH=$ROOT $PYTHON $ROOT/scripts/run_p3_smoke.py live --repo-root $ROOT --timestamp $TIMESTAMP --model-path $MODEL --bert-path $BERT --device cuda:0"
printf '%s\n' "$COMMAND" >"$LOG_DIR/command.sh"
chmod 600 "$LOG_DIR/command.sh"
tmux new-session -d -s "$SESSION" \
  "exec env CUDA_VISIBLE_DEVICES=$GPU HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=$ROOT PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True $PYTHON $ROOT/scripts/run_p3_smoke.py live --repo-root $ROOT --timestamp $TIMESTAMP --model-path $MODEL --bert-path $BERT --device cuda:0 >>$LOG_DIR/launcher_stdout.log 2>>$LOG_DIR/launcher_stderr.log"
sleep 2
PID="$(tmux display-message -p -t "$SESSION" '#{pane_pid}')"
printf 'TIMESTAMP=%s\nTMUX=%s\nPID=%s\nGPU=%s\nFREE_MIB=%s\nLOG=%s\n' \
  "$TIMESTAMP" "$SESSION" "$PID" "$GPU" "$FREE_MIB" "$LOG_DIR"
