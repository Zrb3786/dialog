#!/usr/bin/env bash
set -euo pipefail
ROOT="/data1/zhangruibo/projects/dialog/dialogxpert"
PYTHON="/data1/zhangruibo/conda_envs/dialogxpert_qwen/bin/python"
if [[ ! -x "$PYTHON" ]]; then
  echo "BLOCKED: target environment Python is unavailable: $PYTHON" >&2
  exit 3
fi
exec env PYTHONPATH="$ROOT" "$PYTHON" "$ROOT/scripts/run_dataset_command.py" "$@"
