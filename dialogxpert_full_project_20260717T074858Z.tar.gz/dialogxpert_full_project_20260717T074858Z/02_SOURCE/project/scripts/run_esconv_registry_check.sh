#!/usr/bin/env bash
exec "$(dirname "$0")/run_dataset_command.sh" esconv smoke "$@"
