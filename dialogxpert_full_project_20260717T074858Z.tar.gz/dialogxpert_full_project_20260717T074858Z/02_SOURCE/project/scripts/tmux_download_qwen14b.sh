#!/usr/bin/env bash
set -euo pipefail

ROOT="/data1/zhangruibo/projects/dialog/dialogxpert"
PYTHON="/data1/zhangruibo/conda_envs/qwen_multiesc_lf/bin/python"
SESSION="dx_qwen14b_download"
TIMESTAMP="${1:-$(date -u +%Y%m%dT%H%M%SZ)}"
LOG_DIR="$ROOT/logs/model_download/$TIMESTAMP"
REVISION="cf98f3b3bbb457ad9e2bb7baf9a0125b6b88caa8"
TARGET="/data1/zhangruibo/models/Qwen2.5-14B-Instruct"

if tmux has-session -t "$SESSION" 2>/dev/null; then
  echo "tmux session already exists: $SESSION" >&2
  exit 2
fi
mkdir -p "$LOG_DIR"
COMMAND="HF_ENDPOINT=https://hf-mirror.com PYTHONPATH=$ROOT $PYTHON $ROOT/scripts/download_model_asset.py --repo-id Qwen/Qwen2.5-14B-Instruct --revision $REVISION --target $TARGET --provider hf-mirror --estimated-gib 31 --reserve-gib 50 --root $ROOT --timestamp $TIMESTAMP --tmux-session $SESSION"
printf '%s\n' "$COMMAND" >"$LOG_DIR/command.sh"
chmod 600 "$LOG_DIR/command.sh"
tmux new-session -d -s "$SESSION" "exec env HF_ENDPOINT=https://hf-mirror.com PYTHONPATH=$ROOT $PYTHON $ROOT/scripts/download_model_asset.py --repo-id Qwen/Qwen2.5-14B-Instruct --revision $REVISION --target $TARGET --provider hf-mirror --estimated-gib 31 --reserve-gib 50 --root $ROOT --timestamp $TIMESTAMP --tmux-session $SESSION >>$LOG_DIR/stdout.log 2>>$LOG_DIR/stderr.log"
sleep 2
PID="$(tmux display-message -p -t "$SESSION" '#{pane_pid}')"
printf 'TIMESTAMP=%s\nTMUX=%s\nPID=%s\nLOG=%s\n' "$TIMESTAMP" "$SESSION" "$PID" "$LOG_DIR"

