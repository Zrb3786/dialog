#!/usr/bin/env bash
set -euo pipefail
ROOT="/data1/zhangruibo/projects/dialog/dialogxpert"
PYTHON="/data1/zhangruibo/conda_envs/dialogxpert_qwen_v2/bin/python"
if [[ ! -x "$PYTHON" ]]; then
  echo "BLOCKED: recovered environment is unavailable: $PYTHON" >&2
  exit 3
fi
exec env PYTHONPATH="$ROOT" HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
  "$PYTHON" "$ROOT/scripts/run_p3_smoke.py" "$@"
