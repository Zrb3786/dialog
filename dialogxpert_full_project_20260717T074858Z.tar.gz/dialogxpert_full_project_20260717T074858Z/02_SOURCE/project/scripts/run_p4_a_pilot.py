#!/usr/bin/env python3
"""Authorized, offline-local entry point for one bounded P4-A arm.

This script is intentionally fail-closed: having the code present is not an
authorization to run it. The literal external-review marker is mandatory.
"""

from __future__ import annotations

import argparse
import json
import os
import shlex
import sys
import time
from dataclasses import asdict
from pathlib import Path

import torch

from dialogxpert_repro.backend import TransformersLocalBackend
from dialogxpert_repro.p4_pilot import (
    P4APilotRunner,
    PilotConfig,
    require_gate_authorization,
    require_single_gpu,
    load_phase_a_gate_artifact,
)
from dialogxpert_repro.qnet import FrozenBertEncoder
from dialogxpert_repro.registry import get_dataset, load_split
from dialogxpert_repro.smoke import git_code_state, write_json, write_jsonl
from dialogxpert_repro.task_logging import TaskLog


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", required=True)
    parser.add_argument("--timestamp", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--authorization-marker", required=True)
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--bert-path", required=True)
    parser.add_argument("--tmux-session", required=True)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--resume")
    parser.add_argument("--phase-a-gate")
    args = parser.parse_args()

    require_gate_authorization(args.authorization_marker)
    require_single_gpu(args.device, os.environ.get("CUDA_VISIBLE_DEVICES", ""))
    if os.environ.get("HF_HUB_OFFLINE") != "1" or (
        os.environ.get("TRANSFORMERS_OFFLINE") != "1"
    ):
        raise RuntimeError("P4-A requires HF_HUB_OFFLINE=1 and TRANSFORMERS_OFFLINE=1")
    root = Path(args.repo_root).resolve()
    model = Path(args.model_path).resolve()
    bert = Path(args.bert_path).resolve()
    if not model.is_dir() or not bert.is_dir():
        raise RuntimeError("local Qwen7/BERT asset is missing; network fallback is forbidden")
    envelope = json.loads(Path(args.config).read_text(encoding="utf-8"))
    config = PilotConfig.from_state_dict(envelope)
    phase_a_gate = None
    if config.phase == "B":
        if not args.phase_a_gate:
            raise PermissionError("Phase B requires a Phase-A gate artifact")
        phase_a_gate = load_phase_a_gate_artifact(args.phase_a_gate)

    code_state = git_code_state(root)
    log = TaskLog(
        root, "p4_a_pilot", args.timestamp,
        context={
            "arm": config.arm, "phase": config.phase,
            "pilot_config_sha256": config.sha256,
            "protocol_name": config.protocol_name,
            "protocol_hash": config.protocol_hash,
            "pid": os.getpid(), "tmux_session": args.tmux_session,
            "device": args.device,
        },
    )
    argv = " ".join(shlex.quote(value) for value in sys.argv)
    inner = (
        f"cd {shlex.quote(str(root))} && export "
        f"CUDA_VISIBLE_DEVICES={shlex.quote(os.environ.get('CUDA_VISIBLE_DEVICES', ''))} "
        "HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONPATH=. PYTHONUNBUFFERED=1 && "
        f"{shlex.quote(sys.executable)} {argv} >> "
        f"{shlex.quote(str(log.directory / 'stdout.log'))} 2>> "
        f"{shlex.quote(str(log.directory / 'stderr.log'))}"
    )
    log.write_command(
        f"tmux new-session -d -s {shlex.quote(args.tmux_session)} {shlex.quote(inner)}"
    )
    log.write_environment({
        "python": sys.executable, "torch": torch.__version__,
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES", ""),
        "hf_hub_offline": os.environ.get("HF_HUB_OFFLINE", ""),
        "transformers_offline": os.environ.get("TRANSFORMERS_OFFLINE", ""),
        "model_path": str(model), "bert_path": str(bert),
        "code_commit": code_state["commit"], "code_dirty": code_state["dirty"],
    })
    progress = {
        "stage": "initializing", "episode": 0, "turn": 0, "q_updates": 0,
        "replay_size": 0, "phase": config.phase, "gpu_memory_allocated": 0,
        "last_reward": None, "last_loss": None, "parse_failures": 0,
        "peak_gpu_memory_allocated": 0,
    }
    run_started = time.perf_counter()

    runner_holder = {"runner": None, "last_heartbeat": time.monotonic()}

    def heartbeat_state():
        runner_holder["last_heartbeat"] = time.monotonic()
        runner = runner_holder["runner"]
        if runner is not None:
            runner.operational_gate(heartbeat_age_seconds=0.0)
        value = dict(progress)
        if torch.cuda.is_available():
            value["gpu_memory_allocated"] = int(torch.cuda.memory_allocated())
            progress["peak_gpu_memory_allocated"] = max(
                int(progress["peak_gpu_memory_allocated"]),
                int(value["gpu_memory_allocated"]),
            )
        return value

    stop, heartbeat = log.start_heartbeat(heartbeat_state, interval_seconds=60)
    log.write_status(status="RUNNING", stage="initializing")
    try:
        backend = TransformersLocalBackend(
            model, device=args.device, seed=config.global_seed,
            dtype="bfloat16", max_retries=2,
        )
        encoder = FrozenBertEncoder(bert, device=config.bert_device, pooling="cls")
        train = load_split("esconv", "train", repo_root=root)
        valid = load_split("esconv", "valid", repo_root=root)[:20]
        runner = P4APilotRunner(
            repo_root=root, output_dir=log.directory / "artifacts",
            spec=get_dataset("esconv"), train_cases=train, valid_cases=valid,
            backend=backend, encoder=encoder, config=config, device=args.device,
            phase_a_authorization=phase_a_gate,
        )
        runner_holder["runner"] = runner
        if args.resume:
            if config.phase == "B":
                runner.restore_phase_b(args.resume, expected_code_state=code_state)
            else:
                runner.restore(args.resume, expected_code_state=code_state)
        elif config.phase == "B":
            raise PermissionError("Phase B must resume the authorized episode-20 checkpoint")
        decision = runner.operational_gate()
        checkpoint_dir = log.directory / "artifacts" / "checkpoints"
        checkpoint_dir.mkdir(parents=True, exist_ok=True)
        if (
            not decision.stop and config.phase == "A"
            and runner.state.next_train_episode_id == 0
            and not runner.state.baseline_validation_records
        ):
            progress["stage"] = "validation_baseline"
            runner.run_validation_block(label="baseline")
            runner.operational_gate(
                heartbeat_age_seconds=time.monotonic()
                - runner_holder["last_heartbeat"]
            )
        while (
            runner.monitor.first_trigger is None
            and runner.state.next_train_episode_id < config.train_episodes
        ):
            episode_id = runner.state.next_train_episode_id
            progress.update(stage="train", episode=episode_id,
                            replay_size=len(runner.train_replay))
            try:
                record = runner.run_train_episode(episode_id)
            except torch.cuda.OutOfMemoryError:
                torch.cuda.empty_cache()
                oom = runner.monitor.record_oom(fail_closed_first=True)
                log.write_status(
                    status="STOPPED", stage="hard_stop",
                    oom_count=runner.monitor.oom_count,
                )
                break
            progress.update(
                q_updates=runner.state.q_update_count,
                replay_size=len(runner.train_replay),
                last_reward=record["cumulative_reward"],
                last_loss=record["loss"],
                parse_failures=runner.train_metrics.parse_failures,
            )
            if runner.monitor.first_trigger is not None:
                break
            runner.operational_gate(
                heartbeat_age_seconds=time.monotonic()
                - runner_holder["last_heartbeat"]
            )
            if runner.monitor.first_trigger is not None:
                break
            if runner.checkpoint_due:
                checkpoint = runner.save(
                    checkpoint_dir / f"episode-{runner.state.next_train_episode_id:04d}.pt",
                    code_state=code_state, task_log_run_id=args.timestamp,
                )
                if runner.monitor.first_trigger is None:
                    runner.verify_checkpoint_roundtrip(
                        checkpoint, expected_code_state=code_state
                    )
                runner.operational_gate(
                    heartbeat_age_seconds=time.monotonic()
                    - runner_holder["last_heartbeat"]
                )
                if runner.monitor.first_trigger is not None:
                    log.flush()
                    break
            log.flush()
        if runner.monitor.first_trigger is None:
            progress["stage"] = "validation_post"
            runner.run_validation_block(label="post")
            runner.operational_gate(
                heartbeat_age_seconds=time.monotonic()
                - runner_holder["last_heartbeat"]
            )
        generation_path = write_jsonl(
            log.directory / "artifacts" / "generation_records.jsonl",
            [asdict(record) for record in backend.records],
        )
        episode_path = write_jsonl(
            log.directory / "artifacts" / "episode_records.jsonl",
            runner.state.baseline_validation_records
            + runner.state.episode_records
            + runner.state.validation_records,
        )
        gate = runner.phase_a_gate() if config.phase == "A" else {
            "phase": "B", "complete": runner.monitor.first_trigger is None,
            "pilot_config_sha256": config.sha256,
        }
        gate_artifact_path = None
        if config.phase == "A":
            gate_artifact_path = write_json(
                log.directory / "artifacts" / "phase_a_gate.json",
                {
                    "artifact_type": "p4_a_phase_a_gate_v1",
                    "pilot_status": (
                        "STOPPED" if runner.monitor.first_trigger else "COMPLETE"
                    ),
                    "pilot_config": config.state_dict(),
                    "gate": gate,
                },
            )
        result = {
            "status": "STOPPED" if runner.monitor.first_trigger else "COMPLETE",
            "config": config.state_dict(), "gate": gate,
            "stop_monitor": runner.monitor.state_dict(),
            "train_metrics": runner.train_metrics.summary(),
            "valid_metrics": (
                runner.valid_metrics.summary() if runner.valid_metrics else None
            ),
            "baseline_metrics": (
                runner.baseline_metrics.summary() if runner.baseline_metrics else None
            ),
            "aggregates": runner.aggregate_report(),
            "resources": {
                "wall_seconds": time.perf_counter() - run_started,
                "peak_gpu_memory_allocated": progress["peak_gpu_memory_allocated"],
                "device": args.device,
                "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES", ""),
            },
            "state": asdict(runner.state),
            "generation_records": str(generation_path),
            "episode_records": str(episode_path),
            "phase_a_gate_artifact": (
                str(gate_artifact_path) if gate_artifact_path else None
            ),
        }
        write_json(log.directory / "artifacts" / "pilot_result.json", result)
        if runner.monitor.first_trigger:
            progress["stage"] = "stopped"
            log.write_status(
                status="STOPPED", stage="hard_stop",
                stop=asdict(runner.monitor.first_trigger),
            )
        else:
            progress["stage"] = "complete"
            log.write_status(status="COMPLETE", stage="complete")
    except Exception as exc:
        progress["stage"] = "failed"
        log.logger.exception("P4-A pilot failed closed")
        log.write_status(status="FAILED", stage="failed", error=repr(exc))
        raise
    finally:
        stop.set()
        heartbeat.join(5)
        log.finalize_artifact_manifest()
        log.flush()
        log.close()


if __name__ == "__main__":
    main()
