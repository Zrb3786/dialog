"""Filesystem and network safety guards for DialogXpert reproduction.

Source: local P0 data policy and upstream loader audit.
Purpose: reject test or aggregate data paths before filesystem access.
Created: 2026-07-16T06:28:17Z.
"""

from __future__ import annotations

from pathlib import Path


class SealedTestAccessError(RuntimeError):
    """Raised before a sealed or test-associated data path is touched."""


ALLOWED_DEVELOPMENT_SPLITS = frozenset({"train", "valid", "dev"})
BLOCKED_AGGREGATES = frozenset(
    {
        "data/ExTES/ExTES.json",
        "data/P4G/original_data/dialog_all.json",
    }
)


def assert_development_split(split: str) -> str:
    normalized = split.strip().lower()
    if normalized not in ALLOWED_DEVELOPMENT_SPLITS:
        raise SealedTestAccessError(
            f"split {split!r} is sealed; allowed={sorted(ALLOWED_DEVELOPMENT_SPLITS)}"
        )
    return normalized


def assert_safe_data_path(path: str | Path, repo_root: str | Path) -> Path:
    """Validate a data path lexically without statting or opening it."""

    candidate = Path(path)
    lexical_parts = tuple(part.lower() for part in candidate.parts)
    if any("test" in part for part in lexical_parts):
        raise SealedTestAccessError(f"test-associated path is sealed: {path}")
    if any("dialog_all" in part for part in lexical_parts):
        raise SealedTestAccessError(f"aggregate path is sealed: {path}")
    root = Path(repo_root).resolve()
    if not candidate.is_absolute():
        candidate = root / candidate
    normalized = candidate.resolve(strict=False)
    try:
        relative = normalized.relative_to(root)
    except ValueError as exc:
        raise SealedTestAccessError(f"data path escapes repository: {path}") from exc

    lowered_parts = tuple(part.lower() for part in relative.parts)
    if any("test" in part for part in lowered_parts):
        raise SealedTestAccessError(f"test-associated path is sealed: {relative}")
    if any("dialog_all" in part for part in lowered_parts):
        raise SealedTestAccessError(f"aggregate path is sealed: {relative}")
    if relative.as_posix() in BLOCKED_AGGREGATES:
        raise SealedTestAccessError(f"blocked aggregate path: {relative}")
    return normalized
