"""Functional episode-addressable seeds for generation and action selection.

Source: P3.6 resume and validation-coupling review.
Purpose: make stochastic streams pure functions of semantic episode coordinates.
Created: 2026-07-17T04:55:00Z.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any


SEED_PROTOCOL_VERSION = "episode-addressable-v1"


def functional_seed(global_seed: int, *, phase: str, episode_id: int, case_id: str,
                    turn: int, role: str, attempt: int = 1,
                    sequence_index: int = 0, rollout_id: str = "primary") -> int:
    payload: list[Any] = [SEED_PROTOCOL_VERSION, int(global_seed), phase,
                          int(episode_id), case_id, int(turn), role, int(attempt),
                          int(sequence_index), rollout_id]
    digest = hashlib.sha256(
        json.dumps(payload, ensure_ascii=True, separators=(",", ":")).encode()
    ).digest()
    return int.from_bytes(digest[:8], "big") % (2**63 - 1)
