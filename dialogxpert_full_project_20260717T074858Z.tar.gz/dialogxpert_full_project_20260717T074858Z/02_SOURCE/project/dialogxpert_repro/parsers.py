"""Strict structured-output parsers for corrected and prompt-faithful tracks.

Source: external P1.5 review of legacy substring slicing.
Purpose: reject duplicate, reordered, empty, or extra emotion/response fields.
Created: 2026-07-16T07:44:00Z.
"""

from __future__ import annotations

import json
import re
from typing import Any


class StructuredOutputError(ValueError):
    """A countable backend parse failure retaining the raw completion."""

    def __init__(self, message: str, raw_output: str):
        super().__init__(message)
        self.raw_output = raw_output


def parse_emotion_json(raw_output: str) -> dict[str, str]:
    text = raw_output.strip()
    try:
        value: Any = json.loads(text)
    except json.JSONDecodeError as exc:
        raise StructuredOutputError("emotion output is not one JSON object", raw_output) from exc
    if not isinstance(value, dict) or set(value) != {"raw", "normalized"}:
        raise StructuredOutputError(
            "emotion JSON must contain exactly raw and normalized", raw_output
        )
    raw = value["raw"]
    normalized = value["normalized"]
    if not isinstance(raw, str) or not isinstance(normalized, str):
        raise StructuredOutputError("emotion fields must be strings", raw_output)
    raw = raw.strip()
    normalized = normalized.strip().casefold()
    if not raw or not normalized or len(normalized) > 64 or "\n" in normalized:
        raise StructuredOutputError("emotion fields are empty or invalid", raw_output)
    return {"raw": raw, "normalized": normalized}


_COUPLED = re.compile(
    r"\AEmotion:[ \t]*([^\r\n]+)\r?\n(?:[ \t]*\r?\n)*Response:[ \t]*(.+)\Z",
    flags=re.DOTALL,
)


def parse_coupled_emotion_response(raw_output: str) -> tuple[dict[str, str], str]:
    # DX-REPRO CHANGE 2026-07-17T02:45:00Z [DX-P3_5-007]
    # Base: 6ea4d579, parsers.py:parse_coupled_emotion_response
    # Reason: harmless blank lines caused false prompt-faithful quarantine.
    # Behavior: allow inter-field whitespace but reject extra labeled sections.
    text = raw_output.strip()
    match = _COUPLED.fullmatch(text)
    if not match or text.count("Emotion:") != 1 or text.count("Response:") != 1:
        raise StructuredOutputError(
            "expected exactly ordered Emotion and Response fields", raw_output
        )
    raw_emotion = match.group(1).strip()
    response = match.group(2).strip()
    if not raw_emotion or not response:
        raise StructuredOutputError("emotion/response field is empty", raw_output)
    if re.search(r"(?m)^[A-Za-z][A-Za-z _-]{0,40}:\s*", response):
        raise StructuredOutputError("unexpected additional labeled section", raw_output)
    if len(raw_emotion) > 64 or len(response) > 2000:
        raise StructuredOutputError("emotion/response field exceeds limit", raw_output)
    return {"raw": raw_emotion, "normalized": raw_emotion.casefold()}, response


def parse_short_response(raw_output: str) -> str:
    response = raw_output.strip()
    if not response or len(response) > 2000:
        raise StructuredOutputError("response is empty or exceeds limit", raw_output)
    return response
