"""Recency-aware causal Q-state serialization.

Source: P3.6 review of right-truncated monolithic PlannerStateView JSON.
Purpose: place decision-critical current state first and drop oldest complete turns.
Created: 2026-07-17T04:31:00Z.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Protocol

from .views import PlannerStateView, assert_causal_planner_payload


@dataclass(frozen=True)
class SerializedPlannerState:
    text: str
    audit: dict[str, Any]


class StateTokenizer(Protocol):
    def __call__(self, text: str, **kwargs: Any) -> dict[str, Any]: ...


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=True, separators=(",", ":"))


def serialize_planner_state(
    view: PlannerStateView,
    *,
    max_chars: int = 6000,
    tokenizer: StateTokenizer | None = None,
    max_state_tokens: int | None = None,
    reserve_action_tokens: int = 0,
) -> SerializedPlannerState:
    """Serialize critical current state first, then newest complete turns that fit."""

    if max_chars < 256:
        raise ValueError("state serialization budget is too small")
    if (tokenizer is None) != (max_state_tokens is None):
        raise ValueError("tokenizer and max_state_tokens must be provided together")
    if max_state_tokens is not None and max_state_tokens < 32:
        raise ValueError("state token budget is too small")

    def token_count(text: str) -> int | None:
        if tokenizer is None:
            return None
        encoded = tokenizer(text, add_special_tokens=False, truncation=False)
        return len(encoded["input_ids"])
    conversation = [dict(turn) for turn in view.conversation]
    latest_user_index = next(
        (index for index in range(len(conversation) - 1, -1, -1)
         if conversation[index]["role"] in {"Patient", "Student", "Seller", "Persuadee"}),
        len(conversation) - 1 if conversation else -1,
    )
    latest_user = conversation[latest_user_index] if latest_user_index >= 0 else None
    current_emotion = dict(view.emotion_history[-1]) if view.emotion_history else None
    case_context = dict(view.public_case_context)
    deduplicated_case_fields: list[str] = []
    if latest_user is not None:
        for field, value in tuple(case_context.items()):
            if isinstance(value, str) and value == latest_user["content"]:
                # DX-REPRO CHANGE 2026-07-17T06:03:00Z [DX-P3_6-030]
                # Base: 42213a7, state_serializer.py:serialize_planner_state
                # Reason: ESConv initialization duplicated the full situation as
                # both public context and the current user turn, exhausting the
                # critical-only token budget before history could be dropped.
                # Behavior: preserve the text once as current_user and audit the
                # semantically equivalent context reference.
                case_context.pop(field)
                deduplicated_case_fields.append(field)
    critical = {
        "dataset": view.dataset,
        "turn_index": view.turn_index,
        "case_context": case_context,
        "current_user": latest_user,
        "current_emotion": current_emotion,
    }
    assert_causal_planner_payload(critical)
    recent = [
        {"turn_id": index, **turn}
        for index, turn in enumerate(conversation)
        if index != latest_user_index
    ]
    payload = {"critical": critical, "recent_conversation": recent}
    text = _canonical(payload)
    serialized_tokens = token_count(text)
    while recent and (
        len(text) > max_chars
        or (max_state_tokens is not None and serialized_tokens is not None
            and serialized_tokens > max_state_tokens)
    ):
        recent.pop(0)
        text = _canonical(payload)
        serialized_tokens = token_count(text)
    if len(text) > max_chars:
        raise ValueError("critical case/current-user/current-emotion state exceeds budget")
    if (max_state_tokens is not None and serialized_tokens is not None
            and serialized_tokens > max_state_tokens):
        raise ValueError("critical case/current-user/current-emotion tokens exceed budget")
    kept = [int(turn["turn_id"]) for turn in recent]
    if latest_user_index >= 0:
        kept.append(latest_user_index)
    kept = sorted(set(kept))
    all_ids = list(range(len(conversation)))
    dropped = [index for index in all_ids if index not in kept]
    audit = {
        "serializer": "recency_critical_first_v2",
        "max_chars": max_chars,
        "serialized_chars": len(text),
        "max_state_tokens": max_state_tokens,
        "serialized_state_tokens": serialized_tokens,
        "reserve_action_tokens": int(reserve_action_tokens),
        "token_budget_enforced": tokenizer is not None,
        "kept_turn_ids": kept,
        "dropped_turn_ids": dropped,
        "latest_user_turn_id": latest_user_index,
        "case_context_preserved": True,
        "case_context_fields_deduplicated_to_current_user": deduplicated_case_fields,
        "current_user_preserved": latest_user is not None,
        "current_emotion_preserved": current_emotion is not None,
        "truncation_reason": "oldest_complete_turns" if dropped else "none",
    }
    return SerializedPlannerState(text=text, audit=audit)
