"""Dataset-routed policy, emotion, role-play, and critic prompts.

Source: upstream qwen_prompts.py/prompt.py and extended-paper prompt appendix.
Purpose: replace manual ExTES edits with explicit registry-selected messages.
Created: 2026-07-16T06:28:17Z.
"""

from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any, Iterable, Mapping

from .registry import DatasetSpec
from .views import audience_case_view


def format_conversation(conversation: Iterable[Mapping[str, str]]) -> str:
    return " ".join(f"{turn['role']}: {turn['content']}" for turn in conversation)


def _format_appendix_conversation(conversation: Iterable[Mapping[str, str]]) -> str:
    """Match the local extended implementation's trailing-space rendering."""

    return "".join(f"{turn['role']}: {turn['content']} " for turn in conversation)


def _emotion_text(emotion_history: Iterable[Any]) -> str:
    values = []
    for item in emotion_history:
        if is_dataclass(item):
            item = asdict(item)
        values.append(
            str(item.get("label", item.get("normalized", "")))
            if isinstance(item, Mapping) else str(item)
        )
    return " -> ".join(value for value in values if value) or "-"


POLICY_GOALS = {
    "esconv": "help the patient feel understood, supported, and progress toward resolution",
    "extes": "help the patient feel understood, supported, and progress toward resolution",
    "cima": "guide the student toward translating the target English sentence into Italian",
    "cb": "negotiate effectively while maximizing the buyer's benefit",
    "p4g": "persuade the persuadee to donate to Save the Children",
}


def render_case_context(
    spec: DatasetSpec,
    case: Mapping[str, Any],
    *,
    audience: str,
    emotion_tracker_variant: str | None = None,
) -> str:
    """Render task-specific, audience-scoped case metadata."""

    # DX-REPRO CHANGE 2026-07-16T07:36:00Z [DX-P1_5-007]
    # Upstream/local base: 37ee4ef/dialogxpert_repro/prompts.py/generic roleplay context
    # Reason: generic prompts discarded the case goal for CIMA, CB, and P4G.
    # Behavior: each dataset has an explicit visibility-scoped prompt renderer.
    if audience not in {"policy", "system", "user", "critic", "emotion"}:
        raise ValueError(f"unknown prompt audience: {audience}")
    # DX-REPRO CHANGE 2026-07-17T02:40:00Z [DX-P3_5-003]
    # Base: 6ea4d579, prompts.py:render_case_context
    # Reason: dataset-specific prompts still received the entire case mapping.
    # Behavior: render only the registry-approved audience view.
    visible = audience_case_view(
        spec, case, audience=audience,
        emotion_tracker_variant=emotion_tracker_variant,
    )
    if spec.name in {"esconv", "extes"}:
        return (
            f"Emotion type: {visible.get('emotion_type', 'unknown')}\n"
            f"Problem type: {visible.get('problem_type', 'unknown')}\n"
            f"Situation: {visible.get('situation', 'not supplied')}"
        )
    if spec.name == "cima":
        lines = [f"English sentence to teach: {visible['sentence']}"]
        if audience == "critic":
            lines.append(f"Gold Italian target for evaluation only: {visible['target']}")
        else:
            lines.append("The student does not know the gold target; guide incrementally without revealing it.")
        return "\n".join(lines)
    if spec.name == "cb":
        labels = {
            "item_name": "Item",
            "buyer_item_description": "Buyer description",
            "seller_item_description": "Seller description",
            "buyer_price": "Buyer target price",
            "seller_price": "Seller desired/list price",
        }
        return "\n".join(f"{labels[key]}: {value}" for key, value in visible.items())
    if spec.name == "p4g":
        return (
            "Task background: persuade the other participant to donate to "
            "Save the Children while remaining truthful, respectful, and non-coercive.\n"
            "Charity background: Save the Children supports children through "
            "humanitarian and development programs."
        )
    raise KeyError(f"no case renderer for dataset {spec.name}")


def build_policy_messages(
    spec: DatasetSpec,
    conversation: list[dict[str, str]],
    emotion_history: list[Any],
    options: str,
    *,
    top_k: int,
    case: Mapping[str, Any] | None = None,
    prompt_variant: str = "dataset_specific_corrected_v1",
    emotion_tracker_variant: str = "tracker_text_only",
) -> list[dict[str, str]]:
    full = (
        _format_appendix_conversation(conversation)
        if prompt_variant == "esconv_appendix_policy_exact_v1"
        else format_conversation(conversation)
    )
    emotions = _emotion_text(emotion_history)
    if prompt_variant == "esconv_appendix_policy_exact_v1":
        if spec.name != "esconv" or top_k != 4:
            raise ValueError("Appendix policy exact v1 is ESConv top-4 only")
        return [
            {
                "role": "system",
                "content": (
                    "You are a specialist in policy-planning for emotional support conversations. "
                    "The following is a conversation between a therapist and a patient. The patient's "
                    "emotion states throughout the conversation are also provided. Your task is to decide "
                    "the most therapeutically helpful next action the therapist should do based on the "
                    "patient's emotion history and the conversation flow. The therapist's goal is to help "
                    "the patient feel emotionally understood, supported, and to make progress toward "
                    "emotional resolution."
                ),
            },
            {
                "role": "user",
                "content": (
                    f"Conversation History: {full}\n Emotion History: {emotions}\n. "
                    f"Options: {options}\n Choose the TOP 4 most suitable actions from the given "
                    "options list. Reply ONLY in the given format: 1,2,4,5"
                ),
            },
        ]
    if prompt_variant not in {
        "dataset_specific_corrected_v1", "released_integer_top4_v1"
    }:
        raise ValueError(f"unknown policy prompt variant: {prompt_variant}")
    context = render_case_context(
        spec, case or {}, audience="policy",
        emotion_tracker_variant=emotion_tracker_variant,
    ) if case is not None else ""
    return [
        {
            "role": "system",
            "content": (
                f"You are a policy planner for {spec.name}. Select the next {spec.system_role} "
                f"strategy to {POLICY_GOALS[spec.name]}."
            ),
        },
        {
            "role": "user",
            "content": (
                f"Case Context:\n{context}\n"
                f"Conversation History: {full}\n"
                f"Emotion History: {emotions}\n"
                f"Options:\n{options}\nChoose exactly {top_k} action IDs. "
                "Reply only as comma-separated integers, for example: 1,2,4,5"
            ),
        },
    ]


def build_emotion_messages(
    spec: DatasetSpec,
    conversation: list[dict[str, str]],
    case: Mapping[str, Any] | None = None,
) -> list[dict[str, str]]:
    return [
        {
            "role": "system",
            "content": (
                f"Infer the current {spec.user_role}'s emotion from the latest user utterance. "
                "Return exactly one JSON object with keys raw and normalized; normalized must be one short label."
            ),
        },
        {
            "role": "user",
            "content": (
                f"Case Context:\n{render_case_context(spec, case, audience='emotion')}\n"
                if case is not None
                else ""
            )
            + format_conversation(conversation),
        },
    ]


def build_roleplay_messages(
    spec: DatasetSpec,
    case: Mapping[str, Any],
    role: str,
    conversation: list[dict[str, str]],
    emotion_history: list[Any] | None = None,
    action: str | None = None,
    *,
    coupled_emotion: bool = False,
    critic_variant: str = "critic_compact_enum_v1",
    system_prompt_variant: str = "dataset_specific_corrected_v1",
    user_prompt_variant: str = "dataset_specific_corrected_v1",
) -> list[dict[str, str]]:
    full = format_conversation(conversation)
    appendix_full = _format_appendix_conversation(conversation)
    last = conversation[-1]["content"]
    action_text = spec.action_inventory.get(action or "", "Continue naturally.")
    if role == "system":
        if system_prompt_variant == "esconv_appendix_system_exact_v1":
            if spec.name != "esconv" or action not in spec.action_inventory:
                raise ValueError("Appendix system exact v1 requires an ESConv action")
            return [
                {
                    "role": "system",
                    "content": (
                        "You are role playing as a therapist in a counseling conversation with a patient. "
                        "Your goal is to help the patient resolve their emotional issues and assist them "
                        "in understanding and working through their challenges."
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"Full conversation: \n{appendix_full}\n\nThe patient just said: '{last}'. "
                        "Please infer the patient's emotional state in one word (Example: Emotion: ...) "
                        "followed by your response, which should be only one short and succint sentence "
                        f"(Response: ...). {action_text}"
                    ),
                },
            ]
        if system_prompt_variant not in {
            "dataset_specific_corrected_v1", "released_code_system_v1"
        }:
            raise ValueError(f"unknown system prompt variant: {system_prompt_variant}")
        context = render_case_context(spec, case, audience="system")
        suffix = (
            " First output 'Emotion: <one label>' and then 'Response: <one short response>'."
            if coupled_emotion
            else " Reply with one short response only."
        )
        return [
            {
                "role": "system",
                "content": (
                    f"Role-play as the {spec.system_role} in {spec.name}.\n"
                    f"{context}"
                ),
            },
            {
                "role": "user",
                "content": f"Conversation: {full}\nThe {spec.user_role} said: {last}\nStrategy: {action_text}.{suffix}",
            },
        ]
    if role == "user":
        if user_prompt_variant == "esconv_appendix_user_exact_v1":
            if spec.name != "esconv":
                raise ValueError("Appendix user exact v1 is ESConv only")
            return [
                {
                    "role": "system",
                    "content": (
                        "You are role playing as a patient in a counseling conversation with a therapist. "
                        "You are seeking help from the therapist, because you are dealing with emotional "
                        f"issues related to {case['emotion_type']} regarding {case['problem_type']}."
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"Full conversation:\n{appendix_full}\n\nThe therapist just said: '{last}'. Express how "
                        "you feel in a natural, emotional way. Please reply with only one short and "
                        "succinct sentence."
                    ),
                },
            ]
        if user_prompt_variant not in {
            "dataset_specific_corrected_v1", "released_code_user_v1"
        }:
            raise ValueError(f"unknown user prompt variant: {user_prompt_variant}")
        context = render_case_context(spec, case, audience="user")
        return [
            {
                "role": "system",
                "content": (
                    f"Role-play as the {spec.user_role} in {spec.name}.\n"
                    f"{context}"
                ),
            },
            {
                "role": "user",
                "content": f"Conversation: {full}\nThe {spec.system_role} just responded. Reply naturally in one short sentence.",
            },
        ]
    aliases = {
        "paper": "critic_appendix_full_sentence_v1",
        "compact_enum": "critic_compact_enum_v1",
    }
    critic_variant = aliases.get(critic_variant, critic_variant)
    if critic_variant not in {
        "critic_appendix_full_sentence_v1",
        "critic_compact_enum_v1",
        "critic_released_code_v1",
    }:
        raise ValueError(f"unknown critic prompt variant: {critic_variant}")
    emotions = _emotion_text(emotion_history or [])
    context = render_case_context(spec, case, audience="critic")
    enums = {
        "esconv": ["worse", "same", "better", "solved"],
        "cima": ["incorrect", "did_not", "part", "whole"],
        "cb": ["no_deal", "deal:<numeric_price>"],
        "p4g": ["refused", "neutral", "positive", "agree"],
        "extes": ["worse", "same", "solved"],
    }[spec.name]
    if critic_variant == "critic_compact_enum_v1":
        return [
            {
                "role": "system",
                "content": "You are a strict classifier. Return one exact enum and no explanation.",
            },
            {
                "role": "user",
                "content": (
                    f"Task: {spec.name}\n{context}\nConversation: {full}\n"
                    f"Allowed enums: {', '.join(enums)}"
                ),
            },
        ]
    if critic_variant == "critic_released_code_v1":
        if spec.name == "esconv":
            return [
                {
                    "role": "system",
                    "content": "Given a conversation between a Therapist and a Patient, please assess whether the Patient' emotional issue has been solved after the conversation.",
                },
                {
                    "role": "user",
                    "content": (
                        "You can only reply with one of the following sentences: "
                        "No, the Patient feels worse. No, the Patient feels the same. "
                        "No, but the Patient feels better. Yes, the Patient's issue has been solved.\n\n"
                        f"The following is a conversation about {case['emotion_type']} regarding "
                        f"{case['problem_type']}: {full}\nQuestion: Has the Patient's issue been solved? Answer: "
                    ),
                },
            ]
        return build_roleplay_messages(
            spec, case, role, conversation, emotion_history, action,
            critic_variant="critic_compact_enum_v1",
        )
    appendix_options = {
        "esconv": (
            "- No, the patient feels worse.\n"
            "- No, the patient feels the same.\n"
            "- No, but the patient feels somewhat better.\n"
            "- Yes, the patient's emotional issues have been resolved."
        ),
        "cima": (
            "- No, the Student made an incorrect translation.\n"
            "- No, the Student did not try to translate.\n"
            f"- No, the Student only correctly translated a part of \"{case.get('sentence', '')}\".\n"
            f"- Yes, the Student correctly translated the whole sentence of \"{case.get('sentence', '')}\"."
        ),
        "p4g": (
            "- The persuadee has explicitly refused.\n"
            "- The persuadee remains neutral about donating.\n"
            "- The persuadee has a positive attitude towards donating but hasn't decided yet.\n"
            "- The persuadee has decided to donate."
        ),
        "cb": "- They have reached a deal at [price].\n- They have not reached a deal.",
        "extes": (
            "- No, the patient feels worse.\n- No, the patient feels the same.\n"
            "- Yes, the patient's emotional issues have been resolved."
        ),
    }[spec.name]
    system_text = {
        "esconv": (
            "You are an expert in assessing counseling sessions between a patient and a therapist. "
            "Your task is to evaluate whether the conversation helped improve the patient's emotional state. "
            f"The session concerns the emotion type \"{case.get('emotion_type', '')}\" and the problem type \"{case.get('problem_type', '')}\"."
        ),
        "cima": (
            "You are role-playing as an expert in evaluating tutoring conversations between a teacher and a student. "
            f"The goal is to evaluate whether the student correctly translated the English sentence \"{case.get('sentence', '')}\" into Italian. "
            f"The emotion states of the student during the conversation were: {emotions}"
        ),
        "p4g": "You are an expert in evaluating persuasive donation conversations.",
        "cb": "You are an expert in deciding whether a buyer and seller reached a deal.",
        "extes": "You are an expert in assessing counseling sessions between a patient and a therapist.",
    }[spec.name]
    question = {
        "esconv": "Based on the conversation and emotional trajectory",
        "cima": f"Did the student correctly translate the entire sentence \"{case.get('sentence', '')}\" into Italian?",
        "p4g": "Has the persuadee been successfully convinced to make a donation at the end of the conversation?",
        "cb": "Have they reached a deal?",
        "extes": "Based on the conversation and emotional trajectory",
    }[spec.name]
    return [
        {
            "role": "system",
            "content": system_text,
        },
        {
            "role": "user",
            "content": (
                f"Conversation so far:\n{appendix_full}\n\nEmotion History: {emotions}\n"
                f". {question}, please respond with ONE AND ONLY ONE of the following:\n\n"
                f"{appendix_options}"
            ),
        },
    ]
