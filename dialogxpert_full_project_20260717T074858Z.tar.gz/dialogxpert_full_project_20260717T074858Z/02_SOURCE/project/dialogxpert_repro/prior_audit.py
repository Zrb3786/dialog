"""ESConv prior-coverage and all-eight-Q audit for P3.6.

Source: P3.6 external review gate H.
Purpose: quantify strategy exclusion/position against random-k and all-8 Q controls.
Created: 2026-07-17T05:24:00Z.
"""

from __future__ import annotations

import json
import math
import random
from collections import Counter, defaultdict
from dataclasses import asdict
from pathlib import Path
from typing import Any

import torch

from .backend import TransformersLocalBackend
from .protocols import PROTOCOLS
from .prior import ActionPriorParseError
from .qnet import FrozenBertEncoder, QMLP
from .registry import get_dataset, load_split
from .smoke import write_json, write_jsonl
from .state import initialize_state, make_emotion_state
from .state_serializer import serialize_planner_state
from .views import build_planner_state_view


def _entropy(counts: Counter[str]) -> float:
    total = sum(counts.values())
    return -sum((count / total) * math.log2(count / total)
                for count in counts.values() if count) if total else 0.0


def run_prior_coverage_audit(*, output_dir: str | Path, model_path: str | Path,
                             bert_path: str | Path, device: str = "cuda:0",
                             seeds: tuple[int, ...] = (7, 17, 29)) -> dict[str, Any]:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=False)
    spec = get_dataset("esconv")
    cases = [("train", case) for case in load_split("esconv", "train")[:100]]
    cases += [("valid", case) for case in load_split("esconv", "valid")[:50]]
    backend = TransformersLocalBackend(model_path, device=device, seed=seeds[0], dtype="bfloat16")
    encoder = FrozenBertEncoder(bert_path, device=device, pooling="cls", max_length=512)
    rows: list[dict[str, Any]] = []
    protocol = PROTOCOLS["corrected_resolved_only"]
    for seed in seeds:
        backend.seed = seed
        torch.manual_seed(seed)
        q_head = QMLP(int(encoder.manifest["hidden_size"])).to(device)
        q_head.eval()
        for split, case in cases:
            episode_id = int(case["_dx_row_index"])
            state = initialize_state(spec, case)
            backend.set_episode_context(
                case_id=state.case_id, split=split, track="prior_coverage",
                episode_id=episode_id, rollout_id=f"seed:{seed}",
                protocol_name=protocol.name, protocol_hash=protocol.sha256,
            )
            parsed = backend.infer_emotion(
                spec, case, state, tracker_variant="tracker_text_only"
            )
            emotion, oov = make_emotion_state(
                parsed, state, tracker_variant="tracker_text_only"
            )
            state.emotion_history.append(emotion)
            planner_view = build_planner_state_view(
                spec, case, state, emotion_tracker_variant="tracker_text_only"
            )
            max_action_tokens = max(
                len(encoder.tokenizer(action, add_special_tokens=False)["input_ids"])
                for action in spec.action_names
            )
            reserve = max_action_tokens + 3
            state_text = serialize_planner_state(
                planner_view, tokenizer=encoder.tokenizer,
                max_state_tokens=encoder.max_length - reserve,
                reserve_action_tokens=reserve,
            ).text
            encoded = encoder.encode_pairs(
                [state_text] * len(spec.action_names), list(spec.action_names)
            )
            with torch.no_grad():
                q_values = q_head(encoded.features.to(device).float()).detach().cpu()
            q_order = sorted(range(len(spec.action_names)),
                             key=lambda index: float(q_values[index]), reverse=True)
            random_order = list(range(len(spec.action_names)))
            random.Random((seed << 32) + episode_id).shuffle(random_order)
            for top_k in (2, 3, 4, 5):
                # DX-REPRO CHANGE 2026-07-17T05:45:00Z [DX-P3_6-029]
                # Base: 3793c14, prior_audit.py:run_prior_coverage_audit
                # Reason: prefixes of one top-5 generation are not samples from
                # prompts that explicitly request k=2/3/4/5.
                # Behavior: issue and retain one exact-k prior call per state/k.
                backend.set_episode_context(
                    case_id=state.case_id, split=split, track="prior_coverage",
                    episode_id=episode_id, rollout_id=f"seed:{seed}:k:{top_k}",
                    protocol_name=protocol.name, protocol_hash=protocol.sha256,
                )
                prior_error = None
                try:
                    prior = backend.propose_actions(
                        spec, case, state, top_k=top_k,
                        behavior_track="corrected_primary",
                    )
                    llm_actions = list(prior.actions)
                    llm_action_ids = list(prior.action_ids)
                except ActionPriorParseError as exc:
                    prior_error = repr(exc)
                    llm_actions = []
                    llm_action_ids = []
                rows.append({
                    "seed": seed, "split": split, "case_id": state.case_id,
                    "top_k": top_k, "llm_actions": llm_actions,
                    "llm_action_ids": llm_action_ids,
                    "parse_success": prior_error is None,
                    "prior_error": prior_error,
                    "random_actions": [spec.action_names[index]
                                       for index in random_order[:top_k]],
                    "all8_q_order": [spec.action_names[index] for index in q_order],
                    "all8_q_values": [float(q_values[index]) for index in q_order],
                    "q_best_in_llm_topk": spec.action_names[q_order[0]] in llm_actions,
                    "duplicates": len(llm_actions) != len(set(llm_actions)),
                    "emotion_oov": oov,
                })
    summaries: dict[str, Any] = {}
    for top_k in (2, 3, 4, 5):
        selected = [row for row in rows if row["top_k"] == top_k]
        inclusion = Counter(action for row in selected for action in row["llm_actions"])
        random_inclusion = Counter(action for row in selected for action in row["random_actions"])
        positions: dict[str, list[int]] = defaultdict(list)
        for row in selected:
            for position, action in enumerate(row["llm_actions"], 1):
                positions[action].append(position)
        summaries[str(top_k)] = {
            "rows": len(selected),
            "parse_success_rate": sum(int(row["parse_success"]) for row in selected)
            / len(selected),
            "duplicate_rate": sum(int(row["duplicates"]) for row in selected) / len(selected),
            "q_best_in_llm_topk_rate": sum(int(row["q_best_in_llm_topk"])
                                              for row in selected) / len(selected),
            "llm_inclusion": dict(sorted(inclusion.items())),
            "random_inclusion": dict(sorted(random_inclusion.items())),
            "llm_inclusion_entropy_bits": _entropy(inclusion),
            "random_inclusion_entropy_bits": _entropy(random_inclusion),
            "mean_position_when_included": {
                action: sum(values) / len(values) for action, values in sorted(positions.items())
            },
        }
    result = {
        "status": "PASS",
        "cases": {"train": 100, "valid": 50},
        "seeds": list(seeds),
        "top_k": [2, 3, 4, 5],
        "top_k_execution": "independent_exact_k_prompts_v1",
        "comparisons": ["llm_top_k", "all8_q", "random_k"],
        "protocol_name": protocol.name,
        "protocol_hash": protocol.sha256,
        "model_manifest": backend.manifest,
        "encoder_manifest": encoder.manifest,
        "summaries": summaries,
    }
    write_json(output / "prior_coverage_result.json", result)
    write_jsonl(output / "prior_coverage_records.jsonl", rows)
    write_jsonl(output / "generation_records.jsonl", [asdict(record) for record in backend.records])
    (output / "COMPLETE").write_text("COMPLETE\n", encoding="utf-8")
    return result
