"""Strict prompt-faithful and formal action-prior interfaces.

Source: upstream env.py integer parsing and official/extended paper prior claims.
Purpose: separate integer-ID candidates from formal projected probabilities.
Created: 2026-07-16T06:28:17Z.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Iterable, Mapping, Sequence


class ActionPriorParseError(ValueError):
    """An explicit, countable action-prior parse failure."""


@dataclass(frozen=True)
class ActionPriorResult:
    top_k_actions: tuple[str, ...]
    top_k_action_ids: tuple[int, ...]
    top_k_conditional_probabilities: tuple[float, ...] | None
    raw_output: str
    variant: str
    absolute_action_probabilities: dict[str, float] | None = None
    matched_conditional_probabilities: dict[str, float] | None = None
    unmatched_mass: float = 0.0
    projection_failures: tuple[str, ...] = ()
    projection_version: str | None = None

    @property
    def actions(self) -> tuple[str, ...]:
        return self.top_k_actions

    @property
    def action_ids(self) -> tuple[int, ...]:
        return self.top_k_action_ids

    @property
    def probabilities(self) -> tuple[float, ...] | None:
        return self.top_k_conditional_probabilities


@dataclass(frozen=True)
class FormalCandidate:
    continuation: str
    log_probability: float


_ID_LIST = re.compile(r"\s*(\d+)(?:\s*,\s*(\d+))*\s*")


def parse_prompt_faithful(
    raw_output: str,
    action_inventory: Sequence[str],
    *,
    top_k: int,
) -> ActionPriorResult:
    """Parse exactly k unique one-based IDs and never invent probabilities."""

    text = raw_output.strip()
    if not _ID_LIST.fullmatch(text):
        raise ActionPriorParseError("output must contain only comma-separated positive integers")
    tokens = [part.strip() for part in text.split(",")]
    if len(tokens) != top_k:
        raise ActionPriorParseError(f"expected exactly {top_k} IDs, got {len(tokens)}")
    ids = tuple(int(token) for token in tokens)
    if len(set(ids)) != len(ids):
        raise ActionPriorParseError("duplicate action IDs are not allowed")
    if any(action_id < 1 or action_id > len(action_inventory) for action_id in ids):
        raise ActionPriorParseError(
            f"action ID outside 1..{len(action_inventory)}: {ids}"
        )
    actions = tuple(action_inventory[action_id - 1] for action_id in ids)
    return ActionPriorResult(actions, ids, None, raw_output, "prompt_faithful")


def _normalized(text: str) -> str:
    return " ".join(re.findall(r"[a-z0-9]+", text.casefold()))


def project_official_formal(
    candidates: Iterable[FormalCandidate],
    action_inventory: Sequence[str],
    *,
    top_k: int,
    synonyms: Mapping[str, str] | None = None,
    projection_version: str = "dx-formal-v2",
    fallback_action: str | None = None,
) -> ActionPriorResult:
    """Deterministically project continuations and aggregate normalized mass."""

    # DX-REPRO CHANGE 2026-07-16T07:34:00Z [DX-P1_5-004]
    # Upstream/local base: 37ee4ef/dialogxpert_repro/prior.py/project_official_formal
    # Reason: top-k mass was not conditional-normalized and fallback could yield ID 0.
    # Behavior: exact/synonym/substring projection is deterministic and fail-closed.
    candidate_list = list(candidates)
    if top_k < 1 or top_k > len(action_inventory):
        raise ValueError("top_k must be within the action inventory")
    exact_lookup = {_normalized(action): action for action in action_inventory}
    synonym_lookup: dict[str, str] = {}
    for alias, action in (synonyms or {}).items():
        if action not in action_inventory:
            raise ValueError(f"synonym target is not a registered action: {action}")
        normalized_alias = _normalized(alias)
        if normalized_alias in exact_lookup and exact_lookup[normalized_alias] != action:
            raise ValueError(f"synonym collides with registered action: {alias}")
        synonym_lookup[normalized_alias] = action
    if fallback_action is None and "Others" in action_inventory:
        fallback_action = "Others"
    if fallback_action is not None and fallback_action not in action_inventory:
        raise ValueError("fallback_action must be an explicitly registered action")
    collected: list[tuple[str, float]] = []
    unmatched: list[float] = []
    failures: list[str] = []
    for candidate in candidate_list:
        normalized = _normalized(candidate.continuation)
        action = exact_lookup.get(normalized)
        if action is None:
            action = synonym_lookup.get(normalized)
        if action is None:
            matches = {
                registered
                for key, registered in {**exact_lookup, **synonym_lookup}.items()
                if key and key in normalized
            }
            if len(matches) == 1:
                action = next(iter(matches))
            elif len(matches) > 1:
                failures.append(f"ambiguous:{candidate.continuation}")
            elif fallback_action is not None:
                action = fallback_action
            else:
                failures.append(f"unmatched:{candidate.continuation}")
        logp = float(candidate.log_probability)
        if action is None:
            unmatched.append(logp)
        else:
            collected.append((action, logp))
    if not candidate_list:
        raise ActionPriorParseError("formal prior received no candidates")
    all_logps = [candidate.log_probability for candidate in candidate_list]
    max_logp = max(all_logps)
    unmatched_weight = sum(math.exp(logp - max_logp) for logp in unmatched)
    weights: dict[str, float] = {}
    for action, logp in collected:
        weights[action] = weights.get(action, 0.0) + math.exp(logp - max_logp)
    matched_total = sum(weights.values())
    raw_total = matched_total + unmatched_weight
    if matched_total <= 0:
        raise ActionPriorParseError("formal prior projected no registered action mass")
    # DX-REPRO CHANGE 2026-07-17T02:45:00Z [DX-P3_5-008]
    # Base: 6ea4d579, prior.py:project_official_formal
    # Reason: matched-conditional mass was mislabeled as a full distribution.
    # Behavior: expose absolute, matched-conditional, and top-k-conditional mass separately.
    absolute_probabilities = {
        action: weights.get(action, 0.0) / raw_total for action in action_inventory
    }
    matched_probabilities = {
        action: weights.get(action, 0.0) / matched_total for action in action_inventory
    }
    ranked = sorted(weights.items(), key=lambda item: (-item[1], item[0]))[:top_k]
    if len(ranked) < top_k:
        raise ActionPriorParseError(
            f"projection produced {len(ranked)} unique actions, expected {top_k}"
        )
    actions = tuple(action for action, _ in ranked)
    ids = tuple(action_inventory.index(action) + 1 for action in actions)
    if any(action_id < 1 for action_id in ids):
        raise ActionPriorParseError("formal prior generated a non-positive action ID")
    top_total = sum(weight for _, weight in ranked)
    probabilities = tuple(weight / top_total for _, weight in ranked)
    return ActionPriorResult(
        actions,
        ids,
        probabilities,
        raw_output="\n".join(candidate.continuation for candidate in candidate_list),
        variant="official_formal",
        absolute_action_probabilities=absolute_probabilities,
        matched_conditional_probabilities=matched_probabilities,
        unmatched_mass=unmatched_weight / raw_total if raw_total else 0.0,
        projection_failures=tuple(failures),
        projection_version=projection_version,
    )
