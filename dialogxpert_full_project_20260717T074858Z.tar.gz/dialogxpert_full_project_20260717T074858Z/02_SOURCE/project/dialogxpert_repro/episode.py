"""Episode configuration and result contracts for standalone corrected runtime.

Source: P1.5 external review runtime order and P3 bounded-smoke requirements.
Purpose: separate episode state/results from legacy Env and training scripts.
Created: 2026-07-16T07:44:00Z.
"""

from __future__ import annotations

from dataclasses import dataclass

from .rl import Transition
from .protocols import get_protocol


@dataclass(frozen=True)
class EpisodeConfig:
    behavior_track: str = "corrected_primary"
    top_k: int = 4
    max_turns: int = 2
    critic_completions: int = 10
    critic_min_valid: int = 8
    critic_prompt_variant: str = "critic_compact_enum_v1"
    emotion_tracker_variant: str = "tracker_text_only"
    protocol_name: str = "corrected_resolved_only"
    episode_id: int = 0
    rollout_id: str = "primary"
    epsilon: float = 0.0
    seed: int = 7

    def __post_init__(self) -> None:
        if self.critic_prompt_variant not in {
            "paper", "compact_enum", "critic_appendix_full_sentence_v1",
            "critic_compact_enum_v1", "critic_released_code_v1",
        }:
            raise ValueError("unknown critic prompt variant")
        if self.emotion_tracker_variant not in {
            "tracker_case_oracle", "tracker_text_only", "no_emotion"
        }:
            raise ValueError("unknown emotion tracker variant")
        protocol = get_protocol(self.protocol_name)
        expected_track = (
            "repository_diagnostic" if self.protocol_name == "released_code_compat"
            else "prompt_faithful" if self.protocol_name == "extended_prompt_faithful"
            else "corrected_primary"
        )
        if self.behavior_track != expected_track:
            raise ValueError("behavior track and protocol contract mismatch")
        if self.emotion_tracker_variant != protocol.emotion_tracker_variant:
            raise ValueError("emotion tracker and protocol contract mismatch")
        if self.critic_prompt_variant != protocol.critic_prompt_variant:
            raise ValueError("critic prompt and protocol contract mismatch")
        if self.protocol_name in {"released_code_compat", "extended_prompt_faithful"}:
            if self.top_k != 4:
                raise ValueError("released/Appendix protocols require exact top-4")
        if self.episode_id < 0:
            raise ValueError("episode_id must be nonnegative")


@dataclass
class EpisodeResult:
    dataset: str
    split: str
    case_id: str
    behavior_track: str
    transitions: list[Transition]
    completed: bool
    success: bool
    quarantined: bool
    terminal_reason: str | None
    turns: int
    total_reward: float
    episode_id: int = 0
    rollout_id: str = "primary"
    protocol_name: str = "corrected_resolved_only"
    protocol_hash: str = ""
