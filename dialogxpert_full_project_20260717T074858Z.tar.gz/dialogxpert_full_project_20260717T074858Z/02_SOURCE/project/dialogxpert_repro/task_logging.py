"""Flush-safe task logs, status files, and heartbeat support.

Source: local logging/tmux contract.
Purpose: keep background model and smoke tasks observable without foreground waits.
Created: 2026-07-16T06:28:17Z.
"""

from __future__ import annotations

import json
import hashlib
import logging
import os
import shutil
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class TaskLog:
    # DX-REPRO CHANGE 2026-07-16T07:40:00Z [DX-P1_5-012]
    # Upstream/local base: 37ee4ef/dialogxpert_repro/task_logging.py/TaskLog
    # Reason: duplicate handlers and silent heartbeat callback failure obscured runs.
    # Behavior: one stdout/stderr handler pair, contextual status, fail-closed heartbeat.
    def __init__(
        self,
        root: str | Path,
        task: str,
        timestamp: str,
        *,
        context: dict[str, Any] | None = None,
    ):
        self.directory = Path(root) / "logs" / task / timestamp
        self.directory.mkdir(parents=True, exist_ok=True)
        self.context = dict(context or {})
        for filename in ("stdout.log", "stderr.log", "heartbeat.log"):
            (self.directory / filename).touch()
        (self.directory / "artifact_manifest.tsv").write_text(
            "path\tsize\tsha256\tstatus\n", encoding="utf-8"
        )
        self.logger = logging.getLogger(f"dialogxpert.{task}.{timestamp}")
        self.logger.setLevel(logging.INFO)
        self.logger.propagate = False
        for existing in list(self.logger.handlers):
            self.logger.removeHandler(existing)
            existing.close()
        formatter = logging.Formatter("%(asctime)sZ %(levelname)s %(message)s")
        stdout_handler = logging.FileHandler(self.directory / "stdout.log", encoding="utf-8")
        stdout_handler.setLevel(logging.INFO)
        stdout_handler.addFilter(lambda record: record.levelno < logging.ERROR)
        stdout_handler.setFormatter(formatter)
        stderr_handler = logging.FileHandler(self.directory / "stderr.log", encoding="utf-8")
        stderr_handler.setLevel(logging.ERROR)
        stderr_handler.setFormatter(formatter)
        self.logger.addHandler(stdout_handler)
        self.logger.addHandler(stderr_handler)

    def write_status(self, **values: Any) -> None:
        payload = {"timestamp": utc_now(), **self.context, **values}
        temporary = self.directory / "status.json.tmp"
        temporary.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
        temporary.replace(self.directory / "status.json")

    def write_environment(self, values: dict[str, Any]) -> None:
        (self.directory / "environment.txt").write_text(
            "\n".join(f"{key}={value}" for key, value in sorted(values.items())) + "\n",
            encoding="utf-8",
        )

    def write_command(self, command: str) -> None:
        (self.directory / "command.sh").write_text(
            "#!/usr/bin/env bash\nset -euo pipefail\n" + command.rstrip() + "\n",
            encoding="utf-8",
        )

    def finalize_artifact_manifest(self) -> None:
        rows = ["path\tsize\tsha256\tstatus"]
        excluded = {"artifact_manifest.tsv", "artifact_manifest.tsv.tmp"}
        for path in sorted(self.directory.rglob("*")):
            if not path.is_file() or path.name in excluded:
                continue
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            rows.append(
                f"{path.relative_to(self.directory)}\t{path.stat().st_size}\t{digest}\tPRESENT"
            )
        temporary = self.directory / "artifact_manifest.tsv.tmp"
        temporary.write_text("\n".join(rows) + "\n", encoding="utf-8")
        temporary.replace(self.directory / "artifact_manifest.tsv")

    def start_heartbeat(
        self,
        state: Callable[[], dict[str, Any]],
        *,
        interval_seconds: int = 60,
    ) -> tuple[threading.Event, threading.Thread]:
        stop = threading.Event()

        def run() -> None:
            while not stop.wait(0 if not (self.directory / "heartbeat.log").stat().st_size else interval_seconds):
                try:
                    usage = shutil.disk_usage(self.directory)
                    values = {
                        "timestamp": utc_now(),
                        "pid": os.getpid(),
                        "disk_free": usage.free,
                        **self.context,
                        **state(),
                    }
                    with (self.directory / "heartbeat.log").open(
                        "a", encoding="utf-8", buffering=1
                    ) as handle:
                        handle.write(json.dumps(values, sort_keys=True) + "\n")
                except Exception as exc:
                    self.logger.exception("heartbeat state callback failed")
                    self.write_status(
                        status="FAILED",
                        stage="heartbeat_failed",
                        error=repr(exc),
                        pid=os.getpid(),
                    )
                    stop.set()
                    return

        thread = threading.Thread(target=run, name="dx-heartbeat", daemon=True)
        thread.start()
        return stop, thread

    def flush(self) -> None:
        for handler in self.logger.handlers:
            handler.flush()

    def close(self) -> None:
        for handler in list(self.logger.handlers):
            handler.flush()
            self.logger.removeHandler(handler)
            handler.close()
