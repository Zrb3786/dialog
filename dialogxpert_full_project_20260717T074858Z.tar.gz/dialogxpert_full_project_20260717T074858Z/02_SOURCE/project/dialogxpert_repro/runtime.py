"""Standalone corrected DialogXpert episode runtime.

Source: P1.5 external review and corrected MDP ordering contract.
Purpose: run causal emotion→prior→Q→dialogue→consensus→replay without legacy Env.
Created: 2026-07-16T07:44:00Z.
"""

from __future__ import annotations

import hashlib
import random
from dataclasses import asdict
from typing import Any, Callable, Protocol, Sequence

import torch

from .backend import LLMBackend
from .encoding import PairEncodingResult, compact_cpu_tensor, feature_sha256
from .episode import EpisodeConfig, EpisodeResult
from .metrics import RunMetrics
from .parsers import StructuredOutputError
from .prior import ActionPriorParseError, ActionPriorResult
from .registry import DatasetSpec
from .rewards import (
    CriticParseError,
    CriticSchemaFailure,
    aggregate_critic_outputs,
    decide_termination,
)
from .rl import ActionSelection, ReplayBuffer, Transition, select_action_with_evidence
from .state import DialogueState, initialize_state, make_emotion_state
from .state_serializer import serialize_planner_state
from .views import PlannerStateView, build_planner_state_view
from .protocols import get_protocol
from .seeding import functional_seed


class TextEncoder(Protocol):
    manifest: dict[str, Any]

    def encode_pairs(
        self,
        state_texts: Sequence[str],
        action_texts: Sequence[str],
    ) -> PairEncodingResult:
        raise NotImplementedError


class DeterministicHashEncoder:
    """CPU-only deterministic feature encoder for scripted integration tests."""

    def __init__(self, dimension: int = 32):
        self.dimension = dimension
        self.manifest = {
            "encoder": "sha256_expand",
            "dimension": dimension,
            "version": 1,
        }

    def encode_pairs(
        self,
        state_texts: Sequence[str],
        action_texts: Sequence[str],
    ) -> PairEncodingResult:
        if len(state_texts) != len(action_texts):
            raise ValueError("state/action pair count mismatch")
        rows: list[list[float]] = []
        stats: list[dict[str, Any]] = []
        for state_text, action_text in zip(state_texts, action_texts):
            text = f"{state_text}\n[PAIR_ACTION]\n{action_text}"
            material = b""
            counter = 0
            while len(material) < self.dimension:
                material += hashlib.sha256(
                    text.encode("utf-8") + counter.to_bytes(4, "big")
                ).digest()
                counter += 1
            rows.append([(byte / 127.5) - 1.0 for byte in material[: self.dimension]])
            stats.append(
                {
                    "state_chars": len(state_text),
                    "action_chars": len(action_text),
                    "input_tokens": None,
                    "state_tokens": None,
                    "action_tokens": None,
                    "truncated_state_tokens": 0,
                    "action_preserved": True,
                    "truncation": "deterministic_pair_no_tokenizer",
                }
            )
        features = torch.tensor(rows, dtype=torch.float32)
        return PairEncodingResult(
            features,
            tuple(feature_sha256(row) for row in features),
            tuple(stats),
        )


def _runtime_audit_snapshot(state: DialogueState) -> dict[str, Any]:
    """Persist occurred history without copying raw/future case metadata."""

    return {
        "case_id": state.case_id,
        "dataset": state.dataset,
        "conversation": [dict(turn) for turn in state.conversation],
        "emotion_history": [asdict(item) for item in state.emotion_history],
        "turn_index": state.turn_index,
        "last_action": state.last_action,
        "last_reward": state.last_reward,
        "terminal_reason": state.terminal_reason,
        "case_metadata_keys": sorted(state.case_metadata),
    }


def _prior_metadata(prior: Any) -> dict[str, Any]:
    value = asdict(prior)
    return value


def _account_backend_records(
    metrics: RunMetrics | None,
    backend: LLMBackend,
    start_index: int,
) -> None:
    if metrics is None:
        return
    metrics.record_generation_records(backend.records[start_index:])


def run_episode(
    *,
    spec: DatasetSpec,
    case: dict[str, Any],
    split: str,
    backend: LLMBackend,
    encoder: TextEncoder,
    online_head: torch.nn.Module,
    replay: ReplayBuffer,
    config: EpisodeConfig,
    metrics: RunMetrics | None = None,
    device: str | torch.device = "cpu",
    progress_callback: Callable[[dict[str, Any]], None] | None = None,
    transition_guard: Callable[[Transition], bool] | None = None,
) -> EpisodeResult:
    """Execute one bounded episode with causal next-candidate preparation."""

    protocol_tracks = {
        "released_code_compat": "repository_diagnostic",
        "extended_prompt_faithful": "prompt_faithful",
        "corrected_resolved_only": "corrected_primary",
        "corrected_case_oracle_ablation": "corrected_primary",
        "corrected_no_emotion_ablation": "corrected_primary",
        "corrected_masked_mean_ablation": "corrected_primary",
        "corrected_all8_q_pilot": "corrected_primary",
        "corrected_prior_only_pilot": "corrected_primary",
    }
    if config.behavior_track != protocol_tracks[config.protocol_name]:
        raise ValueError("behavior track and protocol contract mismatch")
    protocol = get_protocol(config.protocol_name)
    encoder_pooling = getattr(encoder, "pooling", None)
    if encoder_pooling is not None and encoder_pooling != protocol.pooling:
        raise ValueError("encoder pooling and protocol contract mismatch")
    rng = random.Random(functional_seed(
        config.seed, phase=split, episode_id=config.episode_id,
        case_id=str(case["_dx_case_id"]), turn=0, role="action_selection",
        rollout_id=config.rollout_id,
    ))
    state = initialize_state(spec, case)
    backend.set_episode_context(
        case_id=state.case_id,
        split=split,
        track=config.behavior_track,
        episode_id=config.episode_id,
        rollout_id=config.rollout_id,
        protocol_name=protocol.name,
        protocol_hash=protocol.sha256,
        seed_root=config.seed,
    )
    record_start = len(backend.records)
    transitions: list[Transition] = []
    total_reward = 0.0
    if metrics is not None:
        if metrics.protocol_name and metrics.protocol_name != protocol.name:
            raise ValueError("metrics protocol name mismatch")
        if metrics.protocol_hash and metrics.protocol_hash != protocol.sha256:
            raise ValueError("metrics protocol hash mismatch")
        metrics.protocol_name = protocol.name
        metrics.protocol_hash = protocol.sha256
        metrics.attempted_episodes += 1
        metrics.eligible_episodes += 1

    def prepare() -> tuple[Any, PlannerStateView, Any, PairEncodingResult]:
        if config.behavior_track == "corrected_primary" and config.emotion_tracker_variant != "no_emotion":
            if config.emotion_tracker_variant == "tracker_case_oracle":
                parsed = {
                    "raw": str(case.get("emotion_type", "neutral")),
                    "normalized": str(case.get("emotion_type", "neutral")),
                }
            else:
                parsed = backend.infer_emotion(
                    spec, case, state, tracker_variant=config.emotion_tracker_variant
                )
            emotion, emotion_oov = make_emotion_state(
                parsed, state, tracker_variant=config.emotion_tracker_variant
            )
            state.emotion_history.append(emotion)
            if metrics is not None:
                metrics.emotion_observations += 1
                metrics.emotion_oov += int(emotion_oov)
        # DX-REPRO CHANGE 2026-07-17T06:25:00Z [DX-P3_6-031]
        # The A3 arm enumerates all registered actions without an LLM prior call.
        if protocol.action_selection == "all8_q":
            actions = tuple(spec.action_names)
            prior = ActionPriorResult(
                top_k_actions=actions,
                top_k_action_ids=tuple(range(1, len(actions) + 1)),
                top_k_conditional_probabilities=None,
                raw_output="[ALL_REGISTERED_ACTIONS_NO_PRIOR_CALL]",
                variant="all8_no_prior_v1",
            )
        else:
            prior = backend.propose_actions(
                spec,
                case,
                state,
                top_k=config.top_k,
                behavior_track=config.behavior_track,
            )
        planner_view = build_planner_state_view(
            spec, case, state,
            emotion_tracker_variant=config.emotion_tracker_variant,
            include_emotion=protocol.emotion_in_q,
        )
        action_texts = tuple(prior.actions)
        tokenizer = getattr(encoder, "tokenizer", None)
        max_length = getattr(encoder, "max_length", None)
        serializer_kwargs: dict[str, Any] = {}
        if tokenizer is not None and max_length is not None:
            action_lengths = [
                len(tokenizer(action, add_special_tokens=False, truncation=False)["input_ids"])
                for action in action_texts
            ]
            # DX-REPRO CHANGE 2026-07-17T05:38:00Z [DX-P3_6-027]
            # Base: 3793c14, runtime.py:run_episode/prepare
            # Reason: a character-only serializer still delegated hidden state
            # truncation to BERT and could not prove recent-state retention.
            # Behavior: reserve the longest action and all pair special tokens.
            reserve_action_tokens = max(action_lengths) + 3
            serializer_kwargs = {
                "tokenizer": tokenizer,
                "max_state_tokens": int(max_length) - reserve_action_tokens,
                "reserve_action_tokens": reserve_action_tokens,
            }
        serialized = serialize_planner_state(planner_view, **serializer_kwargs)
        encoded = encoder.encode_pairs(
            [serialized.text] * len(action_texts),
            action_texts,
        )
        return prior, planner_view, serialized, encoded

    try:
        state.turn_index = 0
        prior, planner_view, serialization, encoding = prepare()
        for turn_index in range(config.max_turns):
            if progress_callback is not None:
                progress_callback({
                    "episode": config.episode_id,
                    "turn": turn_index,
                    "replay_size": len(replay),
                    "last_reward": state.last_reward,
                    "parse_failures": metrics.parse_failures if metrics else 0,
                })
            if state.turn_index != turn_index or planner_view.turn_index != turn_index:
                raise RuntimeError("planner/runtime turn index is stale")
            features = encoding.features
            planner_snapshot = planner_view.as_dict()
            runtime_snapshot = _runtime_audit_snapshot(state)
            state_text = serialization.text
            emotion_snapshot = tuple(asdict(item) for item in state.emotion_history)
            candidate_mask = torch.ones(features.shape[0], dtype=torch.bool)
            with torch.no_grad():
                q_values = online_head(features.to(device).float()).detach().cpu()
            # The A0 control follows rank one and cannot consult Q for behavior.
            if protocol.action_selection == "prior_only":
                selection = ActionSelection(0, rng.random(), "prior_rank_1")
            else:
                selection = select_action_with_evidence(
                    q_values,
                    candidate_mask,
                    epsilon=config.epsilon,
                    rng=rng,
                )
            selected_index = selection.index
            selected_action = prior.actions[selected_index]
            generated = backend.generate_system_response(
                spec,
                case,
                state,
                action=selected_action,
                behavior_track=config.behavior_track,
            )
            if generated.emotion is not None:
                emotion, emotion_oov = make_emotion_state(
                    generated.emotion, state, tracker_variant="coupled_system_output"
                )
                state.emotion_history.append(emotion)
                if metrics is not None:
                    metrics.emotion_observations += 1
                    metrics.emotion_oov += int(emotion_oov)
            state.append(spec.system_role, generated.response)
            state.last_action = selected_action
            user_response = backend.simulate_user(spec, case, state)
            state.append(spec.user_role, user_response)
            critic_outputs = backend.evaluate_transition(
                spec,
                case,
                state,
                count=config.critic_completions,
                prompt_variant=config.critic_prompt_variant,
            )
            aggregation = aggregate_critic_outputs(
                spec,
                critic_outputs,
                case,
                requested_count=config.critic_completions,
                min_valid=config.critic_min_valid,
            )
            outcome = decide_termination(
                spec,
                aggregation,
                turn_index=turn_index,
                behavior_track=config.behavior_track,
                max_turns=config.max_turns,
            )
            state.last_reward = aggregation.aggregate_reward
            state.terminal_reason = outcome.reason
            total_reward += aggregation.aggregate_reward

            next_actions: tuple[str, ...] = ()
            next_action_texts: tuple[str, ...] = ()
            next_planner_snapshot: dict[str, Any] | None = None
            next_state_text: str | None = None
            next_state_serialization: dict[str, Any] | None = None
            next_features = torch.empty((0, features.shape[-1]), dtype=features.dtype)
            next_feature_hashes: tuple[str, ...] = ()
            next_token_stats: tuple[dict[str, Any], ...] = ()
            next_q_values: tuple[float, ...] = ()
            next_mask = torch.empty((0,), dtype=torch.bool)
            if not outcome.done:
                # DX-REPRO CHANGE 2026-07-17T02:40:00Z [DX-P3_5-004]
                # Base: 6ea4d579, runtime.py:run_episode/prepare-next
                # Reason: next candidates were encoded with the previous turn index.
                # Behavior: advance causal time before next emotion/prior/Q encoding.
                state.turn_index = turn_index + 1
                next_prior, next_planner_view, next_serialization, next_encoding = prepare()
                next_state_text = next_serialization.text
                next_state_serialization = next_serialization.audit
                next_actions = next_prior.actions
                next_action_texts = tuple(next_prior.actions)
                next_planner_snapshot = next_planner_view.as_dict()
                next_features = next_encoding.features
                next_feature_hashes = next_encoding.feature_hashes
                next_token_stats = next_encoding.token_stats
                next_mask = torch.ones(next_features.shape[0], dtype=torch.bool)
                with torch.no_grad():
                    next_q_values = tuple(
                        float(value)
                        for value in online_head(next_features.to(device).float()).detach().cpu()
                    )
            transition = Transition(
                behavior_track=config.behavior_track,
                dataset=spec.name,
                split=split,
                case_id=state.case_id,
                turn_index=turn_index,
                planner_state_view=planner_snapshot,
                runtime_audit_state=runtime_snapshot,
                state_text=state_text,
                state_serialization=serialization.audit,
                emotion_snapshot=emotion_snapshot,
                candidate_actions=prior.actions,
                candidate_action_ids=prior.action_ids,
                action_texts=tuple(prior.actions),
                candidate_prior_metadata=_prior_metadata(prior),
                candidate_features=compact_cpu_tensor(features),
                candidate_feature_hashes=encoding.feature_hashes,
                candidate_token_stats=encoding.token_stats,
                candidate_q_values=tuple(float(value) for value in q_values),
                candidate_mask=candidate_mask,
                epsilon=config.epsilon,
                selection_random_draw=selection.random_draw,
                selection_mode=selection.mode,
                selected_action_index=selected_index,
                selected_action=selected_action,
                selected_feature=compact_cpu_tensor(features[selected_index]),
                reward_aggregation=asdict(aggregation),
                reward=aggregation.aggregate_reward,
                done=outcome.done,
                success=outcome.success,
                terminal_reason=outcome.reason,
                next_planner_state_view=next_planner_snapshot,
                next_state_text=next_state_text,
                next_state_serialization=next_state_serialization,
                next_candidate_actions=next_actions,
                next_action_texts=next_action_texts,
                next_features=compact_cpu_tensor(next_features),
                next_feature_hashes=next_feature_hashes,
                next_token_stats=next_token_stats,
                next_candidate_q_values=next_q_values,
                next_candidate_mask=next_mask,
                model_manifest=dict(backend.manifest),
                encoder_manifest=dict(encoder.manifest),
                action_registry_hash=spec.action_registry_hash,
                episode_id=config.episode_id,
                rollout_id=config.rollout_id,
                protocol_name=protocol.name,
                protocol_hash=protocol.sha256,
            )
            if transition_guard is not None and not transition_guard(transition):
                _account_backend_records(metrics, backend, record_start)
                return EpisodeResult(
                    spec.name, split, state.case_id, config.behavior_track,
                    transitions, False, False, True, "pilot_hard_stop",
                    len(transitions), total_reward, config.episode_id,
                    config.rollout_id, protocol.name, protocol.sha256,
                )
            replay.append(transition)
            transitions.append(transition)
            if progress_callback is not None:
                progress_callback({
                    "episode": config.episode_id,
                    "turn": turn_index,
                    "replay_size": len(replay),
                    "last_reward": aggregation.aggregate_reward,
                    "parse_failures": metrics.parse_failures if metrics else 0,
                })
            if metrics is not None:
                metrics.total_turns += 1
                metrics.total_reward += aggregation.aggregate_reward
                metrics.critic_requested += aggregation.requested_count
                metrics.critic_valid += aggregation.valid_count
                metrics.critic_invalid += aggregation.invalid_count
            if outcome.done:
                if metrics is not None:
                    metrics.completed_episodes += 1
                    metrics.completed_turns += turn_index + 1
                    metrics.completed_reward += total_reward
                    metrics.solved_episodes += int(outcome.success)
                    metrics.failed_episodes += int(not outcome.success)
                    metrics.timeouts += int(outcome.reason == "max_turn_failure")
                    metrics.record_termination(outcome.reason or "unknown")
                _account_backend_records(metrics, backend, record_start)
                return EpisodeResult(
                    spec.name,
                    split,
                    state.case_id,
                    config.behavior_track,
                    transitions,
                    True,
                    outcome.success,
                    False,
                    outcome.reason,
                    turn_index + 1,
                    total_reward,
                    config.episode_id,
                    config.rollout_id,
                    protocol.name,
                    protocol.sha256,
                )
            prior, planner_view, serialization, encoding = (
                next_prior,
                next_planner_view,
                next_serialization,
                next_encoding,
            )
    except (
        CriticSchemaFailure,
        CriticParseError,
        StructuredOutputError,
        ActionPriorParseError,
    ) as exc:
        reason = (
            "critic_schema_failure"
            if isinstance(exc, CriticSchemaFailure)
            else "structured_parse_failure"
        )
        if metrics is not None:
            metrics.parse_failures += 1
            if isinstance(exc, CriticSchemaFailure):
                # DX-REPRO CHANGE 2026-07-17T05:20:00Z [DX-P3_6-024]
                # Base: 8f06af6, runtime.py:run_episode/critic quarantine
                # Reason: a whole failed batch vanished from critic validity denominators.
                # Behavior: retain every requested, valid, and invalid completion on failure.
                metrics.critic_requested += exc.aggregation.requested_count
                metrics.critic_valid += exc.aggregation.valid_count
                metrics.critic_invalid += exc.aggregation.invalid_count
            metrics.quarantined_episodes += 1
            if state.case_id not in metrics.quarantined_case_ids:
                metrics.quarantined_case_ids.append(state.case_id)
            metrics.record_termination(reason)
        if progress_callback is not None:
            progress_callback({
                "episode": config.episode_id,
                "turn": state.turn_index,
                "replay_size": len(replay),
                "last_reward": state.last_reward,
                "parse_failures": metrics.parse_failures if metrics else 1,
            })
        _account_backend_records(metrics, backend, record_start)
        return EpisodeResult(
            spec.name,
            split,
            state.case_id,
            config.behavior_track,
            transitions,
            False,
            False,
            True,
            reason,
            len(transitions),
            total_reward,
            config.episode_id,
            config.rollout_id,
            protocol.name,
            protocol.sha256,
        )
    raise RuntimeError("episode ended without terminal or quarantine outcome")
