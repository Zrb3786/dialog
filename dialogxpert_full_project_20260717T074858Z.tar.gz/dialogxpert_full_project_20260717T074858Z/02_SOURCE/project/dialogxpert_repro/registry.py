"""Dataset registry and single-split loaders for corrected DialogXpert.

Source: upstream utils_data.py, prompt.py, qwen_prompts.py, and train/valid audit.
Purpose: replace manual prompt edits and unsafe all-split/eval loaders.
Created: 2026-07-16T06:28:17Z.
"""

from __future__ import annotations

import ast
import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Mapping

from .safety import assert_development_split, assert_safe_data_path


class DatasetBlockedError(RuntimeError):
    """Raised when a dataset cannot be used without violating split policy."""


Loader = Callable[[Path], list[dict[str, Any]]]


@dataclass(frozen=True)
class DatasetSpec:
    name: str
    collaborative: bool
    system_role: str
    user_role: str
    train_path: str | None
    valid_path: str | None
    test_path_sealed: str
    loader: Loader
    case_initializer: str
    action_inventory: Mapping[str, str]
    policy_prompt: str
    system_prompt: str
    user_prompt: str
    critic_prompt: str
    reward_mapping: Mapping[str, float]
    termination_rule: str
    max_turns: int
    metrics: tuple[str, ...]
    blocked_reason: str | None = None
    schema_version: int = 3
    # DX-REPRO CHANGE 2026-07-17T02:40:00Z [DX-P3_5-003]
    # Base: 6ea4d579, registry.py:DatasetSpec
    # Reason: a shared raw case exposed future gold and cross-role private goals.
    # Behavior: every dataset explicitly registers fields visible to each audience.
    audience_fields: Mapping[str, tuple[str, ...]] = field(default_factory=dict)

    @property
    def action_names(self) -> tuple[str, ...]:
        return tuple(self.action_inventory)

    @property
    def action_registry_hash(self) -> str:
        payload = json.dumps(
            list(self.action_inventory.items()),
            ensure_ascii=True,
            separators=(",", ":"),
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def action_id(self, action: str) -> int:
        try:
            return self.action_names.index(action) + 1
        except ValueError as exc:
            raise KeyError(f"unregistered action for {self.name}: {action}") from exc


ESCONV_ACTIONS = {
    "Question": "Please ask the Patient to elaborate on the situation they just described.",
    "Self-disclosure": "Please provide a statement relating to the Patient about the situation they just described.",
    "Affirmation and Reassurance": "Please provide affirmation and reassurance to the Patient on the situation they just described.",
    "Providing Suggestions": "Please provide suggestion to the Patient on the situation they just described.",
    "Others": "Please chat with the Patient.",
    "Reflection of feelings": "Please acknowledge the Patient's feelings about the situation they described.",
    "Information": "Please provide factual information to help the Patient with their situation.",
    "Restatement or Paraphrasing": "Please acknowledge the Patient's feelings by paraphrasing their situation.",
}

CIMA_ACTIONS = {
    "Hint": "Provide a helpful hint without giving the answer.",
    "Question": "Ask a question that advances the student's understanding.",
    "Correction": "Correct a mistake or misconception.",
    "Confirmation": "Confirm a correct answer or understanding.",
    "Others": "Continue without a named pedagogical strategy.",
}

CB_ACTIONS = {
    "greet": "Greet or make brief small talk.",
    "inquire": "Ask about the product, condition, use, or price.",
    "inform": "Provide product or negotiation information.",
    "propose": "Initiate a price or range.",
    "counter": "Counter with a new price or range.",
    "counter-noprice": "Counter comparatively without an explicit price.",
    "confirm": "Ask for confirmation.",
    "affirm": "Affirm a confirmed point.",
    "deny": "Deny a proposed or confirmed point.",
    "agree": "Agree to the proposed price.",
    "disagree": "Disagree with the proposed price.",
}

EXTES_ACTIONS = {
    "Reflective Statements": "Reflect the user's thoughts or feelings.",
    "Clarification": "Ask for clarification or detail.",
    "Emotional Validation": "Validate the user's emotional experience.",
    "Empathetic Statements": "Express empathy.",
    "Affirmation": "Affirm efforts, strengths, or qualities.",
    "Offer Hope": "Offer hope or optimism.",
    "Avoid Judgment and Criticism": "Respond without judgment.",
    "Suggest Options": "Suggest options the user may consider.",
    "Collaborative Planning": "Invite collaborative planning.",
    "Provide Different Perspectives": "Offer an alternative perspective.",
    "Reframe Negative Thoughts": "Reframe negative thoughts constructively.",
    "Share Information": "Share relevant factual information.",
    "Normalize Experiences": "Normalize understandable experiences.",
    "Promote Self-Care Practices": "Encourage healthy self-care.",
    "Stress Management": "Offer stress-management strategies.",
    "Others": "Continue naturally and supportively.",
}

P4G_ACTIONS = {
    "Proposition of donation": "Propose a donation to Save the Children.",
    "Proposition of amount to be donated": "Propose a small donation amount.",
    "Proposition of confirmation of donation": "Ask for donation confirmation.",
    "Proposition of more donation": "Invite a larger donation if appropriate.",
    "Experience affirmation": "Affirm the persuadee's experience.",
    "Greeting": "Use a polite greeting.",
    "Ask for donation rejection purpose": "Ask why the persuadee is hesitant.",
    "Thank": "Thank the persuadee.",
    "Logical appeal": "Use a logical persuasive appeal.",
    "Emotion appeal": "Use an emotional persuasive appeal.",
    "Credibility appeal": "Use organizational credibility.",
    "Foot in the door": "Ask for a small initial commitment.",
    "Self-modeling": "Model charitable behavior personally.",
    "Donation information": "Explain how donations are used.",
    "Personal story": "Tell a concise relevant story.",
    "Source-related inquiry": "Ask about charity information sources.",
    "Task-related inquiry": "Ask about charitable-giving experience.",
    "Personal-related inquiry": "Ask about relevant values or priorities.",
    "Neutral inquiry": "Ask a neutral conversation-continuing question.",
}


def _literal_lines(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8", errors="surrogatepass") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            record = ast.literal_eval(line.rstrip("\n"))
            if not isinstance(record, dict):
                raise ValueError(f"{path}:{line_number}: record is not a mapping")
            records.append(record)
    return records


def _json_list(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, list) or not all(isinstance(item, dict) for item in value):
        raise ValueError(f"{path}: expected list[dict]")
    return value


DATASETS: dict[str, DatasetSpec] = {
    "esconv": DatasetSpec(
        "esconv", True, "Therapist", "Patient", "data/esc-train.txt", "data/esc-valid.txt",
        "data/esc-test.txt", _literal_lines, "esconv", ESCONV_ACTIONS,
        "esconv_policy", "esconv_system", "esconv_user", "esconv_critic",
        {"worse": -1.0, "same": -0.5, "better": 0.5, "solved": 1.0},
        "corrected_solved_only", 8, ("success_rate", "average_turns"),
        audience_fields={
            audience: ("emotion_type", "problem_type", "situation")
            for audience in ("planner", "policy", "system", "user", "critic", "emotion")
        },
    ),
    "cima": DatasetSpec(
        "cima", True, "Teacher", "Student", "data/cima-train.txt", "data/cima-valid.txt",
        "data/cima-test.txt", _literal_lines, "cima", CIMA_ACTIONS,
        "cima_policy", "cima_system", "cima_user", "cima_critic",
        {"incorrect": -1.0, "did_not": -0.5, "part": 0.5, "whole": 1.0},
        "whole_only", 8, ("success_rate", "average_turns"),
        audience_fields={
            "planner": ("sentence",),
            "policy": ("sentence",),
            "system": ("sentence",),
            "user": ("sentence",),
            "emotion": ("sentence",),
            "critic": ("sentence", "target"),
        },
    ),
    # DX-REPRO CHANGE 2026-07-16T07:34:00Z [DX-P1_5-005]
    # Upstream/local base: 37ee4ef/dialogxpert_repro/registry.py/CB DatasetSpec
    # Reason: CB is competitive/non-collaborative rather than collaborative.
    # Behavior: registry metadata now records the task relationship correctly.
    "cb": DatasetSpec(
        "cb", False, "Buyer", "Seller", "data/cb-train.txt", "data/cb-valid.txt",
        "data/cb-test.txt", _literal_lines, "cb", CB_ACTIONS,
        "cb_policy", "cb_system", "cb_user", "cb_critic", {},
        "deal_only", 8, ("success_rate", "average_turns", "sale_to_list"),
        audience_fields={
            "planner": ("item_name", "buyer_item_description", "buyer_price"),
            "policy": ("item_name", "buyer_item_description", "buyer_price"),
            "system": ("item_name", "buyer_item_description", "buyer_price"),
            "emotion": ("item_name", "buyer_item_description", "buyer_price"),
            "user": ("item_name", "seller_item_description", "seller_price"),
            "critic": (
                "item_name",
                "buyer_item_description",
                "seller_item_description",
                "buyer_price",
                "seller_price",
            ),
        },
    ),
    "p4g": DatasetSpec(
        "p4g", True, "Persuader", "Persuadee", "data/P4G/api_annotated/train.json",
        "data/P4G/api_annotated/dev.json", "data/P4G/api_annotated/test.json",
        _json_list, "p4g", P4G_ACTIONS, "p4g_policy", "p4g_system",
        "p4g_user", "p4g_critic",
        {"refused": -1.0, "neutral": -0.5, "positive": 0.1, "agree": 1.0},
        "agree_only", 8, ("success_rate", "average_turns"),
        audience_fields={
            audience: ()
            for audience in ("planner", "policy", "system", "user", "critic", "emotion")
        },
    ),
    "extes": DatasetSpec(
        "extes", True, "Therapist", "Patient", None, None, "data/ExTES/ExTES.json", _json_list,
        "extes", EXTES_ACTIONS, "extes_policy", "extes_system", "extes_user",
        "extes_critic", {"worse": -1.0, "same": -0.5, "solved": 1.0},
        "solved_only", 8, ("success_rate", "average_turns"),
        blocked_reason="aggregate file may contain sealed test records",
        audience_fields={},
    ),
}

ALIASES = {"esc": "esconv", "esconv": "esconv", "cima": "cima", "cb": "cb", "p4g": "p4g", "extes": "extes"}
CIMA_CORRECTED_QUARANTINE = frozenset({"cima:train:82"})


def canonical_record_id(record: Mapping[str, Any]) -> str:
    payload = json.dumps(record, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def get_dataset(name: str) -> DatasetSpec:
    try:
        return DATASETS[ALIASES[name.strip().lower()]]
    except KeyError as exc:
        raise KeyError(f"unknown dataset {name!r}; choices={sorted(DATASETS)}") from exc


def load_split(
    name: str,
    split: str,
    *,
    repo_root: str | Path | None = None,
    behavior_track: str = "corrected_primary",
) -> list[dict[str, Any]]:
    normalized_split = assert_development_split(split)
    spec = get_dataset(name)
    if spec.blocked_reason:
        raise DatasetBlockedError(f"{spec.name} BLOCKED: {spec.blocked_reason}")
    root = Path(repo_root) if repo_root is not None else Path(__file__).resolve().parents[1]
    selected = spec.train_path if normalized_split == "train" else spec.valid_path
    if selected is None:
        raise DatasetBlockedError(f"{spec.name} has no approved {normalized_split} path")
    safe_path = assert_safe_data_path(selected, root)
    records = spec.loader(safe_path)
    output: list[dict[str, Any]] = []
    canonical_split = "valid" if normalized_split == "dev" else normalized_split
    for row_index, raw in enumerate(records):
        # DX-REPRO CHANGE 2026-07-16T07:34:00Z [DX-P1_5-006]
        # Upstream/local base: 37ee4ef/dialogxpert_repro/registry.py/load_split
        # Reason: truthiness replaced a legitimate integer index=0 with a hash.
        # Behavior: any explicit non-null index is a stable case ID, including zero.
        stable_row_index = (
            raw["index"]
            if spec.name == "p4g" and "index" in raw and raw["index"] is not None
            else row_index
        )
        # DX-REPRO CHANGE 2026-07-17T04:31:00Z [DX-P3_6-003]
        # Base: 487c0874, registry.py:load_split
        # Reason: full-record hashes changed identity when future gold changed.
        # Behavior: identity is dataset/split/row; raw provenance is a separate hash.
        record_id = f"{spec.name}:{canonical_split}:{stable_row_index}"
        if (
            spec.name == "cima"
            and normalized_split == "train"
            and behavior_track == "corrected_primary"
            and record_id in CIMA_CORRECTED_QUARANTINE
        ):
            continue
        copied = dict(raw)
        copied["_dx_case_id"] = record_id
        copied["_dx_split"] = canonical_split
        copied["_dx_row_index"] = stable_row_index
        copied["_dx_provenance_sha256"] = canonical_record_id(raw)
        copied["_dx_behavior_track"] = behavior_track
        copied["_dx_schema_version"] = spec.schema_version
        copied["_dx_action_registry_hash"] = spec.action_registry_hash
        output.append(copied)
    return output
