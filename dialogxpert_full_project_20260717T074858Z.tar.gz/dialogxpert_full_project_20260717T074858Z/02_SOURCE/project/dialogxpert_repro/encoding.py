"""State-action pair encoding evidence shared by runtime and encoders.

Source: P3.5 action-truncation review.
Purpose: carry all candidate features, hashes, and truncation statistics.
Created: 2026-07-17T02:40:00Z.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Any

import torch


def feature_sha256(feature: torch.Tensor) -> str:
    value = feature.detach().cpu().contiguous()
    return hashlib.sha256(value.numpy().tobytes()).hexdigest()


def compact_cpu_tensor(value: torch.Tensor) -> torch.Tensor:
    """Return a contiguous CPU tensor owning exactly its logical storage."""

    return value.detach().to("cpu").contiguous().clone()


def tensor_storage_metadata(value: torch.Tensor) -> dict[str, Any]:
    """Expose logical versus backing-storage bytes for checkpoint audits."""

    logical_bytes = int(value.numel() * value.element_size())
    storage_bytes = int(value.untyped_storage().nbytes())
    return {
        "shape": list(value.shape),
        "numel": int(value.numel()),
        "element_size": int(value.element_size()),
        "logical_bytes": logical_bytes,
        "storage_bytes": storage_bytes,
        "is_contiguous": bool(value.is_contiguous()),
        "compact_storage": storage_bytes == logical_bytes,
    }


@dataclass(frozen=True)
class PairEncodingResult:
    features: torch.Tensor
    feature_hashes: tuple[str, ...]
    token_stats: tuple[dict[str, Any], ...]

    def __post_init__(self) -> None:
        if self.features.ndim != 2:
            raise ValueError("pair features must be rank 2")
        if self.features.shape[0] != len(self.feature_hashes):
            raise ValueError("feature/hash candidate count mismatch")
        if self.features.shape[0] != len(self.token_stats):
            raise ValueError("feature/token-stat candidate count mismatch")
        if any(not stat.get("action_preserved", False) for stat in self.token_stats):
            raise ValueError("action token truncation detected")
        storage = tensor_storage_metadata(self.features)
        if not storage["compact_storage"] or not storage["is_contiguous"]:
            raise ValueError(f"pair features do not own compact storage: {storage}")
