"""Corrected value-learning, replay, masking, and action selection.

Source: upstream llm_priors.py/train_model.py and audited Bellman defects.
Purpose: implement bounded replay and mathematically valid terminal targets.
Created: 2026-07-16T06:28:17Z.
"""

from __future__ import annotations

import random
from collections import deque
from dataclasses import asdict, dataclass
from typing import Any, Iterable

import torch
import torch.nn.functional as F

from .encoding import compact_cpu_tensor, tensor_storage_metadata


@dataclass
class Transition:
    behavior_track: str
    dataset: str
    split: str
    case_id: str
    turn_index: int
    planner_state_view: dict[str, Any]
    runtime_audit_state: dict[str, Any]
    state_text: str
    state_serialization: dict[str, Any]
    emotion_snapshot: tuple[dict[str, Any], ...]
    candidate_actions: tuple[str, ...]
    candidate_action_ids: tuple[int, ...]
    action_texts: tuple[str, ...]
    candidate_prior_metadata: dict[str, Any]
    candidate_features: torch.Tensor
    candidate_feature_hashes: tuple[str, ...]
    candidate_token_stats: tuple[dict[str, Any], ...]
    candidate_q_values: tuple[float, ...]
    candidate_mask: torch.Tensor
    epsilon: float
    selection_random_draw: float
    selection_mode: str
    selected_action_index: int
    selected_action: str
    selected_feature: torch.Tensor
    reward_aggregation: dict[str, Any]
    reward: float
    done: bool
    success: bool
    terminal_reason: str | None
    next_planner_state_view: dict[str, Any] | None
    next_state_text: str | None
    next_state_serialization: dict[str, Any] | None
    next_candidate_actions: tuple[str, ...]
    next_action_texts: tuple[str, ...]
    next_features: torch.Tensor
    next_feature_hashes: tuple[str, ...]
    next_token_stats: tuple[dict[str, Any], ...]
    next_candidate_q_values: tuple[float, ...]
    next_candidate_mask: torch.Tensor
    model_manifest: dict[str, Any]
    encoder_manifest: dict[str, Any]
    action_registry_hash: str
    episode_id: int
    rollout_id: str
    protocol_name: str
    protocol_hash: str

    def __post_init__(self) -> None:
        for name in ("candidate_features", "selected_feature", "next_features"):
            metadata = tensor_storage_metadata(getattr(self, name))
            if not metadata["compact_storage"] or not metadata["is_contiguous"]:
                raise ValueError(f"{name} does not own compact storage: {metadata}")

    def state_dict(self) -> dict[str, Any]:
        value = asdict(self)
        for key in (
            "candidate_features",
            "candidate_mask",
            "selected_feature",
            "next_features",
            "next_candidate_mask",
        ):
            value[key] = compact_cpu_tensor(value[key])
        return value

    @classmethod
    def from_state_dict(cls, value: dict[str, Any]) -> "Transition":
        return cls(**value)


class ReplayBuffer:
    # DX-REPRO CHANGE 2026-07-16T07:40:00Z [DX-P1_5-008]
    # Upstream/local base: 37ee4ef/dialogxpert_repro/rl.py/ReplayBuffer
    # Reason: sampling replacement, RNG state, and sampling count were implicit.
    # Behavior: replay owns a serializable sampler and explicit replacement policy.
    def __init__(self, capacity: int, *, seed: int = 0, sample_with_replacement: bool = True):
        if capacity < 1:
            raise ValueError("replay capacity must be positive")
        self.capacity = capacity
        self._data: deque[Transition] = deque(maxlen=capacity)
        self.sample_with_replacement = bool(sample_with_replacement)
        self._rng = random.Random(seed)
        self.sample_count = 0

    def append(self, transition: Transition) -> None:
        self._data.append(transition)

    def sample(
        self,
        batch_size: int,
        rng: random.Random | None = None,
        *,
        with_replacement: bool | None = None,
    ) -> list[Transition]:
        if not self._data:
            raise RuntimeError("cannot sample an empty replay buffer")
        if batch_size < 1:
            raise ValueError("batch_size must be positive")
        sampler = rng or self._rng
        replacement = self.sample_with_replacement if with_replacement is None else with_replacement
        population = tuple(self._data)
        if replacement:
            result = [sampler.choice(population) for _ in range(batch_size)]
        else:
            if batch_size > len(population):
                raise ValueError("batch_size exceeds replay size without replacement")
            result = sampler.sample(population, batch_size)
        self.sample_count += 1
        return result

    def __len__(self) -> int:
        return len(self._data)

    def state_dict(self) -> dict[str, Any]:
        return {
            "schema_version": 3,
            "capacity": self.capacity,
            "items": [item.state_dict() for item in self._data],
            "sample_with_replacement": self.sample_with_replacement,
            "sampler_rng_state": self._rng.getstate(),
            "sample_count": self.sample_count,
        }

    @classmethod
    def from_state_dict(cls, value: dict[str, Any]) -> "ReplayBuffer":
        expected = {
            "schema_version",
            "capacity",
            "items",
            "sample_with_replacement",
            "sampler_rng_state",
            "sample_count",
        }
        if set(value) != expected:
            raise ValueError(f"unexpected replay keys: {sorted(set(value) ^ expected)}")
        if value["schema_version"] != 3:
            raise ValueError("old/noncompact replay schema is not loadable")
        buffer = cls(
            int(value["capacity"]),
            sample_with_replacement=bool(value["sample_with_replacement"]),
        )
        for item in value["items"]:
            buffer.append(Transition.from_state_dict(item))
        buffer._rng.setstate(value["sampler_rng_state"])
        buffer.sample_count = int(value["sample_count"])
        return buffer


def masked_max(values: torch.Tensor, candidate_mask: torch.Tensor) -> torch.Tensor:
    if values.shape != candidate_mask.shape:
        raise ValueError(f"value/mask shape mismatch: {values.shape} vs {candidate_mask.shape}")
    if not torch.all(candidate_mask.any(dim=-1)):
        raise ValueError("every row must contain at least one candidate")
    masked = values.masked_fill(~candidate_mask.bool(), torch.finfo(values.dtype).min)
    return masked.max(dim=-1).values


def bellman_target(
    rewards: torch.Tensor,
    done: torch.Tensor,
    next_q_values: torch.Tensor,
    next_candidate_mask: torch.Tensor,
    *,
    gamma: float,
) -> torch.Tensor:
    if done.dtype is not torch.bool:
        raise TypeError("done must be torch.bool")
    # Terminal transitions intentionally have no next prior/candidates.
    nonterminal = ~done
    if torch.any(nonterminal & ~next_candidate_mask.bool().any(dim=-1)):
        raise ValueError("every nonterminal row must contain a next candidate")
    next_max = torch.zeros_like(rewards)
    if torch.any(nonterminal):
        next_max[nonterminal] = masked_max(
            next_q_values[nonterminal],
            next_candidate_mask[nonterminal],
        )
    return rewards + float(gamma) * (~done).to(rewards.dtype) * next_max


def select_action(
    q_values: torch.Tensor,
    candidate_mask: torch.Tensor,
    *,
    epsilon: float,
    rng: random.Random,
) -> int:
    return select_action_with_evidence(
        q_values,
        candidate_mask,
        epsilon=epsilon,
        rng=rng,
    ).index


@dataclass(frozen=True)
class ActionSelection:
    index: int
    random_draw: float
    mode: str


def select_action_with_evidence(
    q_values: torch.Tensor,
    candidate_mask: torch.Tensor,
    *,
    epsilon: float,
    rng: random.Random,
) -> ActionSelection:
    """Select once while persisting the exact epsilon draw and decision mode."""

    # DX-REPRO CHANGE 2026-07-17T02:40:00Z [DX-P3_5-005]
    # Base: 6ea4d579, rl.py:select_action
    # Reason: behavior-time selection/Q evidence was not persisted.
    # Behavior: return the selected index, RNG draw, and random/argmax mode.
    valid = candidate_mask.bool().nonzero(as_tuple=False).flatten().tolist()
    if not valid:
        raise ValueError("candidate set is empty")
    draw = rng.random()
    if draw < epsilon:
        return ActionSelection(int(rng.choice(valid)), draw, "random")
    masked = q_values.masked_fill(~candidate_mask.bool(), torch.finfo(q_values.dtype).min)
    return ActionSelection(int(masked.argmax().item()), draw, "argmax")


@torch.no_grad()
def soft_update(target: torch.nn.Module, source: torch.nn.Module, tau: float) -> None:
    if not 0.0 < tau <= 1.0:
        raise ValueError("tau must be in (0, 1]")
    for target_param, source_param in zip(target.parameters(), source.parameters()):
        target_param.mul_(1.0 - tau).add_(source_param, alpha=tau)


def train_qnetwork(
    transitions: Iterable[Transition],
    optimizer: torch.optim.Optimizer,
    online_head: torch.nn.Module,
    target_head: torch.nn.Module,
    device: str | torch.device,
    *,
    gamma: float,
    tau: float = 0.005,
) -> float:
    batch = list(transitions)
    if not batch:
        raise RuntimeError("Q update requires at least one transition")
    dev = torch.device(device)
    current = torch.stack([item.selected_feature for item in batch]).to(dev).float()
    rewards = torch.tensor([item.reward for item in batch], device=dev, dtype=torch.float32)
    done = torch.tensor([item.done for item in batch], device=dev, dtype=torch.bool)
    max_candidates = max(max(item.next_features.shape[0], 1) for item in batch)
    feature_dim = batch[0].next_features.shape[-1]
    next_features = torch.zeros(len(batch), max_candidates, feature_dim, device=dev)
    next_mask = torch.zeros(len(batch), max_candidates, dtype=torch.bool, device=dev)
    for index, item in enumerate(batch):
        count = item.next_features.shape[0]
        next_features[index, :count] = item.next_features.to(dev).float()
        next_mask[index, :count] = item.next_candidate_mask[:count].to(dev).bool()
    predicted = online_head(current)
    with torch.no_grad():
        next_values = target_head(next_features)
        targets = bellman_target(rewards, done, next_values, next_mask, gamma=gamma)
    loss = F.mse_loss(predicted, targets)
    optimizer.zero_grad(set_to_none=True)
    loss.backward()
    torch.nn.utils.clip_grad_norm_(online_head.parameters(), 1.0)
    optimizer.step()
    soft_update(target_head, online_head, tau)
    return float(loss.detach().cpu())
