"""Deterministic known-MDP convergence gates for value-learning semantics.

Source: P3.6 requirement for ToyBandit and delayed-reward Two-Step MDP.
Purpose: reject broken action choice, gamma, terminal masks, or reward association.
Created: 2026-07-17T05:10:00Z.
"""

from __future__ import annotations

import random
from dataclasses import dataclass

import torch
import torch.nn.functional as F

from .qnet import QMLP


@dataclass(frozen=True)
class KnownMDPResult:
    seed: int
    q_values: dict[str, tuple[float, ...]]
    selected_action: str
    converged: bool
    reward_shuffle: bool = False


def _fixed_features(seed: int) -> torch.Tensor:
    generator = torch.Generator().manual_seed(seed + 10_000)
    features = torch.randn(4, 32, generator=generator)
    return F.normalize(features, dim=-1)


def run_toy_bandit(seed: int, *, episodes: int = 1200) -> KnownMDPResult:
    torch.manual_seed(seed)
    features = _fixed_features(0)
    rewards = torch.tensor([-0.4, 0.0, 0.3, 1.0])
    online = QMLP(32)
    optimizer = torch.optim.AdamW(online.parameters(), lr=3e-3, weight_decay=0.0)
    for _ in range(episodes):
        loss = F.mse_loss(online(features), rewards)
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
    with torch.no_grad():
        q = online(features).tolist()
    return KnownMDPResult(
        seed, {"bandit": tuple(q)}, f"a{max(range(4), key=q.__getitem__)}",
        max(range(4), key=q.__getitem__) == 3,
    )


def run_two_step(seed: int, *, episodes: int = 1800,
                 gamma: float = 0.9, reward_shuffle: bool = False) -> KnownMDPResult:
    torch.manual_seed(seed)
    features = _fixed_features(1)
    online = QMLP(32)
    target = QMLP(32)
    target.load_state_dict(online.state_dict())
    optimizer = torch.optim.AdamW(online.parameters(), lr=3e-3, weight_decay=0.0)
    short_reward, goal_reward = ((1.0, 0.6) if reward_shuffle else (0.6, 1.0))
    for episode in range(episodes):
        with torch.no_grad():
            target_q1 = target(features[2:4]).max()
            targets = torch.tensor([
                short_reward, gamma * float(target_q1), goal_reward, 0.0
            ])
        loss = F.mse_loss(online(features), targets)
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
        if (episode + 1) % 20 == 0:
            target.load_state_dict(online.state_dict())
    with torch.no_grad():
        values = online(features).tolist()
    q0 = values[:2]
    q1 = values[2:]
    selected = "advance" if q0[1] > q0[0] else "short"
    expected = "short" if reward_shuffle else "advance"
    return KnownMDPResult(
        seed, {"s0": tuple(q0), "s1": tuple(q1)}, selected,
        selected == expected, reward_shuffle,
    )
