"""Validation-only metrics and failure accounting.

Source: local metrics contract and upstream AT/SR reporting.
Purpose: keep attempted/completed/failed denominators explicit by behavior track.
Created: 2026-07-16T06:28:17Z.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass, field
from typing import Any, Iterable

from .state import EMOTION_ALIAS_SHA256, EMOTION_ALIAS_VERSION


@dataclass
class RunMetrics:
    behavior_track: str
    dataset: str
    split: str
    seed: int
    protocol_name: str = ""
    protocol_hash: str = ""
    attempted_episodes: int = 0
    eligible_episodes: int = 0
    completed_episodes: int = 0
    solved_episodes: int = 0
    failed_episodes: int = 0
    quarantined_episodes: int = 0
    total_turns: int = 0
    completed_turns: int = 0
    total_reward: float = 0.0
    completed_reward: float = 0.0
    parse_failures: int = 0
    prior_parse_failures: int = 0
    generation_failures: int = 0
    timeouts: int = 0
    quarantined_case_ids: list[str] = field(default_factory=list)
    generate_invocations: int = 0
    returned_completions: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    retries: int = 0
    generation_invocations_by_role: dict[str, int] = field(default_factory=dict)
    returned_sequences_by_role: dict[str, int] = field(default_factory=dict)
    valid_parses_by_role: dict[str, int] = field(default_factory=dict)
    invalid_parses_by_role: dict[str, int] = field(default_factory=dict)
    retries_by_role: dict[str, int] = field(default_factory=dict)
    unique_output_values_by_role: dict[str, list[str]] = field(default_factory=dict)
    critic_requested: int = 0
    critic_valid: int = 0
    critic_invalid: int = 0
    # DX-REPRO CHANGE 2026-07-17T05:20:00Z [DX-P3_6-024]
    # Base: 8f06af6, metrics.py:RunMetrics
    # Reason: live evidence omitted emotion normalization coverage and OOV incidence.
    # Behavior: publish the counted denominator plus immutable alias-map provenance.
    emotion_observations: int = 0
    emotion_oov: int = 0
    emotion_normalization_version: str = EMOTION_ALIAS_VERSION
    emotion_normalization_sha256: str = EMOTION_ALIAS_SHA256
    termination_distribution: dict[str, int] | None = None

    def summary(self) -> dict[str, object]:
        # DX-REPRO CHANGE 2026-07-16T07:40:00Z [DX-P1_5-009]
        # Upstream/local base: 37ee4ef/dialogxpert_repro/metrics.py/RunMetrics.summary
        # Reason: attempted-only denominators hid quarantine and depressed AT.
        # Behavior: attempted, eligible, and completed denominators are explicit.
        result = asdict(self)
        attempted = max(self.attempted_episodes, 1)
        eligible = max(self.eligible_episodes, 1)
        completed = max(self.completed_episodes, 1)
        result["SR_attempted"] = self.solved_episodes / attempted
        result["SR_eligible"] = self.solved_episodes / eligible
        result["AT_attempted"] = self.total_turns / attempted
        result["AT_completed"] = self.completed_turns / completed
        result["average_reward_attempted"] = self.total_reward / attempted
        result["average_reward_completed"] = self.completed_reward / completed
        result["critic_validity"] = self.critic_valid / max(self.critic_requested, 1)
        result["emotion_oov_rate"] = self.emotion_oov / max(self.emotion_observations, 1)
        prior_returned = self.returned_sequences_by_role.get("prior", 0)
        result["prior_parse_failure_rate"] = self.prior_parse_failures / max(
            prior_returned, 1
        )
        result["quarantined_cases"] = len(set(self.quarantined_case_ids))
        result["unique_outputs_by_role"] = {
            role: len(values)
            for role, values in sorted(self.unique_output_values_by_role.items())
        }
        result.pop("unique_output_values_by_role", None)
        result["termination_distribution"] = dict(
            sorted((self.termination_distribution or {}).items())
        )
        return result

    def record_termination(self, reason: str) -> None:
        counts = Counter(self.termination_distribution or {})
        counts[reason] += 1
        self.termination_distribution = dict(counts)

    def record_generation_records(self, records: Iterable[Any]) -> None:
        """Account invocations and returned sequences using role-correct denominators."""

        # DX-REPRO CHANGE 2026-07-17T02:46:00Z [DX-P3_5-009]
        # Base: 6ea4d579, runtime.py:_account_backend_records
        # Reason: P3 counted parsed completions as returned and used all roles for prior failure.
        # Behavior: record per-role invocations, sequences, parses, retries, and unique outputs.
        values = list(records)
        invocation_keys: set[tuple[str, int]] = set()
        new_retries = 0
        for record in values:
            role = str(record.role)
            invocation_keys.add((role, int(record.invocation)))
            self.returned_sequences_by_role[role] = (
                self.returned_sequences_by_role.get(role, 0) + 1
            )
            valid = record.parse_status == "PASS"
            target = self.valid_parses_by_role if valid else self.invalid_parses_by_role
            target[role] = target.get(role, 0) + 1
            if role == "prior" and not valid:
                self.prior_parse_failures += 1
            if int(record.attempt) > 1:
                self.retries_by_role[role] = self.retries_by_role.get(role, 0) + 1
                new_retries += 1
            outputs = self.unique_output_values_by_role.setdefault(role, [])
            if record.raw_output not in outputs:
                outputs.append(record.raw_output)
            self.prompt_tokens += int(record.prompt_tokens)
            self.completion_tokens += int(record.completion_tokens)
        for role, _ in invocation_keys:
            self.generation_invocations_by_role[role] = (
                self.generation_invocations_by_role.get(role, 0) + 1
            )
        self.generate_invocations += len(invocation_keys)
        self.returned_completions += len(values)
        self.retries += new_retries
