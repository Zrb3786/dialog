"""Machine-readable released, Appendix, and corrected protocol contracts.

Source: released code, extended-paper Appendix, and P3.6 review resolution.
Purpose: prevent incompatible prompts/rewards/termination semantics from sharing a label.
Created: 2026-07-17T04:47:00Z.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, replace


@dataclass(frozen=True)
class ProtocolConfig:
    name: str
    prior_variant: str
    action_selection: str
    response_generation: str
    emotion_tracker_variant: str
    emotion_in_q: bool
    system_prompt_variant: str
    user_prompt_variant: str
    critic_prompt_variant: str
    critic_sampling: str
    reward_aggregation: str
    reward_policy: str
    termination_policy: str
    q_state_variant: str
    pooling: str
    epsilon_schedule: str
    generation_seed_policy: str
    generation_profile: str
    prompt_contract: str

    @property
    def sha256(self) -> str:
        payload = json.dumps(asdict(self), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()


PROTOCOLS = {
    "released_code_compat": ProtocolConfig(
        name="released_code_compat",
        prior_variant="released_integer_top4_v1",
        action_selection="integer_top4",
        response_generation="coupled_response",
        emotion_tracker_variant="tracker_text_only",
        emotion_in_q=False,
        system_prompt_variant="released_code_system_v1",
        user_prompt_variant="released_code_user_v1",
        critic_prompt_variant="critic_released_code_v1",
        critic_sampling="released_single_or_greedy",
        reward_aggregation="released_any_label_v1",
        reward_policy="released_reward",
        termination_policy="better_or_solved",
        q_state_variant="released_no_current_emotion_v1",
        pooling="cls",
        epsilon_schedule="released_linear_1_to_0_1",
        generation_seed_policy="episode-addressable-v1",
        generation_profile="paper_prior_t1_p1_roles_greedy_v1",
        prompt_contract="released_code",
    ),
    "extended_prompt_faithful": ProtocolConfig(
        name="extended_prompt_faithful",
        prior_variant="esconv_appendix_policy_exact_v1",
        action_selection="integer_top4",
        response_generation="coupled_response",
        emotion_tracker_variant="tracker_text_only",
        emotion_in_q=True,
        system_prompt_variant="esconv_appendix_system_exact_v1",
        user_prompt_variant="esconv_appendix_user_exact_v1",
        critic_prompt_variant="critic_appendix_full_sentence_v1",
        critic_sampling="sampled_10_t1_p1",
        reward_aggregation="appendix_mean_then_majority_v1",
        reward_policy="appendix_reward",
        termination_policy="appendix_declared",
        q_state_variant="recency_critical_first_v2",
        pooling="cls",
        epsilon_schedule="appendix_public_linear_1_to_0_1",
        generation_seed_policy="episode-addressable-v1",
        generation_profile="paper_prior_t1_p1_roles_greedy_v1",
        prompt_contract="extended_appendix_exact",
    ),
    "corrected_resolved_only": ProtocolConfig(
        name="corrected_resolved_only",
        prior_variant="dataset_specific_corrected_v1",
        action_selection="prior_then_q",
        response_generation="role_separated",
        emotion_tracker_variant="tracker_text_only",
        emotion_in_q=True,
        system_prompt_variant="dataset_specific_corrected_v1",
        user_prompt_variant="dataset_specific_corrected_v1",
        critic_prompt_variant="critic_compact_enum_v1",
        critic_sampling="sampled_majority_10",
        reward_aggregation="corrected_consensus_v2",
        reward_policy="better_positive_nonterminal",
        termination_policy="solved_only",
        q_state_variant="recency_critical_first_v2",
        pooling="cls",
        epsilon_schedule="configured_explicit_v1",
        generation_seed_policy="episode-addressable-v1",
        generation_profile="corrected_role_specific_v1",
        prompt_contract="corrected_causal",
    ),
}

# Explicit ablations receive independent hashes instead of silently overriding a
# primary protocol while retaining its provenance.
PROTOCOLS["corrected_case_oracle_ablation"] = replace(
    PROTOCOLS["corrected_resolved_only"],
    name="corrected_case_oracle_ablation",
    emotion_tracker_variant="tracker_case_oracle",
    q_state_variant="recency_critical_first_v2_with_oracle_initial_emotion",
    prompt_contract="corrected_oracle_ablation",
)
PROTOCOLS["corrected_no_emotion_ablation"] = replace(
    PROTOCOLS["corrected_resolved_only"],
    name="corrected_no_emotion_ablation",
    emotion_tracker_variant="no_emotion",
    emotion_in_q=False,
    q_state_variant="recency_critical_first_v2_no_emotion",
    prompt_contract="corrected_no_emotion_ablation",
)
PROTOCOLS["corrected_masked_mean_ablation"] = replace(
    PROTOCOLS["corrected_resolved_only"],
    name="corrected_masked_mean_ablation",
    pooling="masked_mean",
    prompt_contract="corrected_masked_mean_ablation",
)
# DX-REPRO CHANGE 2026-07-17T06:25:00Z [DX-P3_6-031]
# A0 prior-only and A3 all-eight controls need independent machine-readable
# identities; neither may inherit the corrected top-four protocol hash.
PROTOCOLS["corrected_all8_q_pilot"] = replace(
    PROTOCOLS["corrected_resolved_only"],
    name="corrected_all8_q_pilot",
    action_selection="all8_q",
    prior_variant="all8_no_prior_v1",
    prompt_contract="corrected_all8_q_pilot",
)
PROTOCOLS["corrected_prior_only_pilot"] = replace(
    PROTOCOLS["corrected_resolved_only"],
    name="corrected_prior_only_pilot",
    action_selection="prior_only",
    epsilon_schedule="disabled_prior_only",
    prompt_contract="corrected_prior_only_pilot",
)


def get_protocol(name: str) -> ProtocolConfig:
    try:
        return PROTOCOLS[name]
    except KeyError as exc:
        raise ValueError(f"unknown protocol: {name}") from exc
