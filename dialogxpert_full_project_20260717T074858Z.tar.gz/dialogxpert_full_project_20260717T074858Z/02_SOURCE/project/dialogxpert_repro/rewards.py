"""Structured critic parsing, rewards, and termination decisions.

Source: upstream env.py reward dictionaries and extended-paper Appendix E.
Purpose: eliminate substring bias and separate success from timeout reasons.
Created: 2026-07-16T06:28:17Z.
"""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass
from statistics import fmean, median
from typing import Any, Iterable

from .registry import DatasetSpec


class CriticParseError(ValueError):
    """Raised when a critic completion is not in the configured schema."""


# DX-REPRO CHANGE 2026-07-16T07:34:00Z [DX-P1_5-001]
# Upstream/local base: 37ee4ef/dialogxpert_repro/rewards.py/CriticAggregation
# Reason: corrected success previously accepted any isolated success label.
# Behavior: corrected_consensus exposes validity, majority, tie, and policy evidence.
@dataclass(frozen=True)
class CriticAggregation:
    requested_count: int
    valid_count: int
    invalid_count: int
    labels: tuple[str, ...]
    rewards: tuple[float, ...]
    label_counts: dict[str, int]
    majority_label: str
    invalid_outputs: tuple[str, ...]
    aggregate_reward: float
    consensus_ratio: float
    aggregation_policy: str
    deal_price_median: float | None = None
    schema_failure: bool = False


class CriticSchemaFailure(CriticParseError):
    """Raised when corrected consensus lacks enough valid completions."""

    def __init__(self, aggregation: CriticAggregation):
        super().__init__(
            f"critic_schema_failure: valid={aggregation.valid_count} "
            f"required by {aggregation.aggregation_policy}"
        )
        self.aggregation = aggregation


@dataclass(frozen=True)
class TerminationOutcome:
    done: bool
    success: bool
    reason: str | None


def _exact_label(output: str, labels: Iterable[str]) -> str:
    full_sentence_aliases = {
        "no, the patient feels worse.": "worse",
        "no, the patient feels the same.": "same",
        "no, but the patient feels better.": "better",
        "no, but the patient feels somewhat better.": "better",
        "yes, the patient's issue has been solved.": "solved",
        "yes, the patient's emotional issues have been resolved.": "solved",
        "no, the student made an incorrect translation.": "incorrect",
        "no, the student did not try to translate.": "did_not",
        "the persuadee has explicitly refused.": "refused",
        "the persuadee remains neutral about donating.": "neutral",
        "the persuadee has a positive attitude towards donating but hasn't decided yet.": "positive",
        "the persuadee has decided to donate.": "agree",
    }
    sentence = output.strip().casefold()
    if sentence in full_sentence_aliases and full_sentence_aliases[sentence] in labels:
        return full_sentence_aliases[sentence]
    if sentence.startswith("no, the student only correctly translated a part of"):
        return "part"
    if sentence.startswith("yes, the student correctly translated the whole sentence of"):
        return "whole"
    normalized = sentence.replace(" ", "_")
    allowed = {label.casefold(): label for label in labels}
    if normalized not in allowed:
        raise CriticParseError(f"critic output is not an exact enum: {output!r}")
    return allowed[normalized]


def _cb_reward(output: str, case: dict[str, Any]) -> tuple[str, float, float | None]:
    text = output.strip().casefold()
    if text == "no_deal":
        return "no_deal", 0.0, None
    match = re.fullmatch(r"deal\s*:\s*(-?\d+(?:\.\d+)?)", text)
    if not match:
        raise CriticParseError(f"invalid CB critic output: {output!r}")
    price = float(match.group(1))
    seller = float(case["seller_price"])
    buyer = float(case["buyer_price"])
    denominator = buyer - seller
    if denominator == 0:
        raise CriticParseError("CB buyer and seller prices yield zero reward denominator")
    lower, upper = sorted((seller, buyer))
    if not lower <= price <= upper:
        raise CriticParseError(
            f"CB deal price {price} outside registered negotiation range [{lower}, {upper}]"
        )
    return "deal", (price - seller) / denominator, price


def _conservative_majority(
    counts: Counter[str],
    reward_by_label: dict[str, float],
) -> str:
    highest = max(counts.values())
    tied = [label for label, count in counts.items() if count == highest]
    return min(tied, key=lambda label: (reward_by_label[label], label))


def aggregate_critic_outputs(
    spec: DatasetSpec,
    outputs: Iterable[str],
    case: dict[str, Any],
    *,
    requested_count: int | None = None,
    min_valid: int = 8,
    aggregation_policy: str = "corrected_consensus_v2",
) -> CriticAggregation:
    # DX-REPRO CHANGE 2026-07-16T07:34:00Z [DX-P1_5-002]
    # Upstream/local base: 37ee4ef/dialogxpert_repro/rewards.py/aggregate_critic_outputs
    # Reason: invalid-output dropping plus any-success termination inflated SR.
    # Behavior: fail closed below min_valid and choose a conservative majority label.
    output_list = list(outputs)
    requested = len(output_list) if requested_count is None else int(requested_count)
    if requested < len(output_list):
        raise ValueError("requested_count cannot be smaller than returned outputs")
    if min_valid < 1:
        raise ValueError("min_valid must be positive")
    labels: list[str] = []
    rewards: list[float] = []
    invalid: list[str] = []
    deal_prices: list[float] = []
    reward_by_label: dict[str, float] = {}
    for output in output_list:
        try:
            if spec.name == "cb":
                label, reward, price = _cb_reward(output, case)
                if price is not None:
                    deal_prices.append(price)
            else:
                label = _exact_label(output, spec.reward_mapping)
                reward = float(spec.reward_mapping[label])
            labels.append(label)
            rewards.append(reward)
            reward_by_label[label] = min(reward_by_label.get(label, reward), reward)
        except CriticParseError:
            invalid.append(output)
    counts = Counter(labels)
    missing = requested - len(output_list)
    valid_count = len(labels)
    invalid_count = len(invalid) + missing
    majority = _conservative_majority(counts, reward_by_label) if counts else "invalid"
    aggregation = CriticAggregation(
        requested_count=requested,
        valid_count=valid_count,
        invalid_count=invalid_count,
        labels=tuple(labels),
        rewards=tuple(rewards),
        label_counts=dict(sorted(counts.items())),
        majority_label=majority,
        invalid_outputs=tuple(invalid),
        aggregate_reward=fmean(rewards) if rewards else 0.0,
        consensus_ratio=(counts[majority] / valid_count) if valid_count else 0.0,
        aggregation_policy=aggregation_policy,
        deal_price_median=median(deal_prices) if deal_prices else None,
        schema_failure=valid_count < min_valid,
    )
    if aggregation.schema_failure:
        raise CriticSchemaFailure(aggregation)
    return aggregation


def decide_termination(
    spec: DatasetSpec,
    aggregation: CriticAggregation | Iterable[str],
    *,
    turn_index: int,
    behavior_track: str,
    max_turns: int | None = None,
) -> TerminationOutcome:
    # DX-REPRO CHANGE 2026-07-16T07:34:00Z [DX-P1_5-003]
    # Upstream/local base: 37ee4ef/dialogxpert_repro/rewards.py/decide_termination
    # Reason: one solved/deal completion previously terminated the episode.
    # Behavior: corrected tracks terminate only from the conservative majority.
    if isinstance(aggregation, CriticAggregation):
        majority_label = aggregation.majority_label
        label_set = set(aggregation.labels)
    else:
        labels = tuple(aggregation)
        label_set = set(labels)
        majority_label = next(iter(label_set)) if len(label_set) == 1 else ""
    success_labels = {"esconv": "solved", "cima": "whole", "p4g": "agree", "extes": "solved"}
    if behavior_track == "repository_diagnostic" and spec.name == "esconv":
        success = bool({"better", "solved"} & label_set)
    elif spec.name == "cb":
        success = majority_label == "deal"
    else:
        success = majority_label == success_labels.get(spec.name)
    if success:
        return TerminationOutcome(True, True, "success")
    if turn_index + 1 >= (spec.max_turns if max_turns is None else max_turns):
        return TerminationOutcome(True, False, "max_turn_failure")
    return TerminationOutcome(False, False, None)
