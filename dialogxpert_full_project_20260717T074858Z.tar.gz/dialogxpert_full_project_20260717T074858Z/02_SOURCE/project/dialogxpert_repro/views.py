"""Causal, audience-scoped views for planning and model prompts.

Source: P3.5 external semantic review of raw-case and future-gold leakage.
Purpose: expose only explicitly registered current information to each audience.
Created: 2026-07-17T02:40:00Z.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from typing import Any, Mapping, TYPE_CHECKING

from .registry import DatasetBlockedError, DatasetSpec

if TYPE_CHECKING:
    from .state import RuntimeState


PRIVILEGED_PLANNER_KEYS = frozenset(
    {
        "dialog",
        "strategy",
        "last_reward",
        "terminal_reason",
        "critic_labels",
        "reward_aggregation",
    }
)


@dataclass(frozen=True)
class PlannerStateView:
    """Deployment-causal state consumed by the prior and Q network only."""

    dataset: str
    public_case_context: dict[str, Any]
    conversation: tuple[dict[str, str], ...]
    emotion_history: tuple[dict[str, Any], ...]
    turn_index: int

    def as_dict(self) -> dict[str, Any]:
        value = asdict(self)
        assert_causal_planner_payload(value)
        return value

    def canonical_text(self) -> str:
        return json.dumps(
            self.as_dict(),
            sort_keys=True,
            ensure_ascii=True,
            separators=(",", ":"),
        )


def assert_causal_planner_payload(value: Any) -> None:
    """Fail closed if privileged/internal keys appear anywhere in a Q payload."""

    if isinstance(value, Mapping):
        for key, nested in value.items():
            name = str(key)
            if name.startswith("_dx_") or name in PRIVILEGED_PLANNER_KEYS:
                raise ValueError(f"privileged planner key is forbidden: {name}")
            assert_causal_planner_payload(nested)
    elif isinstance(value, (list, tuple)):
        for nested in value:
            assert_causal_planner_payload(nested)


def audience_case_view(
    spec: DatasetSpec,
    case: Mapping[str, Any],
    *,
    audience: str,
    emotion_tracker_variant: str | None = None,
) -> dict[str, Any]:
    """Return only case fields registered for the requested model audience."""

    if spec.blocked_reason:
        raise DatasetBlockedError(f"{spec.name} BLOCKED: {spec.blocked_reason}")
    try:
        allowed = spec.audience_fields[audience]
    except KeyError as exc:
        raise ValueError(f"unknown/unregistered audience for {spec.name}: {audience}") from exc
    view = {field: case[field] for field in allowed if field in case}
    if (
        spec.name == "esconv"
        and audience in {"planner", "policy"}
        and emotion_tracker_variant in {"tracker_text_only", "no_emotion"}
    ):
        # DX-REPRO CHANGE 2026-07-17T05:42:00Z [DX-P3_6-028]
        # Base: 3793c14, views.py:audience_case_view
        # Reason: text-only/no-emotion paths still exposed gold initial emotion
        # to Q and prior through the static ESConv audience registry.
        # Behavior: initial emotion is visible only to the explicit oracle path.
        view.pop("emotion_type", None)
    if any(key.startswith("_dx_") for key in view):
        raise ValueError("internal registry metadata cannot enter an audience view")
    return view


def build_planner_state_view(
    spec: DatasetSpec,
    case: Mapping[str, Any],
    state: RuntimeState,
    *,
    emotion_tracker_variant: str = "tracker_case_oracle",
    include_emotion: bool = True,
) -> PlannerStateView:
    """Freeze a causal planner snapshot independent of the runtime audit object."""

    # DX-REPRO CHANGE 2026-07-17T02:40:00Z [DX-P3_5-002]
    # Base: 6ea4d579, state.py:DialogueState/as_serializable
    # Reason: raw case metadata exposed future gold dialogue and privileged reward.
    # Behavior: Q sees only registered public context and generated history prefix.
    view = PlannerStateView(
        dataset=spec.name,
        public_case_context=audience_case_view(
            spec, case, audience="planner",
            emotion_tracker_variant=emotion_tracker_variant,
        ),
        conversation=tuple(dict(turn) for turn in state.conversation),
        emotion_history=(
            tuple({
                "label": item.label,
                "source_turn_index": item.source_turn_index,
                "tracker_variant": item.tracker_variant,
            } for item in state.emotion_history)
            if include_emotion else ()
        ),
        turn_index=int(state.turn_index),
    )
    view.as_dict()
    return view
