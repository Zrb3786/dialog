"""Standalone local and scripted LLM backends for corrected DialogXpert.

Source: external P1.5 runtime review and local-only model policy.
Purpose: execute role-separated generation without FastChat or legacy Env.
Created: 2026-07-16T07:44:00Z.
"""

from __future__ import annotations

import abc
import hashlib
import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable, Mapping

from .parsers import (
    StructuredOutputError,
    parse_coupled_emotion_response,
    parse_emotion_json,
    parse_short_response,
)
from .prior import ActionPriorParseError, ActionPriorResult, parse_prompt_faithful
from .prompts import build_emotion_messages, build_policy_messages, build_roleplay_messages
from .registry import DatasetSpec
from .rewards import CriticParseError, aggregate_critic_outputs
from .state import DialogueState
from .seeding import functional_seed
from .protocols import get_protocol


@dataclass(frozen=True)
class GenerationRecord:
    # DX-REPRO CHANGE 2026-07-17T02:42:00Z [DX-P3_5-010]
    # Base: 6ea4d579, backend.py:GenerationRecord
    # Reason: P3 records omitted exact prompts, case/turn identity, and sequence identity.
    # Behavior: every completion retains immutable runtime and generation evidence.
    invocation: int
    sequence_index: int
    role: str
    case_id: str
    split: str
    track: str
    turn: int
    seed: int
    attempt: int
    messages: tuple[dict[str, str], ...]
    canonical_prompt: str
    prompt_sha256: str
    generation_config: dict[str, Any]
    prompt_tokens: int
    completion_tokens: int
    raw_output: str
    parse_status: str
    episode_id: int = 0
    rollout_id: str = "primary"
    protocol_name: str = "unset"
    protocol_hash: str = "unset"


@dataclass(frozen=True)
class SystemGeneration:
    response: str
    emotion: dict[str, str] | None = None


@dataclass(frozen=True)
class RoleGenerationConfig:
    max_new_tokens: int
    do_sample: bool
    temperature: float = 1.0
    top_p: float = 1.0
    num_return_sequences: int = 1


def default_role_generation_configs() -> dict[str, RoleGenerationConfig]:
    return {
        "emotion": RoleGenerationConfig(64, False),
        "prior": RoleGenerationConfig(25, True, 1.0, 0.9),
        "system": RoleGenerationConfig(100, False),
        "user": RoleGenerationConfig(100, False),
        "critic": RoleGenerationConfig(12, True, 1.0, 1.0, 10),
    }


class LLMBackend(abc.ABC):
    records: list[GenerationRecord]
    call_order: list[str]

    def set_episode_context(self, *, case_id: str, split: str, track: str,
                            episode_id: int = 0, rollout_id: str = "primary",
                            protocol_name: str = "unset", protocol_hash: str = "unset",
                            seed_root: int | None = None) -> None:
        if protocol_name != "unset":
            protocol = get_protocol(protocol_name)
            if protocol_hash != protocol.sha256:
                raise ValueError("episode context protocol hash mismatch")
        self._episode_context = {
            "case_id": case_id, "split": split, "track": track,
            "episode_id": int(episode_id), "rollout_id": rollout_id,
            "protocol_name": protocol_name, "protocol_hash": protocol_hash,
            "seed_root": int(getattr(self, "seed", 0) if seed_root is None else seed_root),
        }

    def current_protocol(self):
        name = self._episode_context["protocol_name"]
        if name == "unset":
            raise RuntimeError("backend protocol context is unset")
        return get_protocol(name)

    @property
    @abc.abstractmethod
    def manifest(self) -> dict[str, Any]:
        raise NotImplementedError

    @abc.abstractmethod
    def infer_emotion(
        self, spec: DatasetSpec, case: dict[str, Any], state: DialogueState,
        *, tracker_variant: str = "tracker_text_only",
    ) -> dict[str, str]:
        raise NotImplementedError

    @abc.abstractmethod
    def propose_actions(
        self,
        spec: DatasetSpec,
        case: dict[str, Any],
        state: DialogueState,
        *,
        top_k: int,
        behavior_track: str,
    ) -> ActionPriorResult:
        raise NotImplementedError

    @abc.abstractmethod
    def generate_system_response(
        self,
        spec: DatasetSpec,
        case: dict[str, Any],
        state: DialogueState,
        *,
        action: str,
        behavior_track: str,
    ) -> SystemGeneration:
        raise NotImplementedError

    @abc.abstractmethod
    def simulate_user(
        self, spec: DatasetSpec, case: dict[str, Any], state: DialogueState
    ) -> str:
        raise NotImplementedError

    @abc.abstractmethod
    def evaluate_transition(
        self,
        spec: DatasetSpec,
        case: dict[str, Any],
        state: DialogueState,
        *,
        count: int,
        prompt_variant: str = "critic_compact_enum_v1",
    ) -> list[str]:
        raise NotImplementedError


class ScriptedBackend(LLMBackend):
    """Deterministic backend for runtime, replay, and checkpoint tests."""

    def __init__(
        self,
        *,
        seed: int = 7,
        critic_batches: list[list[str]] | None = None,
    ):
        self.seed = seed
        self.records: list[GenerationRecord] = []
        self.call_order: list[str] = []
        self._critic_batches = critic_batches or [["better"] * 10, ["solved"] * 10]
        self._critic_index = 0
        self._invocation_counter = 0
        self._current_turn = 0
        self.set_episode_context(case_id="unset", split="unset", track="unset")
        self.role_configs = default_role_generation_configs()

    @property
    def manifest(self) -> dict[str, Any]:
        return {
            "backend": "scripted",
            "seed": self.seed,
            "version": 2,
            "role_generation_configs": {
                role: asdict(config) for role, config in sorted(self.role_configs.items())
            },
        }

    def set_episode_context(self, *, case_id: str, split: str, track: str,
                            episode_id: int = 0, rollout_id: str = "primary",
                            protocol_name: str = "unset",
                            protocol_hash: str = "unset",
                            seed_root: int | None = None) -> None:
        super().set_episode_context(
            case_id=case_id, split=split, track=track,
            episode_id=episode_id, rollout_id=rollout_id,
            protocol_name=protocol_name, protocol_hash=protocol_hash,
            seed_root=seed_root,
        )
        if protocol_name == "unset" or not hasattr(self, "role_configs"):
            return
        protocol = get_protocol(protocol_name)
        if protocol.generation_profile == "paper_prior_t1_p1_roles_greedy_v1":
            self.role_configs["prior"] = RoleGenerationConfig(25, True, 1.0, 1.0)
            self.role_configs["system"] = RoleGenerationConfig(100, False)
            self.role_configs["user"] = RoleGenerationConfig(100, False)
            self.role_configs["critic"] = (
                RoleGenerationConfig(40, True, 1.0, 1.0, 10)
                if protocol_name == "extended_prompt_faithful"
                else RoleGenerationConfig(40, False, 1.0, 1.0, 1)
            )
        else:
            self.role_configs.update(default_role_generation_configs())

    def _record(self, role: str, raw: str, messages: list[dict[str, str]]) -> None:
        self._invocation_counter += 1
        prompt = json.dumps(messages, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        self.call_order.append(role)
        self.records.append(
            GenerationRecord(
                invocation=self._invocation_counter,
                sequence_index=0,
                role=role,
                case_id=self._episode_context["case_id"],
                split=self._episode_context["split"],
                track=self._episode_context["track"],
                turn=self._current_turn,
                seed=functional_seed(
                    self._episode_context["seed_root"], phase=self._episode_context["split"],
                    episode_id=self._episode_context["episode_id"],
                    case_id=self._episode_context["case_id"], turn=self._current_turn,
                    role=role, rollout_id=self._episode_context["rollout_id"],
                ),
                attempt=1,
                messages=tuple(dict(message) for message in messages),
                canonical_prompt=prompt,
                prompt_sha256=hashlib.sha256(prompt.encode("utf-8")).hexdigest(),
                generation_config=asdict(self.role_configs[role]),
                prompt_tokens=0,
                completion_tokens=0,
                raw_output=raw,
                parse_status="PASS",
                episode_id=self._episode_context["episode_id"],
                rollout_id=self._episode_context["rollout_id"],
                protocol_name=self._episode_context["protocol_name"],
                protocol_hash=self._episode_context["protocol_hash"],
            )
        )

    def infer_emotion(
        self, spec: DatasetSpec, case: dict[str, Any], state: DialogueState,
        *, tracker_variant: str = "tracker_text_only",
    ) -> dict[str, str]:
        self._current_turn = int(state.turn_index)
        raw = '{"raw":"concerned","normalized":"concerned"}'
        messages = build_emotion_messages(
            spec, state.conversation,
            case if tracker_variant == "tracker_case_oracle" else None,
        )
        self._record("emotion", raw, messages)
        return parse_emotion_json(raw)

    def propose_actions(
        self,
        spec: DatasetSpec,
        case: dict[str, Any],
        state: DialogueState,
        *,
        top_k: int,
        behavior_track: str,
    ) -> ActionPriorResult:
        self._current_turn = int(state.turn_index)
        raw = ",".join(str(index) for index in range(1, top_k + 1))
        options = "\n".join(
            f"{index}. {action}: {description}"
            for index, (action, description) in enumerate(spec.action_inventory.items(), 1)
        )
        messages = build_policy_messages(
            spec,
            state.conversation,
            state.emotion_history,
            options,
            top_k=top_k,
            case=case,
            prompt_variant=self.current_protocol().prior_variant,
            emotion_tracker_variant=self.current_protocol().emotion_tracker_variant,
        )
        self._record("prior", raw, messages)
        return parse_prompt_faithful(raw, spec.action_names, top_k=top_k)

    def generate_system_response(
        self,
        spec: DatasetSpec,
        case: dict[str, Any],
        state: DialogueState,
        *,
        action: str,
        behavior_track: str,
    ) -> SystemGeneration:
        self._current_turn = int(state.turn_index)
        if behavior_track in {"prompt_faithful", "repository_diagnostic"}:
            raw = "Emotion: concerned\nResponse: I hear you and would like to help."
            messages = build_roleplay_messages(
                spec,
                case,
                "system",
                state.conversation,
                state.emotion_history,
                action,
                coupled_emotion=True,
                system_prompt_variant=self.current_protocol().system_prompt_variant,
            )
            self._record("system", raw, messages)
            emotion, response = parse_coupled_emotion_response(raw)
            return SystemGeneration(response=response, emotion=emotion)
        raw = "I hear you and would like to help."
        messages = build_roleplay_messages(
            spec,
            case,
            "system",
            state.conversation,
            state.emotion_history,
            action,
            system_prompt_variant=self.current_protocol().system_prompt_variant,
        )
        self._record("system", raw, messages)
        return SystemGeneration(response=parse_short_response(raw))

    def simulate_user(
        self, spec: DatasetSpec, case: dict[str, Any], state: DialogueState
    ) -> str:
        self._current_turn = int(state.turn_index)
        raw = "Thank you; I can explain a little more."
        messages = build_roleplay_messages(
            spec, case, "user", state.conversation,
            user_prompt_variant=self.current_protocol().user_prompt_variant,
        )
        self._record("user", raw, messages)
        return parse_short_response(raw)

    def evaluate_transition(
        self,
        spec: DatasetSpec,
        case: dict[str, Any],
        state: DialogueState,
        *,
        count: int,
        prompt_variant: str = "critic_compact_enum_v1",
    ) -> list[str]:
        self._current_turn = int(state.turn_index)
        batch_index = (
            int(self._episode_context["episode_id"]) + int(self._current_turn)
        ) % len(self._critic_batches)
        batch = self._critic_batches[batch_index]
        self._critic_index += 1
        values = (batch * ((count + len(batch) - 1) // len(batch)))[:count]
        messages = build_roleplay_messages(
            spec,
            case,
            "critic",
            state.conversation,
            state.emotion_history,
            critic_variant=prompt_variant,
        )
        for raw in values:
            self._record("critic", raw, messages)
        return values


class TransformersLocalBackend(LLMBackend):
    """One frozen local Transformers model shared across all dialogue roles."""

    def __init__(
        self,
        model_path: str | Path,
        *,
        device: str,
        seed: int = 7,
        dtype: str = "bfloat16",
        do_sample: bool = False,
        temperature: float = 0.7,
        top_p: float = 0.9,
        max_new_tokens: int = 192,
        max_retries: int = 2,
        role_configs: Mapping[str, RoleGenerationConfig] | None = None,
        critic_prompt_variant: str = "critic_compact_enum_v1",
    ):
        import torch
        from transformers import AutoModelForCausalLM, AutoTokenizer

        self.model_path = str(Path(model_path))
        self.device = torch.device(device)
        self.seed = seed
        self.do_sample = do_sample
        self.temperature = temperature
        self.top_p = top_p
        self.max_new_tokens = max_new_tokens
        self.max_retries = max_retries
        defaults = default_role_generation_configs()
        if role_configs is None and any(
            value != default
            for value, default in (
                (do_sample, False),
                (temperature, 0.7),
                (top_p, 0.9),
                (max_new_tokens, 192),
            )
        ):
            defaults = {
                role: RoleGenerationConfig(
                    max_new_tokens,
                    do_sample,
                    temperature,
                    top_p,
                    1,
                )
                for role in defaults
            }
        self.role_configs = dict(role_configs or defaults)
        if set(self.role_configs) != {"emotion", "prior", "system", "user", "critic"}:
            raise ValueError("role_configs must define emotion/prior/system/user/critic")
        self.critic_prompt_variant = critic_prompt_variant
        self.records: list[GenerationRecord] = []
        self.call_order: list[str] = []
        self._invocation_counter = 0
        self._current_turn = 0
        self.set_episode_context(case_id="unset", split="unset", track="unset")
        model_root = Path(self.model_path)
        small_hashes = {}
        for name in ("config.json", "tokenizer_config.json", "model.safetensors.index.json"):
            candidate = model_root / name
            if candidate.is_file():
                small_hashes[name] = hashlib.sha256(candidate.read_bytes()).hexdigest()
        torch_dtype = {"bfloat16": torch.bfloat16, "float16": torch.float16}[dtype]
        self.tokenizer = AutoTokenizer.from_pretrained(
            self.model_path,
            local_files_only=True,
            trust_remote_code=False,
        )
        self.model = AutoModelForCausalLM.from_pretrained(
            self.model_path,
            local_files_only=True,
            trust_remote_code=False,
            torch_dtype=torch_dtype,
        )
        self.model.requires_grad_(False)
        self.model.eval()
        self.model.to(self.device)
        self.dtype = dtype
        self.small_hashes = small_hashes

    def set_episode_context(self, *, case_id: str, split: str, track: str,
                            episode_id: int = 0, rollout_id: str = "primary",
                            protocol_name: str = "unset",
                            protocol_hash: str = "unset",
                            seed_root: int | None = None) -> None:
        super().set_episode_context(
            case_id=case_id, split=split, track=track,
            episode_id=episode_id, rollout_id=rollout_id,
            protocol_name=protocol_name, protocol_hash=protocol_hash,
            seed_root=seed_root,
        )
        if protocol_name == "unset" or not hasattr(self, "role_configs"):
            return
        protocol = get_protocol(protocol_name)
        if protocol.generation_profile == "paper_prior_t1_p1_roles_greedy_v1":
            self.role_configs["prior"] = RoleGenerationConfig(25, True, 1.0, 1.0)
            self.role_configs["system"] = RoleGenerationConfig(100, False)
            self.role_configs["user"] = RoleGenerationConfig(100, False)
            self.role_configs["critic"] = (
                RoleGenerationConfig(40, True, 1.0, 1.0, 10)
                if protocol_name == "extended_prompt_faithful"
                else RoleGenerationConfig(40, False, 1.0, 1.0, 1)
            )
        elif protocol.generation_profile == "corrected_role_specific_v1":
            self.role_configs.update(default_role_generation_configs())
        else:
            raise ValueError(f"unknown generation profile: {protocol.generation_profile}")
        self.critic_prompt_variant = protocol.critic_prompt_variant

    @property
    def manifest(self) -> dict[str, Any]:
        return {
            "backend": "transformers_local",
            "model_path": self.model_path,
            "device": str(self.device),
            "dtype": self.dtype,
            "seed": self.seed,
            "do_sample": self.do_sample,
            "temperature": self.temperature,
            "top_p": self.top_p,
            "max_new_tokens": self.max_new_tokens,
            "role_generation_configs": {
                role: asdict(config) for role, config in sorted(self.role_configs.items())
            },
            "critic_prompt_variant": self.critic_prompt_variant,
            "small_file_hashes": dict(self.small_hashes),
            "local_files_only": True,
            "trainable_parameters": sum(
                parameter.numel() for parameter in self.model.parameters() if parameter.requires_grad
            ),
        }

    def _generate(
        self,
        messages: list[dict[str, str]],
        *,
        role: str,
        parser: Callable[[str], Any],
    ) -> Any:
        import torch

        last_error: Exception | None = None
        config = self.role_configs[role]
        for attempt in range(1, self.max_retries + 2):
            self._invocation_counter += 1
            invocation = self._invocation_counter
            seed = functional_seed(
                self._episode_context["seed_root"], phase=self._episode_context["split"],
                episode_id=self._episode_context["episode_id"],
                case_id=self._episode_context["case_id"], turn=self._current_turn,
                role=role, attempt=attempt, rollout_id=self._episode_context["rollout_id"],
            )
            torch.manual_seed(seed)
            if self.device.type == "cuda":
                torch.cuda.manual_seed_all(seed)
            prompt = self.tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
            )
            encoded = self.tokenizer(prompt, return_tensors="pt")
            encoded = {key: value.to(self.device) for key, value in encoded.items()}
            kwargs: dict[str, Any] = {
                "max_new_tokens": config.max_new_tokens,
                "do_sample": config.do_sample,
                "pad_token_id": self.tokenizer.eos_token_id,
            }
            if config.do_sample:
                kwargs.update(temperature=config.temperature, top_p=config.top_p)
            with torch.no_grad():
                output = self.model.generate(**encoded, **kwargs)
            completion = output[0, encoded["input_ids"].shape[1] :]
            raw = self.tokenizer.decode(completion, skip_special_tokens=True).strip()
            try:
                parsed = parser(raw)
                parse_status = "PASS"
                last_error = None
            except (StructuredOutputError, ActionPriorParseError, CriticParseError) as exc:
                parsed = None
                parse_status = f"FAIL:{exc}"
                last_error = exc
            self.call_order.append(role)
            self.records.append(
                GenerationRecord(
                    invocation=invocation,
                    sequence_index=0,
                    role=role,
                    case_id=self._episode_context["case_id"],
                    split=self._episode_context["split"],
                    track=self._episode_context["track"],
                    turn=int(self._current_turn),
                    seed=seed,
                    attempt=attempt,
                    messages=tuple(dict(message) for message in messages),
                    canonical_prompt=prompt,
                    prompt_sha256=hashlib.sha256(prompt.encode("utf-8")).hexdigest(),
                    generation_config=asdict(config),
                    prompt_tokens=int(encoded["input_ids"].numel()),
                    completion_tokens=int(completion.numel()),
                    raw_output=raw,
                    parse_status=parse_status,
                    episode_id=self._episode_context["episode_id"],
                    rollout_id=self._episode_context["rollout_id"],
                    protocol_name=self._episode_context["protocol_name"],
                    protocol_hash=self._episode_context["protocol_hash"],
                )
            )
            if last_error is None:
                return parsed
        assert last_error is not None
        raise last_error

    def _generate_many(
        self,
        messages: list[dict[str, str]],
        *,
        role: str,
        parser: Callable[[str], Any],
        count: int,
    ) -> list[str]:
        """Return sampled critic sequences in one model invocation when possible."""

        # DX-REPRO CHANGE 2026-07-17T02:42:00Z [DX-P3_5-010]
        # Base: 6ea4d579, backend.py:evaluate_transition
        # Reason: ten greedy calls cannot establish stochastic self-consistency.
        # Behavior: sampled critics are returned in one auditable batched invocation.

        import torch

        config = self.role_configs[role]
        if not config.do_sample:
            return [self._generate(messages, role=role, parser=parser) for _ in range(count)]
        self._invocation_counter += 1
        invocation = self._invocation_counter
        seed = functional_seed(
            self._episode_context["seed_root"], phase=self._episode_context["split"],
            episode_id=self._episode_context["episode_id"],
            case_id=self._episode_context["case_id"], turn=self._current_turn,
            role=role, rollout_id=self._episode_context["rollout_id"],
        )
        torch.manual_seed(seed)
        if self.device.type == "cuda":
            torch.cuda.manual_seed_all(seed)
        prompt = self.tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
        )
        encoded = self.tokenizer(prompt, return_tensors="pt")
        encoded = {key: value.to(self.device) for key, value in encoded.items()}
        with torch.no_grad():
            output = self.model.generate(
                **encoded,
                max_new_tokens=config.max_new_tokens,
                do_sample=True,
                temperature=config.temperature,
                top_p=config.top_p,
                num_return_sequences=count,
                pad_token_id=self.tokenizer.eos_token_id,
            )
        values: list[str] = []
        for sequence_index, sequence in enumerate(output):
            completion = sequence[encoded["input_ids"].shape[1] :]
            raw = self.tokenizer.decode(completion, skip_special_tokens=True).strip()
            try:
                parser(raw)
                status = "PASS"
            except (StructuredOutputError, ActionPriorParseError, CriticParseError) as exc:
                status = f"FAIL:{exc}"
            self.call_order.append(role)
            self.records.append(
                GenerationRecord(
                    invocation=invocation,
                    sequence_index=sequence_index,
                    role=role,
                    case_id=self._episode_context["case_id"],
                    split=self._episode_context["split"],
                    track=self._episode_context["track"],
                    turn=int(self._current_turn),
                    seed=seed,
                    attempt=1,
                    messages=tuple(dict(message) for message in messages),
                    canonical_prompt=prompt,
                    prompt_sha256=hashlib.sha256(prompt.encode("utf-8")).hexdigest(),
                    generation_config=asdict(config) | {"num_return_sequences": count},
                    prompt_tokens=int(encoded["input_ids"].numel()),
                    completion_tokens=int(completion.numel()),
                    raw_output=raw,
                    parse_status=status,
                    episode_id=self._episode_context["episode_id"],
                    rollout_id=self._episode_context["rollout_id"],
                    protocol_name=self._episode_context["protocol_name"],
                    protocol_hash=self._episode_context["protocol_hash"],
                )
            )
            values.append(raw)
        return values

    def _set_turn(self, state: DialogueState) -> None:
        self._current_turn = int(state.turn_index)

    def configure_critic(
        self,
        config: RoleGenerationConfig,
        *,
        prompt_variant: str,
    ) -> None:
        self.role_configs["critic"] = config
        self.critic_prompt_variant = prompt_variant

    def infer_emotion(
        self, spec: DatasetSpec, case: dict[str, Any], state: DialogueState,
        *, tracker_variant: str = "tracker_text_only",
    ) -> dict[str, str]:
        self._set_turn(state)
        return self._generate(
            build_emotion_messages(
                spec, state.conversation,
                case if tracker_variant == "tracker_case_oracle" else None,
            ),
            role="emotion",
            parser=parse_emotion_json,
        )

    def propose_actions(
        self,
        spec: DatasetSpec,
        case: dict[str, Any],
        state: DialogueState,
        *,
        top_k: int,
        behavior_track: str,
    ) -> ActionPriorResult:
        self._set_turn(state)
        if behavior_track == "official_formal":
            raise NotImplementedError("live official_formal generation is outside P3")
        options = "\n".join(
            f"{index}. {action}: {description}"
            for index, (action, description) in enumerate(spec.action_inventory.items(), 1)
        )
        return self._generate(
            build_policy_messages(
                spec,
                state.conversation,
                state.emotion_history,
                options,
                top_k=top_k,
                case=case,
                prompt_variant=self.current_protocol().prior_variant,
                emotion_tracker_variant=self.current_protocol().emotion_tracker_variant,
            ),
            role="prior",
            parser=lambda raw: parse_prompt_faithful(raw, spec.action_names, top_k=top_k),
        )

    def generate_system_response(
        self,
        spec: DatasetSpec,
        case: dict[str, Any],
        state: DialogueState,
        *,
        action: str,
        behavior_track: str,
    ) -> SystemGeneration:
        self._set_turn(state)
        coupled = behavior_track in {"prompt_faithful", "repository_diagnostic"}
        messages = build_roleplay_messages(
            spec,
            case,
            "system",
            state.conversation,
            state.emotion_history,
            action,
            coupled_emotion=coupled,
            system_prompt_variant=self.current_protocol().system_prompt_variant,
        )
        if coupled:
            emotion, response = self._generate(
                messages,
                role="system",
                parser=parse_coupled_emotion_response,
            )
            return SystemGeneration(response=response, emotion=emotion)
        return SystemGeneration(
            response=self._generate(messages, role="system", parser=parse_short_response)
        )

    def simulate_user(
        self, spec: DatasetSpec, case: dict[str, Any], state: DialogueState
    ) -> str:
        self._set_turn(state)
        return self._generate(
            build_roleplay_messages(
                spec, case, "user", state.conversation,
                user_prompt_variant=self.current_protocol().user_prompt_variant,
            ),
            role="user",
            parser=parse_short_response,
        )

    def evaluate_transition(
        self,
        spec: DatasetSpec,
        case: dict[str, Any],
        state: DialogueState,
        *,
        count: int,
        prompt_variant: str = "critic_compact_enum_v1",
    ) -> list[str]:
        self._set_turn(state)
        messages = build_roleplay_messages(
            spec,
            case,
            "critic",
            state.conversation,
            state.emotion_history,
            critic_variant=prompt_variant or self.critic_prompt_variant,
        )
        def parse_critic(raw: str) -> str:
            value = parse_short_response(raw)
            aggregate_critic_outputs(
                spec,
                [value],
                case,
                requested_count=1,
                min_valid=1,
            )
            return value

        return self._generate_many(
            messages,
            role="critic",
            parser=parse_critic,
            count=count,
        )
