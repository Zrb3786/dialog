"""Track-aware dialogue state for corrected DialogXpert.

Source: upstream env.py reset/perform_self_play and the paper MDP description.
Purpose: keep one causal state object across reset, generation, replay, and logs.
Created: 2026-07-16T06:28:17Z.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from typing import Any

from .registry import DatasetSpec


EMOTION_ALIAS_VERSION = "emotion-alias-v2"
EMOTION_ALIASES = {
    "anxious": "anxiety",
    "anxiety": "anxiety",
    "concern": "concerned",
    "concerned": "concerned",
    "frustrated": "frustration",
    "frustration": "frustration",
    "depressed": "depression",
    "depression": "depression",
    "sad": "sadness",
    "sadness": "sadness",
    "calm": "calm",
    "neutral": "neutral",
}
EMOTION_ALIAS_SHA256 = hashlib.sha256(
    json.dumps(EMOTION_ALIASES, sort_keys=True, separators=(",", ":")).encode()
).hexdigest()


@dataclass(frozen=True)
class EmotionState:
    """Planner-safe emotion label; never carries raw model output or utterance."""

    label: str
    source_turn_index: int
    source_role: str
    source_text_sha256: str
    tracker_variant: str


def normalize_emotion_label(value: str) -> tuple[str, bool]:
    normalized = value.strip().casefold().replace("_", " ").replace("-", " ")
    normalized = " ".join(normalized.split())
    if normalized in EMOTION_ALIASES:
        return EMOTION_ALIASES[normalized], False
    # DX-REPRO CHANGE 2026-07-17T05:35:00Z [DX-P3_6-026]
    # Base: 3793c14, state.py:normalize_emotion_label
    # Reason: v1 collapsed every unknown label to `other`, contrary to the
    # required observable OOV contract and losing the model's normalized label.
    # Behavior: retain the normalized unknown label while separately flagging OOV.
    return normalized, True


def make_emotion_state(
    parsed: dict[str, str],
    state: "RuntimeState",
    *,
    tracker_variant: str,
) -> tuple[EmotionState, bool]:
    label, oov = normalize_emotion_label(parsed["normalized"])
    source = state.last_utterance
    role = state.conversation[-1]["role"] if state.conversation else "none"
    return EmotionState(
        label=label,
        source_turn_index=int(state.turn_index),
        source_role=role,
        source_text_sha256=hashlib.sha256(source.encode("utf-8")).hexdigest(),
        tracker_variant=tracker_variant,
    ), oov


@dataclass
class RuntimeState:
    """Full runtime/audit state; never serialize this object directly for Q."""
    # DX-REPRO CHANGE 2026-07-17T02:40:00Z [DX-P3_5-003]
    # Base: 6ea4d579, state.py:DialogueState
    # Reason: one serializable object conflated privileged runtime audit and planner state.
    # Behavior: retain raw metadata only in RuntimeState; Q consumes PlannerStateView.
    case_id: str
    dataset: str
    case_metadata: dict[str, Any]
    conversation: list[dict[str, str]] = field(default_factory=list)
    emotion_history: list[EmotionState] = field(default_factory=list)
    turn_index: int = 0
    terminal_reason: str | None = None
    last_action: str | None = None
    last_reward: float = 0.0

    def append(self, role: str, content: str) -> None:
        self.conversation.append({"role": role, "content": content})

    @property
    def last_utterance(self) -> str:
        return self.conversation[-1]["content"] if self.conversation else ""

    def as_serializable(self) -> dict[str, Any]:
        return asdict(self)


DialogueState = RuntimeState


def initialize_state(spec: DatasetSpec, case: dict[str, Any]) -> RuntimeState:
    case_id = str(case["_dx_case_id"])
    state = RuntimeState(case_id=case_id, dataset=spec.name, case_metadata=dict(case))
    if spec.name == "esconv":
        state.append(spec.user_role, str(case["situation"]))
        # DX-REPRO CHANGE 2026-07-16T07:45:00Z [DX-P1_5-013]
        # Upstream/local base: 37ee4ef/dialogxpert_repro/state.py/initialize_state
        # Reason: case emotion_type is background metadata, not an inferred trajectory step.
        # Behavior: corrected runtime independently infers emotion before the first action.
    elif spec.name == "cima":
        state.append(spec.system_role, str(case["dialog"][0]["text"]))
        state.append(spec.user_role, str(case["dialog"][1]["text"]))
    elif spec.name == "cb":
        state.append(spec.system_role, f"Hi, how much is the {case['item_name']}?")
        state.append(
            spec.user_role,
            f"Hi, this is a good {case['item_name']} and its price is {case['seller_price']}.",
        )
    elif spec.name == "p4g":
        state.append(spec.system_role, str(case["dialog"][0]["text"]))
        state.append(spec.user_role, str(case["dialog"][1]["text"]))
    else:
        raise RuntimeError(f"initializer unavailable for blocked dataset {spec.name}")
    return state
