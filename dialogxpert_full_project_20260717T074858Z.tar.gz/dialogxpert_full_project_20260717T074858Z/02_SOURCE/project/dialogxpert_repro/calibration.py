"""Bounded local critic calibration for DialogXpert P3.6.

Source: P3.5 external semantic review and critic-consistency gate.
Purpose: compare greedy parser-only and sampled critic prompts without Q training.
Created: 2026-07-17T02:51:00Z.
"""

from __future__ import annotations

import json
import math
from collections import Counter
from dataclasses import asdict
from pathlib import Path
from typing import Any

from .backend import RoleGenerationConfig, TransformersLocalBackend
from .registry import get_dataset, load_split
from .rewards import CriticParseError, CriticSchemaFailure, aggregate_critic_outputs, decide_termination
from .smoke import write_json, write_jsonl
from .state import initialize_state, make_emotion_state
from .protocols import PROTOCOLS


TRACKS = {
    "C0_released_code": (
        RoleGenerationConfig(40, True, 1.0, 1.0, 10),
        "critic_released_code_v1",
        "released_code_compat",
    ),
    "C1_appendix_full_sentence": (
        RoleGenerationConfig(40, True, 1.0, 1.0, 10),
        "critic_appendix_full_sentence_v1",
        "extended_prompt_faithful",
    ),
    "C2_corrected_compact_enum": (
        RoleGenerationConfig(12, True, 1.0, 1.0, 10),
        "critic_compact_enum_v1",
        "corrected_resolved_only",
    ),
}


def _summarize_outputs(
    spec: Any, case: dict[str, Any], outputs: list[str], *, behavior_track: str
) -> dict[str, Any]:
    labels: list[str] = []
    rewards: list[float] = []
    invalid: list[str] = []
    for raw in outputs:
        try:
            aggregation = aggregate_critic_outputs(spec, [raw], case, min_valid=1)
            labels.append(aggregation.majority_label)
            rewards.append(aggregation.aggregate_reward)
        except (CriticParseError, CriticSchemaFailure):
            invalid.append(raw)
    counts = Counter(labels)
    entropy = 0.0
    for count in counts.values():
        probability = count / max(len(labels), 1)
        entropy -= probability * math.log2(probability)
    consensus = max(counts.values(), default=0) / max(len(labels), 1)
    termination = "critic_schema_failure"
    majority = "invalid"
    aggregate_reward = None
    if len(labels) >= 8:
        aggregation = aggregate_critic_outputs(
            spec, outputs, case, requested_count=10, min_valid=8
        )
        majority = aggregation.majority_label
        aggregate_reward = aggregation.aggregate_reward
        termination = decide_termination(
            spec,
            aggregation,
            turn_index=0,
            behavior_track=behavior_track,
            max_turns=2,
        ).reason or "nonterminal"
    return {
        "returned_sequences": len(outputs),
        "valid_parses": len(labels),
        "invalid_parses": len(invalid),
        "unique_raw_outputs": len(set(outputs)),
        "exact_duplicate_rate": 1.0 - (len(set(outputs)) / max(len(outputs), 1)),
        "label_counts": dict(sorted(counts.items())),
        "within_turn_label_entropy_bits": entropy,
        "consensus_ratio": consensus,
        "majority_label": majority,
        "aggregate_reward": aggregate_reward,
        "termination": termination,
        "invalid_outputs": invalid,
    }


def run_critic_calibration(
    *,
    output_dir: str | Path,
    model_path: str | Path,
    device: str = "cuda:0",
    seed: int = 7,
) -> dict[str, Any]:
    """Run C0/C1/C2 on the same 6 train and 6 valid one-turn dialogues."""

    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=False)
    backend = TransformersLocalBackend(
        model_path,
        device=device,
        seed=seed,
        dtype="bfloat16",
        max_retries=2,
    )
    spec = get_dataset("esconv")
    fixed = [("train", case) for case in load_split("esconv", "train")[:6]]
    fixed += [("valid", case) for case in load_split("esconv", "valid")[:6]]
    per_case: list[dict[str, Any]] = []
    for split, case in fixed:
        state = initialize_state(spec, case)
        backend.set_episode_context(
            case_id=state.case_id, split=split, track="critic_calibration",
            episode_id=int(case["_dx_row_index"]), rollout_id="dialogue",
            protocol_name="corrected_resolved_only",
            protocol_hash=PROTOCOLS["corrected_resolved_only"].sha256,
        )
        parsed = backend.infer_emotion(
            spec, case, state, tracker_variant="tracker_text_only"
        )
        emotion, _ = make_emotion_state(
            parsed, state, tracker_variant="tracker_text_only"
        )
        state.emotion_history.append(emotion)
        generated = backend.generate_system_response(
            spec,
            case,
            state,
            action=spec.action_names[0],
            behavior_track="corrected_primary",
        )
        state.append(spec.system_role, generated.response)
        state.append(spec.user_role, backend.simulate_user(spec, case, state))
        for track, (config, prompt_variant, protocol_name) in TRACKS.items():
            for batch_id in range(3):
                protocol = PROTOCOLS[protocol_name]
                behavior_track = (
                    "repository_diagnostic"
                    if protocol_name == "released_code_compat"
                    else "prompt_faithful" if protocol_name == "extended_prompt_faithful"
                    else "corrected_primary"
                )
                backend.set_episode_context(
                    case_id=state.case_id, split=split, track="critic_calibration",
                    episode_id=int(case["_dx_row_index"]),
                    rollout_id=f"{track}:batch:{batch_id}",
                    protocol_name=protocol_name,
                    protocol_hash=protocol.sha256,
                )
                backend.configure_critic(config, prompt_variant=prompt_variant)
                start = len(backend.records)
                error = None
                try:
                    outputs = backend.evaluate_transition(
                        spec, case, state, count=10, prompt_variant=prompt_variant
                    )
                except (CriticParseError, CriticSchemaFailure) as exc:
                    outputs = [record.raw_output for record in backend.records[start:]]
                    error = repr(exc)
                records = backend.records[start:]
                summary = _summarize_outputs(
                    spec, case, outputs, behavior_track=behavior_track
                )
                summary.update(
                    {
                        "track": track,
                        "batch_id": batch_id,
                        "split": split,
                        "case_id": state.case_id,
                        "prompt_variant": prompt_variant,
                        "protocol_name": protocol_name,
                        "protocol_hash": protocol.sha256,
                        "generation_config": asdict(config),
                        "invocations": len({record.invocation for record in records}),
                        "error": error,
                    }
                )
                per_case.append(summary)
    aggregates: dict[str, Any] = {}
    for track in TRACKS:
        rows = [row for row in per_case if row["track"] == track]
        returned = sum(row["returned_sequences"] for row in rows)
        valid = sum(row["valid_parses"] for row in rows)
        labels = Counter()
        terminations = Counter()
        for row in rows:
            labels.update(row["label_counts"])
            terminations[row["termination"]] += 1
        grouped = {}
        for case_id in sorted({row["case_id"] for row in rows}):
            case_rows = [row for row in rows if row["case_id"] == case_id]
            majorities = [row["majority_label"] for row in case_rows]
            rewards = [row["aggregate_reward"] for row in case_rows
                       if row["aggregate_reward"] is not None]
            terminations_for_case = [row["termination"] for row in case_rows]
            mean_reward = sum(rewards) / max(len(rewards), 1)
            grouped[case_id] = {
                "majority_stable_across_3": len(set(majorities)) == 1,
                "termination_agreement_across_3": len(set(terminations_for_case)) == 1,
                "reward_std_across_3": (
                    math.sqrt(sum((value - mean_reward) ** 2 for value in rewards) / len(rewards))
                    if rewards else None
                ),
            }
        aggregates[track] = {
            "cases": len(grouped),
            "batches": len(rows),
            "invocations": sum(row["invocations"] for row in rows),
            "returned_sequences": returned,
            "valid_parses": valid,
            "invalid_parses": returned - valid,
            "parse_validity": valid / max(returned, 1),
            "label_counts": dict(sorted(labels.items())),
            "termination_distribution": dict(sorted(terminations.items())),
            "mean_unique_raw_outputs": sum(row["unique_raw_outputs"] for row in rows)
            / max(len(rows), 1),
            "mean_consensus_ratio": sum(row["consensus_ratio"] for row in rows)
            / max(len(rows), 1),
            "mean_entropy_bits": sum(row["within_turn_label_entropy_bits"] for row in rows)
            / max(len(rows), 1),
            "majority_stability_rate": sum(
                int(value["majority_stable_across_3"]) for value in grouped.values()
            ) / max(len(grouped), 1),
            "termination_agreement_rate": sum(
                int(value["termination_agreement_across_3"]) for value in grouped.values()
            ) / max(len(grouped), 1),
            "per_case_stability": grouped,
        }
    c1_validity = aggregates["C1_appendix_full_sentence"]["parse_validity"]
    c1_stability = aggregates["C1_appendix_full_sentence"]["majority_stability_rate"]
    selected = (
        "critic_appendix_full_sentence_v1"
        if c1_validity >= 0.8 and c1_stability >= 0.8
        else "critic_compact_enum_v1"
    )
    selection_reason = (
        "pre-registered: use sampled Appendix full-sentence prompt only when parse "
        "validity and across-batch majority stability are both >=0.8; otherwise use "
        "compact enum; reward/SR not consulted"
    )
    result = {
        "status": "COMPLETE",
        "model_manifest": backend.manifest,
        "fixed_case_ids": {
            "train": [case["_dx_case_id"] for split, case in fixed if split == "train"],
            "valid": [case["_dx_case_id"] for split, case in fixed if split == "valid"],
        },
        "max_turns": 2,
        "dialogue_turns_used": 1,
        "q_training": False,
        "tracks": aggregates,
        "per_case": per_case,
        "selected_live_critic_prompt": selected,
        "selection_reason": selection_reason,
    }
    write_json(output / "critic_calibration_result.json", result)
    write_jsonl(
        output / "generation_records.jsonl",
        [asdict(record) for record in backend.records],
    )
    (output / "COMPLETE").write_text("COMPLETE\n", encoding="utf-8")
    return result
