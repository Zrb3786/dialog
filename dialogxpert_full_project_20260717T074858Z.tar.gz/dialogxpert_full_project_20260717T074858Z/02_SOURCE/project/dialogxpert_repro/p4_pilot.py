"""Fail-closed bounded P4-A trainer and validation harness.

The module defines the pilot contract without authorizing or starting a pilot.
It deliberately keeps validation state outside the train replay/optimizer/RNG
streams and persists every phase-gate decision needed by an external reviewer.
"""

from __future__ import annotations

import hashlib
import io
import json
import math
import os
import shutil
import time
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence

import torch

from .backend import LLMBackend
from .checkpoint import load_checkpoint, save_checkpoint, sha256_file
from .episode import EpisodeConfig, EpisodeResult
from .metrics import RunMetrics
from .protocols import get_protocol
from .qnet import QMLP
from .registry import DatasetSpec
from .rl import ReplayBuffer, Transition, train_qnetwork
from .runtime import TextEncoder, run_episode
from .seeding import SEED_PROTOCOL_VERSION, functional_seed


P4_A_AUTHORIZATION_MARKER = "P4_A_AUTHORIZED_BY_GATE"
PILOT_CONFIG_VERSION = "p4-a-bounded-v1"
PILOT_ARMS = {
    "A0": {"protocol": "corrected_prior_only_pilot", "top_k": 4, "q_updates": False,
           "selection": "prior_only"},
    "A1": {"protocol": "released_code_compat", "top_k": 4, "q_updates": True,
           "selection": "released_top4_q"},
    "A2": {"protocol": "corrected_resolved_only", "top_k": 4, "q_updates": True,
           "selection": "corrected_top4_q"},
    "A3": {"protocol": "corrected_all8_q_pilot", "top_k": 8, "q_updates": True,
           "selection": "all8_q"},
}


def _canonical_sha256(value: Any) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _torch_state_sha256(value: Any) -> str:
    stream = io.BytesIO()
    torch.save(value, stream)
    return hashlib.sha256(stream.getvalue()).hexdigest()


def module_sha256(module: torch.nn.Module) -> str:
    digest = hashlib.sha256()
    for name, tensor in sorted(module.state_dict().items()):
        digest.update(name.encode("utf-8"))
        digest.update(tensor.detach().cpu().contiguous().numpy().tobytes())
    return digest.hexdigest()


def fixed_validation_contract(cases: Sequence[dict[str, Any]], global_seed: int
                              ) -> tuple[tuple[str, ...], tuple[int, ...]]:
    """Freeze validation identities and episode-root seeds before a run starts."""

    selected = tuple(cases[:20])
    if len(selected) != 20:
        raise ValueError("exactly 20 validation cases are required")
    ids = tuple(str(case["_dx_case_id"]) for case in selected)
    seeds = tuple(
        functional_seed(
            global_seed, phase="valid", episode_id=index, case_id=case_id,
            turn=0, role="episode_root", rollout_id="p4a-shared-valid",
        )
        for index, case_id in enumerate(ids)
    )
    return ids, seeds


@dataclass(frozen=True)
class PilotConfig:
    arm: str
    learning_rate: float
    phase: str = "A"
    train_episodes: int = 20
    validation_episodes: int = 20
    max_turns: int = 8
    gamma: float = 0.999
    target_tau: float = 0.005
    batch_size_cap: int = 32
    epsilon_start: float = 1.0
    epsilon_end: float = 0.1
    checkpoint_every: int = 5
    global_seed: int = 7
    replay_capacity: int = 2048
    disk_reserve_bytes: int = 20 * 1024**3
    checkpoint_limit_bytes: int = 25 * 1024**2
    bert_device: str = "cuda:0"
    fixed_validation_case_ids: tuple[str, ...] = ()
    fixed_validation_seeds: tuple[int, ...] = ()
    config_version: str = PILOT_CONFIG_VERSION

    def __post_init__(self) -> None:
        object.__setattr__(self, "fixed_validation_case_ids",
                           tuple(self.fixed_validation_case_ids))
        object.__setattr__(self, "fixed_validation_seeds",
                           tuple(int(value) for value in self.fixed_validation_seeds))
        if self.arm not in PILOT_ARMS:
            raise ValueError(f"unknown P4-A arm: {self.arm}")
        if self.phase not in {"A", "B"}:
            raise ValueError("phase must be A or B")
        expected_train = 20 if self.phase == "A" else 50
        if self.train_episodes != expected_train:
            raise ValueError(f"phase {self.phase} requires {expected_train} train episodes")
        if self.validation_episodes != 20:
            raise ValueError("P4-A requires exactly 20 fixed validation episodes")
        if (self.max_turns != 8 or self.gamma != 0.999
                or self.target_tau != 0.005 or self.batch_size_cap != 32):
            raise ValueError("max_turns/gamma/target-tau/batch-size contract drift")
        if self.learning_rate not in {1e-6, 1e-4}:
            raise ValueError("learning rate must be preregistered at 1e-6 or 1e-4")
        if (self.epsilon_start, self.epsilon_end) != (1.0, 0.1):
            raise ValueError("epsilon schedule must be linear 1.0 to 0.1")
        if self.checkpoint_every != 5:
            raise ValueError("checkpoint interval must be five episodes")
        if self.bert_device not in {"cuda:0", "cpu"}:
            raise ValueError("BERT device must be cuda:0 or an explicit CPU fallback")
        if self.config_version != PILOT_CONFIG_VERSION:
            raise ValueError("pilot config version mismatch")
        if len(self.fixed_validation_case_ids) != self.validation_episodes:
            raise ValueError("fixed validation IDs must cover all validation episodes")
        if len(self.fixed_validation_seeds) != self.validation_episodes:
            raise ValueError("fixed validation seeds must cover all validation episodes")

    @property
    def arm_contract(self) -> dict[str, Any]:
        return dict(PILOT_ARMS[self.arm])

    @property
    def protocol_name(self) -> str:
        return str(self.arm_contract["protocol"])

    @property
    def protocol_hash(self) -> str:
        return get_protocol(self.protocol_name).sha256

    @property
    def sha256(self) -> str:
        return _canonical_sha256(asdict(self))

    def epsilon(self, episode_id: int) -> float:
        if not 0 <= episode_id < self.train_episodes:
            raise ValueError("episode outside configured epsilon schedule")
        if self.phase == "B" and episode_id >= 20:
            # Controlled A->B expansion keeps the Phase-A endpoint; it does not
            # restart exploration or reinterpret the first 20 episode addresses.
            return self.epsilon_end
        if self.train_episodes == 1:
            return self.epsilon_end
        fraction = episode_id / (self.train_episodes - 1)
        return self.epsilon_start + fraction * (self.epsilon_end - self.epsilon_start)

    def state_dict(self) -> dict[str, Any]:
        return {"config": asdict(self), "sha256": self.sha256}

    @classmethod
    def from_state_dict(cls, value: dict[str, Any]) -> "PilotConfig":
        if set(value) != {"config", "sha256"}:
            raise ValueError("pilot config envelope mismatch")
        config = cls(**value["config"])
        if config.sha256 != value["sha256"]:
            raise ValueError("pilot config hash mismatch")
        return config


@dataclass(frozen=True)
class StopDecision:
    stop: bool
    code: str | None = None
    evidence: dict[str, Any] = field(default_factory=dict)


@dataclass
class HardStopMonitor:
    reward_windows: dict[str, list[float]] = field(
        default_factory=lambda: {"train": [], "valid": []}
    )
    oom_count: int = 0
    first_trigger: StopDecision | None = None

    def _trigger(self, code: str, **evidence: Any) -> StopDecision:
        decision = StopDecision(True, code, evidence)
        if self.first_trigger is None:
            self.first_trigger = decision
        return self.first_trigger

    def check_transition(self, transition: Transition) -> StopDecision:
        if self.first_trigger is not None:
            return self.first_trigger
        forbidden = ('"case_id"', '"dialog"', '"strategy"', '"last_reward"',
                     '"terminal_reason"', '"_dx_')
        if any(marker in transition.state_text for marker in forbidden):
            return self._trigger("forbidden_q_state", case_id=transition.case_id)
        audit = transition.state_serialization
        if audit.get("token_budget_enforced") and (
            audit.get("serialized_state_tokens", 0) > audit.get("max_state_tokens", 0)
        ):
            return self._trigger("critical_state_truncated", audit=audit)
        if any(stat.get("truncated_state_tokens", 0) not in {0, None}
               or not stat.get("action_preserved", True)
               for stat in transition.candidate_token_stats):
            return self._trigger("bert_pair_truncation", case_id=transition.case_id)
        from .encoding import tensor_storage_metadata
        for name in ("candidate_features", "selected_feature", "next_features"):
            metadata = tensor_storage_metadata(getattr(transition, name))
            if metadata["storage_bytes"] != metadata["logical_bytes"]:
                return self._trigger("feature_storage_alias", tensor=name, metadata=metadata)
        values = torch.tensor(transition.candidate_q_values)
        if values.numel() > 1 and (not torch.isfinite(values).all()):
            return self._trigger("q_nan_or_inf", case_id=transition.case_id)
        if values.numel() > 1 and float(values.var(unbiased=False)) == 0.0:
            return self._trigger("zero_q_variance", case_id=transition.case_id)
        phase = "valid" if transition.split == "valid" else "train"
        window = self.reward_windows.setdefault(phase, [])
        window.append(float(transition.reward))
        self.reward_windows[phase] = window[-20:]
        if len(self.reward_windows[phase]) == 20 and len(set(self.reward_windows[phase])) == 1:
            return self._trigger(
                "reward_constant_20", phase=phase,
                reward=self.reward_windows[phase][0],
            )
        return StopDecision(False)

    def check_rates(self, metrics: RunMetrics) -> StopDecision:
        if self.first_trigger is not None:
            return self.first_trigger
        returned = sum(metrics.returned_sequences_by_role.values())
        invalid = sum(metrics.invalid_parses_by_role.values())
        # A schema failure without a returned record remains one explicit failed
        # parse in both numerator and denominator.
        unrecorded = max(int(metrics.parse_failures) - invalid, 0)
        all_parse_rate = (invalid + unrecorded) / max(returned + unrecorded, 1)
        if all_parse_rate > 0.10:
            return self._trigger(
                "all_generation_parse_failure_rate", rate=all_parse_rate,
                invalid=invalid + unrecorded, returned=returned + unrecorded,
            )
        prior_returned = metrics.returned_sequences_by_role.get("prior", 0)
        prior_rate = metrics.prior_parse_failures / max(prior_returned, 1)
        if prior_rate > 0.10:
            return self._trigger("prior_parse_failure_rate", rate=prior_rate)
        if metrics.critic_requested and metrics.critic_valid / metrics.critic_requested < 0.80:
            return self._trigger(
                "critic_validity", rate=metrics.critic_valid / metrics.critic_requested
            )
        return StopDecision(False)

    def check_update(self, *, loss: float, gradient_norm: float,
                     before_hash: str, after_hash: str) -> StopDecision:
        if self.first_trigger is not None:
            return self.first_trigger
        if not math.isfinite(loss) or not math.isfinite(gradient_norm):
            return self._trigger("update_nan_or_inf", loss=loss, gradient_norm=gradient_norm)
        if gradient_norm == 0.0 or before_hash == after_hash:
            return self._trigger("zero_q_update", loss=loss, gradient_norm=gradient_norm)
        return StopDecision(False)

    def check_checkpoint(self, path: str | Path, limit_bytes: int) -> StopDecision:
        size = Path(path).stat().st_size
        if size > limit_bytes:
            return self._trigger("checkpoint_too_large", size=size, limit=limit_bytes)
        return StopDecision(False)

    def check_operational(self, *, disk_free: int, disk_reserve: int,
                          heartbeat_age_seconds: float = 0.0,
                          network_fallback: bool = False,
                          test_touch: bool = False,
                          resume_match: bool = True) -> StopDecision:
        if test_touch:
            return self._trigger("sealed_test_touch")
        if network_fallback:
            return self._trigger("network_or_model_fallback")
        if disk_free < disk_reserve:
            return self._trigger("disk_reserve", free=disk_free, reserve=disk_reserve)
        if heartbeat_age_seconds > 120:
            return self._trigger("heartbeat_stale", age_seconds=heartbeat_age_seconds)
        if not resume_match:
            return self._trigger("resume_mismatch")
        return StopDecision(False)

    def record_oom(self, *, fail_closed_first: bool = False) -> StopDecision:
        self.oom_count += 1
        if fail_closed_first:
            return self._trigger("gpu_oom_fail_closed_first", count=self.oom_count)
        if self.oom_count >= 3:
            return self._trigger("gpu_oom_three_times", count=self.oom_count)
        return StopDecision(False)

    def state_dict(self) -> dict[str, Any]:
        return {
            "reward_windows": {
                phase: list(values) for phase, values in self.reward_windows.items()
            },
            "oom_count": self.oom_count,
            "first_trigger": asdict(self.first_trigger) if self.first_trigger else None,
        }


@dataclass
class PilotRunState:
    next_train_episode_id: int = 0
    q_update_count: int = 0
    target_sync_count: int = 0
    checkpoints_written: int = 0
    episode_records: list[dict[str, Any]] = field(default_factory=list)
    validation_records: list[dict[str, Any]] = field(default_factory=list)
    update_losses: list[float] = field(default_factory=list)
    gradient_norms: list[float] = field(default_factory=list)
    baseline_validation_records: list[dict[str, Any]] = field(default_factory=list)
    validation_isolation_passed: bool = False
    resume_probe_passed: bool = False
    checkpoint_paths: list[str] = field(default_factory=list)
    checkpoint_boundary_manifests: list[str] = field(default_factory=list)


class P4APilotRunner:
    """One preregistered arm; construction alone does not authorize execution."""

    def __init__(self, *, repo_root: str | Path, output_dir: str | Path,
                 spec: DatasetSpec, train_cases: Sequence[dict[str, Any]],
                 valid_cases: Sequence[dict[str, Any]], backend: LLMBackend,
                 encoder: TextEncoder, config: PilotConfig,
                 device: str | torch.device = "cpu",
                 phase_a_authorization: dict[str, Any] | None = None) -> None:
        self.repo_root = Path(repo_root)
        self.output_dir = Path(output_dir)
        self.spec = spec
        self.train_cases = tuple(train_cases)
        self.valid_cases = tuple(valid_cases)
        self.backend = backend
        self.encoder = encoder
        self.config = config
        self.phase_a_authorization = phase_a_authorization
        self.device = torch.device(device)
        if spec.name != "esconv":
            raise ValueError("P4-A is ESConv-only")
        if len(self.valid_cases) < config.validation_episodes:
            raise ValueError("insufficient fixed validation cases")
        actual_ids = tuple(case["_dx_case_id"] for case in self.valid_cases[:20])
        if actual_ids != config.fixed_validation_case_ids:
            raise ValueError("fixed validation case IDs mismatch")
        expected_ids, expected_seeds = fixed_validation_contract(
            self.valid_cases, config.global_seed
        )
        if expected_ids != config.fixed_validation_case_ids or (
            expected_seeds != config.fixed_validation_seeds
        ):
            raise ValueError("fixed validation seed contract mismatch")
        if config.phase == "B":
            authorization = phase_a_authorization or {}
            required = {
                "phase_b_authorized": True,
                "arm": config.arm,
                "learning_rate": config.learning_rate,
                "global_seed": config.global_seed,
            }
            if any(authorization.get(key) != value for key, value in required.items()):
                raise PermissionError("Phase B requires matching PASS Phase-A gate evidence")
            if "phase_a_config" not in authorization:
                raise PermissionError("Phase B authorization lacks frozen Phase-A config")
        input_size = int(encoder.manifest["dimension"] if "dimension" in encoder.manifest
                         else encoder.manifest["hidden_size"])
        torch.manual_seed(config.global_seed)
        self.online = QMLP(input_size).to(self.device)
        self.target = QMLP(input_size).to(self.device)
        self.target.load_state_dict(self.online.state_dict())
        self.optimizer = torch.optim.AdamW(
            self.online.parameters(), lr=config.learning_rate
        )
        self.train_replay = ReplayBuffer(config.replay_capacity, seed=config.global_seed)
        self.train_metrics = RunMetrics(
            self._behavior_track, "esconv", "train", config.global_seed,
            protocol_name=config.protocol_name, protocol_hash=config.protocol_hash,
        )
        self.valid_metrics: RunMetrics | None = None
        self.baseline_metrics: RunMetrics | None = None
        self.monitor = HardStopMonitor()
        self.state = PilotRunState()

    @property
    def _behavior_track(self) -> str:
        return "repository_diagnostic" if self.config.protocol_name == "released_code_compat" else "corrected_primary"

    def _episode_config(self, episode_id: int, split: str,
                        *, seed: int | None = None) -> EpisodeConfig:
        protocol = get_protocol(self.config.protocol_name)
        epsilon = 0.0 if self.config.arm == "A0" else self.config.epsilon(episode_id)
        return EpisodeConfig(
            behavior_track=self._behavior_track,
            top_k=int(self.config.arm_contract["top_k"]),
            max_turns=self.config.max_turns,
            critic_prompt_variant=protocol.critic_prompt_variant,
            emotion_tracker_variant=protocol.emotion_tracker_variant,
            protocol_name=protocol.name,
            episode_id=episode_id,
            rollout_id=(
                "p4a-shared-valid" if split == "valid" else "p4a-shared-train"
            ),
            epsilon=epsilon,
            seed=self.config.global_seed if seed is None else int(seed),
        )

    def _case(self, cases: Sequence[dict[str, Any]], episode_id: int, phase: str) -> dict[str, Any]:
        order = list(range(len(cases)))
        seed = functional_seed(
            self.config.global_seed, phase=phase, episode_id=0,
            case_id="esconv-case-schedule", turn=0, role="case_sampler",
            rollout_id="p4a-shared-train-schedule",
        )
        import random
        random.Random(seed).shuffle(order)
        return cases[order[episode_id % len(order)]]

    def _record_result(self, result: EpisodeResult, split: str) -> dict[str, Any]:
        return {
            "split": split, "episode_id": result.episode_id,
            "case_id": result.case_id, "protocol_name": result.protocol_name,
            "protocol_hash": result.protocol_hash, "completed": result.completed,
            "success": result.success, "quarantined": result.quarantined,
            "termination": result.terminal_reason, "turns": result.turns,
            "cumulative_reward": result.total_reward,
            "transitions": [
                {
                    "turn": item.turn_index,
                    "candidate_actions": item.candidate_actions,
                    "candidate_action_ids": item.candidate_action_ids,
                    "all_q": item.candidate_q_values,
                    "selected_action": item.selected_action,
                    "selected_action_index": item.selected_action_index,
                    "epsilon": item.epsilon,
                    "epsilon_draw": item.selection_random_draw,
                    "reward": item.reward,
                    "termination": item.terminal_reason,
                    "critic": item.reward_aggregation,
                    "feature_hashes": item.candidate_feature_hashes,
                } for item in result.transitions
            ],
        }

    def run_train_episode(self, episode_id: int) -> dict[str, Any]:
        if self.monitor.first_trigger is not None:
            raise RuntimeError(f"pilot stopped: {self.monitor.first_trigger.code}")
        if episode_id != self.state.next_train_episode_id:
            raise ValueError("train episode order/resume mismatch")
        case = self._case(self.train_cases, episode_id, "train")
        started = time.perf_counter()
        result = run_episode(
            spec=self.spec, case=case, split="train", backend=self.backend,
            encoder=self.encoder, online_head=self.online, replay=self.train_replay,
            config=self._episode_config(episode_id, "train"), metrics=self.train_metrics,
            device=self.device,
            transition_guard=lambda transition: not self.monitor.check_transition(
                transition
            ).stop,
        )
        self.monitor.check_rates(self.train_metrics)
        record = self._record_result(result, "train")
        record["wall_seconds"] = time.perf_counter() - started
        if self.monitor.first_trigger is None and self.config.arm_contract["q_updates"] and len(self.train_replay):
            before = module_sha256(self.online)
            batch = self.train_replay.sample(min(self.config.batch_size_cap, len(self.train_replay)))
            loss = train_qnetwork(
                batch, self.optimizer, self.online, self.target, self.device,
                gamma=self.config.gamma,
                tau=self.config.target_tau,
            )
            gradient_norm = math.sqrt(sum(
                float(parameter.grad.detach().float().pow(2).sum().cpu())
                for parameter in self.online.parameters() if parameter.grad is not None
            ))
            after = module_sha256(self.online)
            self.monitor.check_update(
                loss=loss, gradient_norm=gradient_norm,
                before_hash=before, after_hash=after,
            )
            self.state.update_losses.append(loss)
            self.state.gradient_norms.append(gradient_norm)
            # train_qnetwork performs one Polyak target synchronization after
            # every optimizer step. Keep the two counters semantically distinct.
            self.state.q_update_count += 1
            self.state.target_sync_count += 1
            record.update({"loss": loss, "gradient_norm": gradient_norm,
                           "online_before": before, "online_after": after})
        else:
            record.update({"loss": None, "gradient_norm": None})
        self.state.episode_records.append(record)
        self.state.next_train_episode_id += 1
        return record

    @property
    def checkpoint_due(self) -> bool:
        return (
            self.state.next_train_episode_id > 0
            and self.state.next_train_episode_id % self.config.checkpoint_every == 0
        )

    def _train_invariant_snapshot(self) -> dict[str, Any]:
        return {
            "replay_len": len(self.train_replay),
            "replay_sha256": _torch_state_sha256(self.train_replay.state_dict()),
            "online_sha256": module_sha256(self.online),
            "target_sha256": module_sha256(self.target),
            "optimizer_sha256": _torch_state_sha256(self.optimizer.state_dict()),
            "q_update_count": self.state.q_update_count,
            "target_sync_count": self.state.target_sync_count,
            "next_train_episode_id": self.state.next_train_episode_id,
        }

    def run_validation_block(self, *, label: str = "post") -> list[dict[str, Any]]:
        if label not in {"baseline", "post"}:
            raise ValueError("validation label must be baseline or post")
        if self.monitor.first_trigger is not None:
            raise RuntimeError(f"pilot stopped: {self.monitor.first_trigger.code}")
        self.monitor.reward_windows["valid"] = []
        before = self._train_invariant_snapshot()
        records: list[dict[str, Any]] = []
        validation_metrics = RunMetrics(
            self._behavior_track, "esconv", "valid", self.config.global_seed,
            protocol_name=self.config.protocol_name, protocol_hash=self.config.protocol_hash,
        )
        for episode_id in range(self.config.validation_episodes):
            case = self.valid_cases[episode_id]
            sink = ReplayBuffer(max(self.config.max_turns, 1), seed=0)
            started = time.perf_counter()
            result = run_episode(
                spec=self.spec, case=case, split="valid", backend=self.backend,
                encoder=self.encoder, online_head=self.online, replay=sink,
                config=replace(self._episode_config(
                    episode_id, "valid",
                    seed=self.config.fixed_validation_seeds[episode_id],
                ), epsilon=0.0),
                metrics=validation_metrics, device=self.device,
                transition_guard=lambda transition: not self.monitor.check_transition(
                    transition
                ).stop,
            )
            record = self._record_result(result, "valid")
            record["validation_label"] = label
            record["seed_root"] = self.config.fixed_validation_seeds[episode_id]
            record["wall_seconds"] = time.perf_counter() - started
            records.append(record)
            self.monitor.check_rates(validation_metrics)
            if self.monitor.first_trigger is not None:
                break
        after = self._train_invariant_snapshot()
        if before != after:
            self.monitor._trigger("validation_polluted_train_state", before=before, after=after)
            raise RuntimeError("validation changed train replay/head/optimizer/RNG state")
        self.state.validation_isolation_passed = True
        if label == "baseline":
            self.state.baseline_validation_records = records
            self.baseline_metrics = validation_metrics
        else:
            self.state.validation_records = records
            self.valid_metrics = validation_metrics
        return records

    def save(self, path: str | Path, *, code_state: dict[str, Any],
             task_log_run_id: str) -> Path:
        protocol = get_protocol(self.config.protocol_name)
        self.state.checkpoints_written += 1
        self.state.checkpoint_paths.append(str(Path(path)))
        boundary_manifest = Path(path).with_suffix(Path(path).suffix + ".boundary.json")
        self.state.checkpoint_boundary_manifests.append(str(boundary_manifest))
        checkpoint = save_checkpoint(
            path, online_head=self.online, target_head=self.target,
            optimizer=self.optimizer, replay=self.train_replay,
            counters={"episode": self.state.next_train_episode_id,
                      "update": self.state.q_update_count},
            behavior_track=self._behavior_track,
            registry_version=self.spec.schema_version,
            configs={"pilot": self.config.state_dict()},
            manifests={"model": dict(self.backend.manifest),
                       "encoder": dict(self.encoder.manifest),
                       "protocol_name": protocol.name,
                       "protocol_hash": protocol.sha256,
                       "action_registry_hash": self.spec.action_registry_hash},
            metrics={"train": self.train_metrics.summary(),
                     "train_metrics_state": asdict(self.train_metrics),
                     "valid_metrics_state": (
                         asdict(self.valid_metrics) if self.valid_metrics else None
                     ),
                     "baseline_metrics_state": (
                         asdict(self.baseline_metrics) if self.baseline_metrics else None
                     ),
                     "stop_monitor": self.monitor.state_dict(),
                     "pilot_state": asdict(self.state)},
            code_state=code_state,
            episode_resume={
                "episode_sampler_state": {
                    "strategy": "functional_permutation_v1",
                    "pilot_config_sha256": self.config.sha256,
                    "arm": self.config.arm,
                    "protocol_name": protocol.name,
                    "protocol_hash": protocol.sha256,
                    "task_log_run_id": task_log_run_id,
                    "stop_monitor": self.monitor.state_dict(),
                },
                "next_episode_id": self.state.next_train_episode_id,
                "sampling_rng_state": self.train_replay.state_dict()["sampler_rng_state"],
                "epsilon_schedule": {
                    "kind": "linear", "start": self.config.epsilon_start,
                    "end": self.config.epsilon_end,
                    "total": self.config.train_episodes,
                    "next_value": (
                        self.config.epsilon(self.state.next_train_episode_id)
                        if self.state.next_train_episode_id < self.config.train_episodes else None
                    ),
                },
                "backend_seed_protocol": SEED_PROTOCOL_VERSION,
                "target_update_count": self.state.target_sync_count,
                "validation_schedule": {
                    "case_ids": list(self.config.fixed_validation_case_ids),
                    "seeds": list(self.config.fixed_validation_seeds),
                    "train_state_isolation": "sha256_assert_v1",
                },
            },
        )
        self.monitor.check_checkpoint(checkpoint, self.config.checkpoint_limit_bytes)
        boundary_payload = {
            "checkpoint": str(checkpoint),
            "checkpoint_sha256": sha256_file(checkpoint),
            "checkpoint_sidecar": str(checkpoint.with_suffix(checkpoint.suffix + ".sha256")),
            "next_train_episode_id": self.state.next_train_episode_id,
            "q_update_count": self.state.q_update_count,
            "target_sync_count": self.state.target_sync_count,
            "pilot_config_sha256": self.config.sha256,
            "protocol_name": protocol.name,
            "protocol_hash": protocol.sha256,
        }
        temporary = boundary_manifest.with_suffix(boundary_manifest.suffix + ".tmp")
        temporary.write_text(
            json.dumps(boundary_payload, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        temporary.replace(boundary_manifest)
        return checkpoint

    def restore(self, path: str | Path, *, expected_code_state: dict[str, Any]) -> None:
        """Restore the complete episode boundary; config/protocol drift fails closed."""

        protocol = get_protocol(self.config.protocol_name)
        payload = load_checkpoint(
            path, online_head=self.online, target_head=self.target,
            optimizer=self.optimizer, expected_behavior_track=self._behavior_track,
            expected_manifests={
                "model": dict(self.backend.manifest),
                "encoder": dict(self.encoder.manifest),
                "protocol_name": protocol.name,
                "protocol_hash": protocol.sha256,
                "action_registry_hash": self.spec.action_registry_hash,
            },
            expected_registry_version=self.spec.schema_version,
            expected_configs={"pilot": self.config.state_dict()},
            expected_code_state=expected_code_state,
            trusted_local_only=True,
        )
        self._adopt_payload(payload, expected_config_hash=self.config.sha256)

    def _adopt_payload(self, payload: dict[str, Any], *,
                       expected_config_hash: str) -> None:
        self.train_replay = payload["replay_buffer"]
        resume = payload["episode_resume"]
        sampler = resume["episode_sampler_state"]
        if sampler.get("pilot_config_sha256") != expected_config_hash:
            raise ValueError("resume pilot config hash mismatch")
        stored_state = payload["metrics"].get("pilot_state")
        if not isinstance(stored_state, dict):
            raise ValueError("checkpoint lacks complete pilot state")
        self.state = PilotRunState(**stored_state)
        metrics_state = payload["metrics"].get("train_metrics_state")
        if not isinstance(metrics_state, dict):
            raise ValueError("checkpoint lacks complete train metrics")
        self.train_metrics = RunMetrics(**metrics_state)
        valid_metrics = payload["metrics"].get("valid_metrics_state")
        baseline_metrics = payload["metrics"].get("baseline_metrics_state")
        self.valid_metrics = RunMetrics(**valid_metrics) if valid_metrics else None
        self.baseline_metrics = RunMetrics(**baseline_metrics) if baseline_metrics else None
        monitor = payload["metrics"].get("stop_monitor")
        if not isinstance(monitor, dict):
            raise ValueError("checkpoint lacks stop-monitor state")
        self.monitor.reward_windows = {
            phase: list(values)
            for phase, values in monitor["reward_windows"].items()
        }
        self.monitor.oom_count = int(monitor["oom_count"])
        trigger = monitor.get("first_trigger")
        self.monitor.first_trigger = StopDecision(**trigger) if trigger else None
        if self.state.next_train_episode_id != int(resume["next_episode_id"]):
            raise ValueError("resume episode counter mismatch")
        if self.state.target_sync_count != int(resume["target_update_count"]):
            raise ValueError("resume target-update counter mismatch")

    def restore_phase_b(self, path: str | Path, *,
                        expected_code_state: dict[str, Any]) -> None:
        """Migrate a matching 20-episode Phase-A boundary into total-50 Phase B."""

        if self.config.phase != "B":
            raise ValueError("Phase-B migration requested for a non-B config")
        authorization = self.phase_a_authorization or {}
        phase_a = PilotConfig.from_state_dict(authorization["phase_a_config"])
        if phase_a.phase != "A" or phase_a.train_episodes != 20:
            raise ValueError("authorization does not describe Phase A")
        left = asdict(phase_a)
        right = asdict(self.config)
        for key in ("phase", "train_episodes"):
            left.pop(key)
            right.pop(key)
        if left != right:
            raise ValueError("Phase-A/B shared config fields differ")
        protocol = get_protocol(self.config.protocol_name)
        payload = load_checkpoint(
            path, online_head=self.online, target_head=self.target,
            optimizer=self.optimizer, expected_behavior_track=self._behavior_track,
            expected_manifests={
                "model": dict(self.backend.manifest),
                "encoder": dict(self.encoder.manifest),
                "protocol_name": protocol.name,
                "protocol_hash": protocol.sha256,
                "action_registry_hash": self.spec.action_registry_hash,
            }, expected_registry_version=self.spec.schema_version,
            expected_configs={"pilot": phase_a.state_dict()},
            expected_code_state=expected_code_state, trusted_local_only=True,
        )
        self._adopt_payload(payload, expected_config_hash=phase_a.sha256)
        if self.state.next_train_episode_id != 20:
            raise ValueError("Phase B must resume the exact episode-20 boundary")

    def verify_checkpoint_roundtrip(self, path: str | Path, *,
                                    expected_code_state: dict[str, Any]) -> dict[str, Any]:
        """Load a saved boundary into fresh heads and compare all learning state."""

        clone = P4APilotRunner(
            repo_root=self.repo_root, output_dir=self.output_dir,
            spec=self.spec, train_cases=self.train_cases, valid_cases=self.valid_cases,
            backend=self.backend, encoder=self.encoder, config=self.config,
            device=self.device, phase_a_authorization=self.phase_a_authorization,
        )
        clone.restore(path, expected_code_state=expected_code_state)
        expected = self._train_invariant_snapshot()
        actual = clone._train_invariant_snapshot()
        passed = expected == actual
        self.state.resume_probe_passed = passed
        if not passed:
            self.monitor.check_operational(
                disk_free=self.config.disk_reserve_bytes,
                disk_reserve=self.config.disk_reserve_bytes,
                resume_match=False,
            )
        return {"status": "PASS" if passed else "FAIL",
                "expected": expected, "actual": actual}

    def operational_gate(self, *, heartbeat_age_seconds: float = 0.0) -> StopDecision:
        return self.monitor.check_operational(
            disk_free=shutil.disk_usage(self.output_dir.parent).free,
            disk_reserve=self.config.disk_reserve_bytes,
            heartbeat_age_seconds=heartbeat_age_seconds,
            network_fallback=not (
                os.environ.get("HF_HUB_OFFLINE") == "1"
                and os.environ.get("TRANSFORMERS_OFFLINE") == "1"
            ),
        )

    @staticmethod
    def _metric_rates(metrics: RunMetrics | None) -> dict[str, float]:
        if metrics is None:
            return {"all_parse_failure_rate": 1.0, "prior_parse_failure_rate": 1.0,
                    "critic_validity": 0.0}
        returned = sum(metrics.returned_sequences_by_role.values())
        invalid = sum(metrics.invalid_parses_by_role.values())
        unrecorded = max(int(metrics.parse_failures) - invalid, 0)
        prior_returned = metrics.returned_sequences_by_role.get("prior", 0)
        return {
            "all_parse_failure_rate": (
                (invalid + unrecorded) / max(returned + unrecorded, 1)
            ),
            "prior_parse_failure_rate": (
                metrics.prior_parse_failures / max(prior_returned, 1)
            ),
            "critic_validity": metrics.critic_valid / max(metrics.critic_requested, 1),
        }

    def _aggregate_records(self, records: Sequence[dict[str, Any]],
                           metrics: RunMetrics | None) -> dict[str, Any]:
        selection: dict[str, int] = {}
        inclusion: dict[str, int] = {}
        cumulative: list[float] = []
        fixed_horizon: list[float] = []
        q_margins: list[float] = []
        q_reward_pairs: list[dict[str, float]] = []
        better_or_solved = 0
        runtime_success = 0
        solved_only = 0
        improvement_turns: list[int] = []
        resolution_turns: list[int] = []
        wall_seconds = 0.0
        for episode in records:
            cumulative.append(float(episode["cumulative_reward"]))
            fixed_horizon.append(float(episode["cumulative_reward"]) / self.config.max_turns)
            wall_seconds += float(episode.get("wall_seconds", 0.0))
            runtime_success += int(bool(episode["success"]))
            first_improvement = None
            first_resolution = None
            for transition in episode["transitions"]:
                for action in transition["candidate_actions"]:
                    inclusion[action] = inclusion.get(action, 0) + 1
                action = transition["selected_action"]
                selection[action] = selection.get(action, 0) + 1
                values = sorted((float(value) for value in transition["all_q"]), reverse=True)
                if len(values) > 1:
                    q_margins.append(values[0] - values[1])
                selected_q = float(transition["all_q"][transition["selected_action_index"]])
                q_reward_pairs.append({"selected_q": selected_q,
                                       "reward": float(transition["reward"])})
                label = transition["critic"].get("majority_label")
                turn = int(transition["turn"]) + 1
                if label in {"better", "solved"} and first_improvement is None:
                    first_improvement = turn
                if label == "solved" and first_resolution is None:
                    first_resolution = turn
            if first_improvement is not None:
                better_or_solved += 1
                improvement_turns.append(first_improvement)
            if first_resolution is not None:
                solved_only += 1
                resolution_turns.append(first_resolution)
        count = max(len(records), 1)
        metric_summary = metrics.summary() if metrics is not None else None
        return {
            "episodes": len(records),
            "SR_better_or_solved": better_or_solved / count,
            "SR_solved_only": solved_only / count,
            "SR_runtime_protocol_success": runtime_success / count,
            "AT_improvement": (
                sum(improvement_turns) / len(improvement_turns)
                if improvement_turns else None
            ),
            "AT_resolution": (
                sum(resolution_turns) / len(resolution_turns)
                if resolution_turns else None
            ),
            "fixed_horizon_reward": sum(fixed_horizon) / count,
            "average_cumulative_reward": sum(cumulative) / count,
            "strategy_inclusion": dict(sorted(inclusion.items())),
            "strategy_selection": dict(sorted(selection.items())),
            "mean_q_margin": sum(q_margins) / max(len(q_margins), 1),
            "q_reward_pairs": q_reward_pairs,
            "critic_validity": self._metric_rates(metrics)["critic_validity"],
            "critic_unique_outputs": (
                metric_summary.get("unique_outputs_by_role", {}).get("critic", 0)
                if metric_summary else 0
            ),
            "parse_rates": self._metric_rates(metrics),
            "llm_calls": metrics.generate_invocations if metrics else 0,
            "prompt_tokens": metrics.prompt_tokens if metrics else 0,
            "completion_tokens": metrics.completion_tokens if metrics else 0,
            "wall_seconds": wall_seconds,
            "episodes_per_second": len(records) / max(wall_seconds, 1e-12),
        }

    def aggregate_report(self) -> dict[str, Any]:
        return {
            "train": self._aggregate_records(self.state.episode_records,
                                             self.train_metrics),
            "validation_baseline": self._aggregate_records(
                self.state.baseline_validation_records, self.baseline_metrics
            ),
            "validation_post": self._aggregate_records(
                self.state.validation_records, self.valid_metrics
            ),
            "validation_delta": {
                key: (
                    self._aggregate_records(self.state.validation_records,
                                            self.valid_metrics)[key]
                    - self._aggregate_records(self.state.baseline_validation_records,
                                              self.baseline_metrics)[key]
                )
                for key in ("SR_better_or_solved", "SR_solved_only",
                            "fixed_horizon_reward", "average_cumulative_reward")
                if self.state.baseline_validation_records
                and self.state.validation_records
            },
        }

    def phase_a_gate(self) -> dict[str, Any]:
        reasons: list[str] = []
        if self.config.phase != "A":
            reasons.append("not_phase_a")
        if self.monitor.first_trigger is not None:
            reasons.append(f"hard_stop:{self.monitor.first_trigger.code}")
        if self.state.next_train_episode_id != 20:
            reasons.append("train_episodes_incomplete")
        if len(self.state.validation_records) != 20:
            reasons.append("validation_episodes_incomplete")
        if len(self.state.baseline_validation_records) != 20:
            reasons.append("baseline_validation_incomplete")
        if not self.state.validation_isolation_passed:
            reasons.append("validation_isolation_unproved")
        if self.state.checkpoints_written < 4:
            reasons.append("checkpoint_schedule_incomplete")
        if not self.state.resume_probe_passed:
            reasons.append("checkpoint_resume_probe_failed")
        if self.config.arm_contract["q_updates"]:
            if not self.state.update_losses or not any(value > 0 for value in self.state.gradient_norms):
                reasons.append("q_did_not_change")
            if self.state.q_update_count != self.state.next_train_episode_id:
                reasons.append("q_update_schedule_incomplete")
            if self.state.target_sync_count != self.state.q_update_count:
                reasons.append("target_sync_schedule_incomplete")
        elif self.state.update_losses:
            reasons.append("prior_only_arm_updated_q")
        elif self.state.q_update_count or self.state.target_sync_count:
            reasons.append("prior_only_arm_has_update_counters")
        train_rewards = [
            float(transition["reward"])
            for episode in self.state.episode_records
            for transition in episode["transitions"]
        ]
        if not train_rewards or len(set(train_rewards)) == 1:
            reasons.append("reward_is_constant")
        for split, metrics in (("train", self.train_metrics),
                               ("valid", self.valid_metrics)):
            rates = self._metric_rates(metrics)
            if rates["all_parse_failure_rate"] > 0.10:
                reasons.append(f"{split}_all_parse_failure_rate")
            if rates["prior_parse_failure_rate"] > 0.10:
                reasons.append(f"{split}_prior_parse_failure_rate")
            if rates["critic_validity"] < 0.80:
                reasons.append(f"{split}_critic_validity")
        return {
            "phase_b_authorized": not reasons,
            "reasons": reasons,
            "pilot_config_sha256": self.config.sha256,
            "arm": self.config.arm,
            "protocol_name": self.config.protocol_name,
            "protocol_hash": self.config.protocol_hash,
            "learning_rate": self.config.learning_rate,
            "global_seed": self.config.global_seed,
            "phase_a_config": self.config.state_dict(),
            "checkpoint_paths": list(self.state.checkpoint_paths),
            "checkpoint_boundary_manifests": list(
                self.state.checkpoint_boundary_manifests
            ),
            "validation_isolation_passed": self.state.validation_isolation_passed,
            "resume_probe_passed": self.state.resume_probe_passed,
            "q_update_count": self.state.q_update_count,
            "target_sync_count": self.state.target_sync_count,
            "target_tau": self.config.target_tau,
            "rates": {
                "train": self._metric_rates(self.train_metrics),
                "valid": self._metric_rates(self.valid_metrics),
            },
        }


def require_gate_authorization(marker: str) -> None:
    if marker != P4_A_AUTHORIZATION_MARKER:
        raise PermissionError(
            "P4-A is fail-closed until reviewer emits P4_A_AUTHORIZED_BY_GATE"
        )


def require_single_gpu(device: str, visible_devices: str) -> None:
    entries = [item.strip() for item in visible_devices.split(",") if item.strip()]
    if len(entries) != 1:
        raise RuntimeError("P4-A requires exactly one CUDA_VISIBLE_DEVICES entry")
    if device != "cuda:0":
        raise RuntimeError("the single physical GPU must be remapped to cuda:0")


def load_phase_a_gate_artifact(path: str | Path) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    expected = {"artifact_type", "pilot_status", "pilot_config", "gate"}
    if set(value) != expected or value["artifact_type"] != "p4_a_phase_a_gate_v1":
        raise ValueError("Phase-A gate artifact schema mismatch")
    if value["pilot_status"] != "COMPLETE":
        raise PermissionError("Phase-A pilot did not complete")
    config = PilotConfig.from_state_dict(value["pilot_config"])
    gate = value["gate"]
    gate_config = PilotConfig.from_state_dict(gate.get("phase_a_config", {}))
    if config.phase != "A" or gate_config.sha256 != config.sha256:
        raise ValueError("Phase-A gate/config identity mismatch")
    if gate.get("pilot_config_sha256") != config.sha256:
        raise ValueError("Phase-A gate config hash mismatch")
    if gate.get("phase_b_authorized") is not True:
        raise PermissionError("Phase-A gate did not authorize Phase B")
    gate["phase_a_config"] = gate_config.state_dict()
    return gate
