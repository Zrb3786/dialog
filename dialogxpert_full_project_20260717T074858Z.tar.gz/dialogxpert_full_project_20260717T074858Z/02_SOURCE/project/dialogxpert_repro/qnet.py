"""Shared frozen BERT encoder and trainable Q heads.

Source: upstream q_adapter.py and official-paper Q-network description.
Purpose: avoid duplicate encoders, hidden Hub fallback, and padding-biased pooling.
Created: 2026-07-16T06:28:17Z.
"""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import BertModel, BertTokenizerFast

from .encoding import PairEncodingResult, compact_cpu_tensor, feature_sha256, tensor_storage_metadata


def masked_mean_pool(last_hidden_state: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
    mask = attention_mask.unsqueeze(-1).to(last_hidden_state.dtype)
    return (last_hidden_state * mask).sum(dim=1) / mask.sum(dim=1).clamp_min(1.0)


class FrozenBertEncoder(nn.Module):
    def __init__(
        self,
        model_path: str | Path,
        *,
        device: str | torch.device = "cpu",
        pooling: str = "cls",
        max_length: int = 512,
    ):
        super().__init__()
        if pooling not in {"cls", "masked_mean"}:
            raise ValueError("pooling must be cls or masked_mean")
        if max_length < 8:
            raise ValueError("max_length is too small for state/action pair encoding")
        path = str(model_path)
        self.tokenizer = BertTokenizerFast.from_pretrained(path, local_files_only=True)
        self.model = BertModel.from_pretrained(path, local_files_only=True)
        self.model.requires_grad_(False)
        self.model.eval()
        self.device = torch.device(device)
        self.model.to(self.device)
        self.pooling = pooling
        self.max_length = int(max_length)
        config_path = Path(path) / "config.json"
        tokenizer_path = Path(path) / "tokenizer.json"
        if not tokenizer_path.is_file():
            tokenizer_path = Path(path) / "vocab.txt"
        self.manifest = {
            "encoder": "bert",
            "path": path,
            "config_sha256": (
                hashlib.sha256(config_path.read_bytes()).hexdigest()
                if config_path.is_file()
                else "missing"
            ),
            "hidden_size": int(self.model.config.hidden_size),
            "max_length": self.max_length,
            "truncation": "only_first",
            "pair_encoding": True,
            "pooling": self.pooling,
            "tokenizer_sha256": (
                hashlib.sha256(tokenizer_path.read_bytes()).hexdigest()
                if tokenizer_path.is_file()
                else "missing"
            ),
            "local_files_only": True,
            "trainable_parameters": sum(
                parameter.numel() for parameter in self.model.parameters() if parameter.requires_grad
            ),
        }

    @torch.no_grad()
    def encode_pairs(
        self,
        state_texts: Sequence[str],
        action_texts: Sequence[str],
    ) -> PairEncodingResult:
        """Encode BERT sequence pairs while reserving the complete action segment."""

        # DX-REPRO CHANGE 2026-07-17T02:48:00Z [DX-P3_5-006]
        # Base: 6ea4d579, qnet.py:FrozenBertEncoder.encode
        # Reason: tail actions disappeared when a huge concatenated state hit 512 tokens.
        # Behavior: action is the protected second segment; only state may truncate.
        if len(state_texts) != len(action_texts):
            raise ValueError("state/action pair count mismatch")
        if not state_texts:
            raise ValueError("cannot encode an empty candidate set")
        raw_state_ids = self.tokenizer(
            list(state_texts),
            add_special_tokens=False,
            truncation=False,
        )["input_ids"]
        raw_action_ids = self.tokenizer(
            list(action_texts),
            add_special_tokens=False,
            truncation=False,
        )["input_ids"]
        if any(not ids for ids in raw_action_ids):
            raise ValueError("action text tokenized to an empty segment")
        if any(len(ids) + 3 >= self.max_length for ids in raw_action_ids):
            raise ValueError("action segment is too long to preserve")
        encoded = self.tokenizer(
            list(state_texts),
            list(action_texts),
            return_tensors="pt",
            truncation="only_first",
            max_length=self.max_length,
            padding=True,
        )
        token_type_ids = encoded.get("token_type_ids")
        if token_type_ids is None:
            raise RuntimeError("BERT pair encoding did not return token_type_ids")
        stats: list[dict[str, int | bool | str]] = []
        for index, action_ids in enumerate(raw_action_ids):
            active = encoded["attention_mask"][index].bool()
            ids = encoded["input_ids"][index][active].tolist()
            segments = token_type_ids[index][active].tolist()
            second_segment = [token for token, segment in zip(ids, segments) if segment == 1]
            action_preserved = any(
                second_segment[offset : offset + len(action_ids)] == action_ids
                for offset in range(max(len(second_segment) - len(action_ids) + 1, 0))
            )
            encoded_state_tokens = sum(segment == 0 for segment in segments) - 2
            stats.append(
                {
                    "input_tokens": len(ids),
                    "original_state_tokens": len(raw_state_ids[index]),
                    "encoded_state_tokens": max(encoded_state_tokens, 0),
                    "action_tokens": len(action_ids),
                    "truncated_state_tokens": max(
                        len(raw_state_ids[index]) - max(encoded_state_tokens, 0),
                        0,
                    ),
                    "action_preserved": action_preserved,
                    "input_ids": ids,
                    "input_ids_sha256": hashlib.sha256(
                        bytes().join(int(token).to_bytes(4, "big") for token in ids)
                    ).hexdigest(),
                    "action_token_ids": list(action_ids),
                    "token_type_ids": segments,
                    "attention_mask": [1] * len(ids),
                    "token_type_1_tokens": sum(segment == 1 for segment in segments),
                    "truncation": "only_first",
                    "pooling": self.pooling,
                }
            )
        if any(not stat["action_preserved"] for stat in stats):
            raise RuntimeError("action tokens were not preserved by pair encoding")
        device_batch = {key: value.to(self.device) for key, value in encoded.items()}
        output = self.model(**device_batch).last_hidden_state
        if self.pooling == "cls":
            pooled = output[:, 0, :]
        else:
            pooled = masked_mean_pool(output, device_batch["attention_mask"])
        # DX-REPRO CHANGE 2026-07-17T04:24:00Z [DX-P3_6-002]
        # Base: 487c0874, qnet.py:FrozenBertEncoder.encode_pairs
        # Reason: a CLS view retained the complete BERT hidden-state storage.
        # Behavior: every returned feature batch owns compact contiguous CPU storage.
        features = compact_cpu_tensor(pooled)
        storage = tensor_storage_metadata(features)
        for stat in stats:
            stat["feature_batch_storage"] = storage
        return PairEncodingResult(
            features,
            tuple(feature_sha256(feature) for feature in features),
            tuple(stats),
        )

    @torch.no_grad()
    def encode(self, texts: Sequence[str], *, max_length: int = 512) -> torch.Tensor:
        """Compatibility wrapper; corrected Q runtime must use encode_pairs."""

        if max_length != self.max_length:
            raise ValueError("compatibility encode cannot override encoder max_length")
        return self.encode_pairs(texts, ["[NO_ACTION]"] * len(texts)).features


class QMLP(nn.Module):
    def __init__(self, input_size: int = 768):
        super().__init__()
        self.linear1 = nn.Linear(input_size, 64)
        self.linear2 = nn.Linear(64, 64)
        self.linear3 = nn.Linear(64, 1)

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        hidden = F.relu(self.linear1(features))
        hidden = F.relu(self.linear2(hidden))
        return self.linear3(hidden).squeeze(-1)


class QAdapter(nn.Module):
    """Compatibility container with an externally shareable frozen encoder."""

    def __init__(self, encoder: FrozenBertEncoder, input_size: int = 768):
        super().__init__()
        self.encoder = encoder
        self.q_head = QMLP(input_size)

    def transform_features(
        self,
        state_texts: Sequence[str],
        action_texts: Sequence[str],
    ) -> torch.Tensor:
        return self.encoder.encode_pairs(state_texts, action_texts).features

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        return self.q_head(features)
