"""Atomic, track-validated checkpoints for bounded DialogXpert runs.

Source: local checkpoint contract; upstream released no checkpoint support.
Purpose: restore Q heads, optimizer, replay, counters, RNG, and provenance.
Created: 2026-07-16T06:28:17Z.
"""

from __future__ import annotations

import hashlib
import os
import random
from pathlib import Path
from typing import Any

import numpy as np
import torch

from .rl import ReplayBuffer

# DX-REPRO CHANGE 2026-07-17T02:45:00Z [DX-P3_5-011]
# Base: 6ea4d579, checkpoint.py:CHECKPOINT_FORMAT_VERSION
# Reason: v2 replay may contain leaked/noncausal P3 state semantics.
# Behavior: format v6 rejects old payloads and carries the bounded-pilot resume envelope.
CHECKPOINT_FORMAT_VERSION = 6
CHECKPOINT_KEYS = {
    "format_version",
    "online_head",
    "target_head",
    "optimizer",
    "scheduler",
    "replay",
    "counters",
    "rng",
    "behavior_track",
    "registry_version",
    "configs",
    "manifests",
    "metrics",
    "code_state",
    "trusted_local_only",
    "episode_resume",
}
EPISODE_RESUME_KEYS = {
    "episode_sampler_state",
    "next_episode_id",
    "sampling_rng_state",
    "epsilon_schedule",
    "backend_seed_protocol",
    "target_update_count",
    "validation_schedule",
}


def validate_episode_resume(value: dict[str, Any]) -> dict[str, Any]:
    if set(value) != EPISODE_RESUME_KEYS:
        raise ValueError(
            f"unexpected episode resume keys: {sorted(set(value) ^ EPISODE_RESUME_KEYS)}"
        )
    if int(value["next_episode_id"]) < 0 or int(value["target_update_count"]) < 0:
        raise ValueError("episode resume counters must be nonnegative")
    return value


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def checkpoint_sha_path(path: str | Path) -> Path:
    destination = Path(path)
    return destination.with_suffix(destination.suffix + ".sha256")


def capture_rng_state() -> dict[str, Any]:
    state: dict[str, Any] = {
        "python": random.getstate(),
        "numpy": np.random.get_state(),
        "torch": torch.get_rng_state(),
    }
    if torch.cuda.is_available():
        state["cuda"] = torch.cuda.get_rng_state_all()
    return state


def restore_rng_state(state: dict[str, Any]) -> None:
    random.setstate(state["python"])
    np.random.set_state(state["numpy"])
    torch.set_rng_state(state["torch"])
    if "cuda" in state and torch.cuda.is_available():
        torch.cuda.set_rng_state_all(state["cuda"])


def save_checkpoint(
    path: str | Path,
    *,
    online_head: torch.nn.Module,
    target_head: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    replay: ReplayBuffer,
    counters: dict[str, int],
    behavior_track: str,
    registry_version: int,
    configs: dict[str, Any],
    manifests: dict[str, Any],
    metrics: dict[str, Any],
    code_state: dict[str, Any],
    episode_resume: dict[str, Any] | None = None,
    scheduler: Any | None = None,
) -> Path:
    # DX-REPRO CHANGE 2026-07-16T07:40:00Z [DX-P1_5-010]
    # Upstream/local base: 37ee4ef/dialogxpert_repro/checkpoint.py/save_checkpoint
    # Reason: P1 checkpoints lacked file integrity, code state, and fail-closed format.
    # Behavior: format v4 compact causal replay is atomically saved with a SHA-256 sidecar.
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "format_version": CHECKPOINT_FORMAT_VERSION,
        "online_head": online_head.state_dict(),
        "target_head": target_head.state_dict(),
        "optimizer": optimizer.state_dict(),
        "scheduler": scheduler.state_dict() if scheduler is not None else None,
        "replay": replay.state_dict(),
        "counters": dict(counters),
        "rng": capture_rng_state(),
        "behavior_track": behavior_track,
        "registry_version": registry_version,
        "configs": configs,
        "manifests": manifests,
        "metrics": metrics,
        "code_state": code_state,
        "trusted_local_only": True,
        "episode_resume": validate_episode_resume(episode_resume or {
            "episode_sampler_state": {},
            "next_episode_id": int(counters.get("episode", 0)),
            "sampling_rng_state": None,
            "epsilon_schedule": {},
            "backend_seed_protocol": "episode-addressable-v1",
            "target_update_count": int(counters.get("update", 0)),
            "validation_schedule": {},
        }),
    }
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    sidecar = checkpoint_sha_path(destination)
    temporary_sidecar = sidecar.with_suffix(sidecar.suffix + ".tmp")
    try:
        torch.save(payload, temporary)
        with temporary.open("rb") as handle:
            os.fsync(handle.fileno())
        temporary.replace(destination)
        digest = sha256_file(destination)
        temporary_sidecar.write_text(
            f"{digest}  {destination.name}\n",
            encoding="utf-8",
        )
        temporary_sidecar.replace(sidecar)
    finally:
        temporary.unlink(missing_ok=True)
        temporary_sidecar.unlink(missing_ok=True)
    return destination


def load_checkpoint(
    path: str | Path,
    *,
    online_head: torch.nn.Module,
    target_head: torch.nn.Module,
    optimizer: torch.optim.Optimizer,
    expected_behavior_track: str,
    expected_manifests: dict[str, Any],
    expected_registry_version: int,
    expected_configs: dict[str, Any],
    expected_code_state: dict[str, Any],
    trusted_local_only: bool = False,
    scheduler: Any | None = None,
) -> dict[str, Any]:
    # DX-REPRO CHANGE 2026-07-16T07:40:00Z [DX-P1_5-011]
    # Upstream/local base: 37ee4ef/dialogxpert_repro/checkpoint.py/load_checkpoint
    # Reason: unverified pickle loading and partial manifest checks were unsafe.
    # Behavior: only explicitly trusted local checkpoints with matching SHA/contracts load.
    source = Path(path)
    if not trusted_local_only:
        raise ValueError(
            "checkpoint loading requires trusted_local_only=True; "
            "torch.load(weights_only=False) must never accept external checkpoints"
        )
    sidecar = checkpoint_sha_path(source)
    if not sidecar.is_file():
        raise ValueError("checkpoint SHA-256 sidecar is missing")
    fields = sidecar.read_text(encoding="utf-8").strip().split()
    if not fields or fields[0] != sha256_file(source):
        raise ValueError("checkpoint SHA-256 verification failed")
    payload = torch.load(source, map_location="cpu", weights_only=False)
    if set(payload) != CHECKPOINT_KEYS:
        raise ValueError(f"unexpected checkpoint keys: {sorted(set(payload) ^ CHECKPOINT_KEYS)}")
    if payload["format_version"] != CHECKPOINT_FORMAT_VERSION:
        raise ValueError("checkpoint format version mismatch")
    if payload["trusted_local_only"] is not True:
        raise ValueError("checkpoint is not marked trusted-local-only")
    if payload["behavior_track"] != expected_behavior_track:
        raise ValueError("checkpoint behavior track mismatch")
    if payload["registry_version"] != expected_registry_version:
        raise ValueError("checkpoint registry version mismatch")
    if payload["configs"] != expected_configs:
        raise ValueError("checkpoint config mismatch")
    if payload["manifests"] != expected_manifests:
        raise ValueError("checkpoint manifest mismatch")
    if payload["code_state"] != expected_code_state:
        raise ValueError("checkpoint code commit/dirty-state mismatch")
    validate_episode_resume(payload["episode_resume"])
    online_head.load_state_dict(payload["online_head"], strict=True)
    target_head.load_state_dict(payload["target_head"], strict=True)
    optimizer.load_state_dict(payload["optimizer"])
    if scheduler is not None and payload["scheduler"] is not None:
        scheduler.load_state_dict(payload["scheduler"])
    restore_rng_state(payload["rng"])
    payload["replay_buffer"] = ReplayBuffer.from_state_dict(payload["replay"])
    return payload
