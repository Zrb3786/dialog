"""Local corrected DialogXpert reproduction package.

Source: upstream DialogXpert commit 7b35ec95 plus the local audit.
Purpose: provide sealed-test, track-aware P0-P3 execution paths.
Created: 2026-07-16T06:28:17Z.
"""

from .registry import DATASETS, DatasetBlockedError, DatasetSpec, load_split

__all__ = ["DATASETS", "DatasetBlockedError", "DatasetSpec", "load_split"]

