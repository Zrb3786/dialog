"""Bounded scripted and live smoke orchestration for standalone runtime.

Source: P1.5/P3 execution contract.
Purpose: run fixed train/valid cases, one Q update, checkpoint, and fresh replay.
Created: 2026-07-16T08:02:00Z.
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from dataclasses import asdict, replace
from pathlib import Path
from typing import Any, Callable

import torch

from .backend import RoleGenerationConfig, ScriptedBackend, TransformersLocalBackend
from .checkpoint import load_checkpoint, save_checkpoint, sha256_file
from .episode import EpisodeConfig
from .metrics import RunMetrics
from .qnet import FrozenBertEncoder, QMLP
from .registry import get_dataset, load_split
from .rl import ReplayBuffer, train_qnetwork
from .runtime import DeterministicHashEncoder, run_episode
from .task_logging import TaskLog
from .protocols import PROTOCOLS


def write_json(path: str | Path, value: Any) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True), encoding="utf-8")
    temporary.replace(destination)
    return destination


def _jsonable(value: Any) -> Any:
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().tolist()
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(item) for item in value]
    return value


def write_jsonl(path: str | Path, values: list[Any]) -> Path:
    destination = Path(path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("w", encoding="utf-8", buffering=1) as handle:
        for value in values:
            handle.write(json.dumps(_jsonable(value), sort_keys=True) + "\n")
    return destination


def git_code_state(repo_root: str | Path) -> dict[str, Any]:
    root = str(repo_root)
    commit = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=root,
        check=True,
        capture_output=True,
        text=True,
    ).stdout.strip()
    dirty = bool(
        subprocess.run(
            ["git", "status", "--porcelain=v1"],
            cwd=root,
            check=True,
            capture_output=True,
            text=True,
        ).stdout.strip()
    )
    return {"commit": commit, "dirty": dirty}


def module_state_hash(module: torch.nn.Module) -> str:
    digest = hashlib.sha256()
    for key, tensor in sorted(module.state_dict().items()):
        digest.update(key.encode("utf-8"))
        digest.update(tensor.detach().cpu().contiguous().numpy().tobytes())
    return digest.hexdigest()


def verify_checkpoint_next_update(
    checkpoint: str | Path,
    contract_path: str | Path,
) -> dict[str, Any]:
    contract = json.loads(Path(contract_path).read_text(encoding="utf-8"))
    input_size = int(contract["input_size"])
    online = QMLP(input_size)
    target = QMLP(input_size)
    optimizer = torch.optim.AdamW(online.parameters(), lr=float(contract["learning_rate"]))
    payload = load_checkpoint(
        checkpoint,
        online_head=online,
        target_head=target,
        optimizer=optimizer,
        expected_behavior_track=contract["behavior_track"],
        expected_manifests=contract["manifests"],
        expected_registry_version=int(contract["registry_version"]),
        expected_configs=contract["configs"],
        expected_code_state=contract["code_state"],
        trusted_local_only=True,
    )
    batch = payload["replay_buffer"].sample(int(contract["batch_size"]))
    loss = train_qnetwork(
        batch,
        optimizer,
        online,
        target,
        "cpu",
        gamma=float(contract["gamma"]),
        tau=float(contract["tau"]),
    )
    return {
        "loss": loss,
        "online_state_sha256": module_state_hash(online),
        "target_state_sha256": module_state_hash(target),
        "sample_count": payload["replay_buffer"].sample_count,
    }


def _fresh_process_pair(
    repo_root: Path,
    checkpoint: Path,
    contract: Path,
    output_dir: Path,
) -> dict[str, Any]:
    results = []
    script = repo_root / "scripts" / "run_p3_smoke.py"
    environment = {
        **os.environ,
        "PYTHONPATH": str(repo_root),
        "HF_HUB_OFFLINE": "1",
        "TRANSFORMERS_OFFLINE": "1",
    }
    for index in (1, 2):
        output = output_dir / f"fresh_update_{index}.json"
        subprocess.run(
            [
                sys.executable,
                str(script),
                "verify-checkpoint",
                "--checkpoint",
                str(checkpoint),
                "--contract",
                str(contract),
                "--output",
                str(output),
            ],
            cwd=repo_root,
            env=environment,
            check=True,
        )
        results.append(json.loads(output.read_text(encoding="utf-8")))
    if results[0] != results[1]:
        raise RuntimeError("fresh-process next Q update is not deterministic")
    return {"status": "PASS", "runs": results}


def _run_track(
    *,
    repo_root: Path,
    output_dir: Path,
    track: str,
    backend: Any,
    encoder: Any,
    input_size: int,
    train_cases: list[dict[str, Any]],
    valid_cases: list[dict[str, Any]],
    device: str,
    seed: int,
    max_turns: int = 2,
    epsilon: float = 0.0,
    updates: int = 1,
    critic_prompt_variant: str | None = None,
    protocol_name: str | None = None,
    progress_callback: Callable[[dict[str, Any]], None] | None = None,
) -> dict[str, Any]:
    # DX-REPRO CHANGE 2026-07-17T02:49:00Z [DX-P3_5-013]
    # Base: 6ea4d579, smoke.py:_run_track
    # Reason: old smoke persisted selected features but not all candidate/prompts/gates.
    # Behavior: emit exact generation/transition evidence and causal semantic diagnostics.
    spec = get_dataset("esconv")
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    online = QMLP(input_size).to(device)
    target = QMLP(input_size).to(device)
    target.load_state_dict(online.state_dict())
    optimizer = torch.optim.AdamW(online.parameters(), lr=1e-3)
    train_replay = ReplayBuffer(128, seed=seed, sample_with_replacement=True)
    valid_replay = ReplayBuffer(128, seed=seed + 1, sample_with_replacement=True)
    train_metrics = RunMetrics(track, "esconv", "train", seed)
    valid_metrics = RunMetrics(track, "esconv", "valid", seed)
    record_start = len(backend.records)
    protocol_name = protocol_name or (
        "extended_prompt_faithful"
        if track == "prompt_faithful" else "corrected_resolved_only"
    )
    protocol = PROTOCOLS[protocol_name]
    resolved_critic_variant = critic_prompt_variant or (
        protocol.critic_prompt_variant
    )
    config = EpisodeConfig(
        behavior_track=track,
        protocol_name=protocol_name,
        seed=seed,
        max_turns=max_turns,
        epsilon=epsilon,
        critic_prompt_variant=resolved_critic_variant,
        emotion_tracker_variant=protocol.emotion_tracker_variant,
    )
    progress = {"q_updates": 0, "last_loss": "not_available"}

    def emit(phase: str, values: dict[str, Any]) -> None:
        if progress_callback is not None:
            progress_callback({"phase": phase, **progress, **values})

    train_results = []
    for episode_id, case in enumerate(train_cases):
        emit("train", {"episode": episode_id, "turn": 0,
                       "replay_size": len(train_replay)})
        train_results.append(run_episode(
            spec=spec,
            case=case,
            split="train",
            backend=backend,
            encoder=encoder,
            online_head=online,
            replay=train_replay,
            config=replace(config, episode_id=episode_id),
            metrics=train_metrics,
            device=device,
            progress_callback=lambda values: emit("train", values),
        ))
    if not len(train_replay):
        raise RuntimeError(f"{track}: no eligible train transition for Q update")
    update_batch = train_replay.sample(min(4, len(train_replay)))
    update_losses = []
    for _ in range(updates):
        loss = train_qnetwork(
            update_batch,
            optimizer,
            online,
            target,
            device,
            gamma=0.999,
            tau=0.005,
        )
        update_losses.append(loss)
        progress["q_updates"] += 1
        progress["last_loss"] = loss
        emit("train_update", {"episode": len(train_cases), "turn": "update",
                              "replay_size": len(train_replay)})
    valid_results = []
    for episode_id, case in enumerate(valid_cases):
        valid_results.append(run_episode(
            spec=spec,
            case=case,
            split="valid",
            backend=backend,
            encoder=encoder,
            online_head=online,
            replay=valid_replay,
            config=replace(config, episode_id=episode_id),
            metrics=valid_metrics,
            device=device,
            progress_callback=lambda values: emit("valid", values),
        ))

    transitions = [
        transition
        for result in train_results + valid_results
        for transition in result.transitions
    ]
    write_jsonl(
        output_dir / f"{track}.generation_records.jsonl",
        [asdict(record) for record in backend.records[record_start:]],
    )
    write_jsonl(
        output_dir / f"{track}.transition_records.jsonl",
        [transition.state_dict() for transition in transitions],
    )
    unique_feature_counts = [len(set(item.candidate_feature_hashes)) for item in transitions]
    q_variances = [
        float(torch.tensor(item.candidate_q_values).var(unbiased=False))
        for item in transitions
    ]
    forbidden = ('"dialog"', '"strategy"', '"last_reward"', '"terminal_reason"', '"_dx_')
    semantic_gates = {
        "candidate_sets": len(transitions),
        "unique_feature_counts": unique_feature_counts,
        "candidate_features_not_all_equal": all(count > 1 for count in unique_feature_counts),
        "candidate_q_variances": q_variances,
        "actions_preserved": all(
            stat.get("action_preserved")
            for item in transitions
            for stat in item.candidate_token_stats
        ),
        "state_not_tokenizer_truncated": all(
            stat.get("truncated_state_tokens") in {0, None}
            for item in transitions
            for stat in item.candidate_token_stats
        ),
        "state_token_budget_enforced": all(
            item.state_serialization.get("token_budget_enforced", False)
            for item in transitions
        ) if getattr(encoder, "tokenizer", None) is not None else True,
        "causal_state_forbidden_keys_absent": all(
            marker not in item.state_text for item in transitions for marker in forbidden
        ),
        "next_turn_timing": all(
            item.done
            or (
                item.next_planner_state_view is not None
                and item.next_planner_state_view["turn_index"] == item.turn_index + 1
            )
            for item in transitions
        ),
        "exact_prompts_persisted": all(
            bool(record.canonical_prompt and record.prompt_sha256)
            for record in backend.records[record_start:]
        ),
    }

    checkpoint = output_dir / f"{track}.pt"
    configs = {
        "episode": asdict(config),
        "gamma": 0.999,
        "tau": 0.005,
        "learning_rate": 1e-3,
        "input_size": input_size,
    }
    manifests = {
        "model": dict(backend.manifest),
        "encoder": dict(encoder.manifest),
        "action_registry_hash": spec.action_registry_hash,
        "protocol_name": protocol_name,
        "protocol_hash": PROTOCOLS[protocol_name].sha256,
    }
    code_state = git_code_state(repo_root)
    save_checkpoint(
        checkpoint,
        online_head=online,
        target_head=target,
        optimizer=optimizer,
        replay=train_replay,
        counters={"episode": len(train_cases), "update": updates},
        behavior_track=track,
        registry_version=spec.schema_version,
        configs=configs,
        manifests=manifests,
        metrics={"train": train_metrics.summary(), "valid": valid_metrics.summary()},
        code_state=code_state,
        episode_resume={
            "episode_sampler_state": {
                "strategy": "fixed_prefix", "train_case_count": len(train_cases)
            },
            "next_episode_id": len(train_cases),
            "sampling_rng_state": train_replay.state_dict()["sampler_rng_state"],
            "epsilon_schedule": {"type": "constant", "value": epsilon},
            "backend_seed_protocol": "episode-addressable-v1",
            "target_update_count": updates,
            "validation_schedule": {"type": "fixed_prefix", "case_count": len(valid_cases)},
        },
    )
    contract = {
        "input_size": input_size,
        "learning_rate": 1e-3,
        "behavior_track": track,
        "registry_version": spec.schema_version,
        "configs": configs,
        "manifests": manifests,
        "code_state": code_state,
        "batch_size": min(4, len(train_replay)),
        "gamma": 0.999,
        "tau": 0.005,
    }
    contract_path = write_json(output_dir / f"{track}.contract.json", contract)
    deterministic = _fresh_process_pair(repo_root, checkpoint, contract_path, output_dir / track)
    return {
        "track": track,
        "train_case_ids": [case["_dx_case_id"] for case in train_cases],
        "valid_case_ids": [case["_dx_case_id"] for case in valid_cases],
        "train_results": [asdict(result) | {"transitions": len(result.transitions)} for result in train_results],
        "train_metrics": train_metrics.summary(),
        "valid_metrics": valid_metrics.summary(),
        "update_losses": update_losses,
        "semantic_gates": semantic_gates,
        "checkpoint": str(checkpoint),
        "checkpoint_sha256": sha256_file(checkpoint),
        "fresh_process_next_update": deterministic,
    }


def run_scripted_suite(repo_root: str | Path, output_dir: str | Path) -> dict[str, Any]:
    root = Path(repo_root)
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=False)
    train = load_split("esconv", "train")[:2]
    valid = load_split("esconv", "valid")[:3]
    result = {"backend": "scripted", "tracks": {}}
    for track in ("corrected_primary", "prompt_faithful"):
        result["tracks"][track] = _run_track(
            repo_root=root,
            output_dir=output,
            track=track,
            backend=ScriptedBackend(seed=7),
            encoder=DeterministicHashEncoder(32),
            input_size=32,
            train_cases=train,
            valid_cases=valid,
            device="cpu",
            seed=7,
        )
    write_json(output / "scripted_smoke_result.json", result)
    return result


def run_live_suite(
    *,
    repo_root: str | Path,
    timestamp: str,
    model_path: str | Path,
    bert_path: str | Path,
    device: str = "cuda:0",
) -> dict[str, Any]:
    root = Path(repo_root)
    code_state = git_code_state(root)
    log = TaskLog(
        root,
        "esconv_smoke",
        timestamp,
        context={
            "commit": code_state["commit"],
            "track": "corrected_primary,prompt_faithful",
            "dataset": "esconv",
            "split": "train,valid",
            "model_path": str(model_path),
            "model_hash": "pending_local_metadata",
            "gpu": os.environ.get("CUDA_VISIBLE_DEVICES", "logical:0"),
            "pid": os.getpid(),
            "tmux": "dx_esconv_7b_smoke",
        },
    )
    state = {"stage": "load", "episode": 0, "step": 0, "last_metric": None}
    stop, heartbeat = log.start_heartbeat(lambda: dict(state), interval_seconds=60)
    try:
        log.write_status(status="RUNNING", stage="load", pid=os.getpid())
        backend = TransformersLocalBackend(
            model_path,
            device=device,
            seed=7,
            dtype="bfloat16",
            do_sample=False,
            max_new_tokens=128,
            max_retries=2,
        )
        encoder = FrozenBertEncoder(bert_path, device="cpu")
        log.context["model_hash"] = backend.manifest["small_file_hashes"].get(
            "model.safetensors.index.json",
            backend.manifest["small_file_hashes"].get("config.json", "missing"),
        )
        train_base = load_split("esconv", "train")[:2]
        train = [train_base[index] for index in (0, 1, 0, 1, 0)]
        valid = load_split("esconv", "valid")[:3]
        result = {"backend": backend.manifest, "tracks": {}}
        output_dir = log.directory / "checkpoints"
        output_dir.mkdir(parents=True, exist_ok=False)
        for index, track in enumerate(("corrected_primary", "prompt_faithful"), 1):
            state.update(stage=f"track:{track}", episode=index)
            log.write_status(status="RUNNING", stage=state["stage"], pid=os.getpid())
            result["tracks"][track] = _run_track(
                repo_root=root,
                output_dir=output_dir,
                track=track,
                backend=backend,
                encoder=encoder,
                input_size=768,
                train_cases=train,
                valid_cases=valid,
                device=device,
                seed=7,
            )
            state["last_metric"] = result["tracks"][track]["valid_metrics"]
            log.flush()
        write_json(log.directory / "live_smoke_result.json", result)
        with (log.directory / "generation_records.jsonl").open(
            "w", encoding="utf-8", buffering=1
        ) as handle:
            for record in backend.records:
                handle.write(json.dumps(asdict(record), sort_keys=True) + "\n")
        state["stage"] = "complete"
        log.write_status(status="COMPLETE", stage="complete", pid=os.getpid())
        log.logger.info("live smoke complete")
        log.flush()
        return result
    except Exception as exc:
        state["stage"] = "failed"
        log.write_status(status="FAILED", stage="failed", pid=os.getpid(), error=repr(exc))
        log.logger.exception("live smoke failed")
        log.flush()
        raise
    finally:
        stop.set()
        heartbeat.join(timeout=5)
        log.close()


def run_p3_5_live_semantic_suite(
    *,
    repo_root: str | Path,
    output_dir: str | Path,
    model_path: str | Path,
    bert_path: str | Path,
    calibration_result: str | Path,
    device: str = "cuda:0",
    progress_callback: Callable[[dict[str, Any]], None] | None = None,
) -> dict[str, Any]:
    """Run the bounded corrected Q smoke and a tiny masked-mean ablation."""

    # DX-REPRO CHANGE 2026-07-17T02:54:00Z [DX-P3_5-015]
    # Base: 6ea4d579, smoke.py:run_live_suite
    # Reason: old live smoke used leaked states, greedy critics, and dual-track RL.
    # Behavior: use sampled calibrated critic, 5+5 causal CLS smoke, and tiny ablation.
    root = Path(repo_root)
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=False)
    calibration = json.loads(Path(calibration_result).read_text(encoding="utf-8"))
    calibrated_variant = calibration["selected_live_critic_prompt"]
    if calibrated_variant not in {
        "critic_appendix_full_sentence_v1", "critic_compact_enum_v1",
        "critic_released_code_v1", "paper", "compact_enum",
    }:
        raise ValueError("calibration did not select a registered critic prompt")
    # Protocol identity takes precedence over cross-protocol calibration ranking.
    # The calibrated recommendation remains evidence, but corrected execution must
    # not silently inherit Appendix semantics.
    critic_variant = PROTOCOLS["corrected_resolved_only"].critic_prompt_variant
    backend = TransformersLocalBackend(
        model_path,
        device=device,
        seed=7,
        dtype="bfloat16",
        max_retries=2,
    )
    backend.configure_critic(
        RoleGenerationConfig(12, True, 1.0, 1.0, 10),
        prompt_variant=critic_variant,
    )
    train = load_split("esconv", "train")[:5]
    valid = load_split("esconv", "valid")[:5]
    cls_encoder = FrozenBertEncoder(bert_path, device="cpu", pooling="cls")
    main_dir = output / "cls_main"
    main_dir.mkdir()
    main = _run_track(
        repo_root=root,
        output_dir=main_dir,
        track="corrected_primary",
        backend=backend,
        encoder=cls_encoder,
        input_size=768,
        train_cases=train,
        valid_cases=valid,
        device=device,
        seed=7,
        max_turns=3,
        epsilon=0.5,
        updates=2,
        critic_prompt_variant=critic_variant,
        progress_callback=progress_callback,
    )
    cls_encoder.pooling = "masked_mean"
    cls_encoder.manifest["pooling"] = "masked_mean"
    ablation_dir = output / "masked_mean_ablation"
    ablation_dir.mkdir()
    ablation = _run_track(
        repo_root=root,
        output_dir=ablation_dir,
        track="corrected_primary",
        backend=backend,
        encoder=cls_encoder,
        input_size=768,
        train_cases=train[:3],
        valid_cases=valid[:2],
        device=device,
        seed=17,
        max_turns=1,
        epsilon=0.0,
        updates=1,
        critic_prompt_variant=critic_variant,
        protocol_name="corrected_masked_mean_ablation",
        progress_callback=progress_callback,
    )
    result = {
        "status": "COMPLETE",
        "critic_variant": critic_variant,
        "calibrated_cross_protocol_recommendation": calibrated_variant,
        "critic_selection_reason": calibration["selection_reason"],
        "main_cls": main,
        "masked_mean_ablation": ablation,
        "prompt_faithful_parser_regression": "covered by offline CPU gate; no RL rerun",
        "model_manifest": backend.manifest,
    }
    write_json(output / "live_semantic_smoke_result.json", result)
    (output / "COMPLETE").write_text("COMPLETE\n", encoding="utf-8")
    return result
