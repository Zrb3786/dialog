"""Compatibility exports for corrected replay and Bellman updates."""

# DX-REPRO CHANGE 2026-07-16T06:28:17Z [DX-P1-014]
# Upstream: 7b35ec95, llm_priors.py:1-91 (buffer and train_qnetwork)
# Reason: upstream hard-coded gamma, mishandled timeout, and maxed padded candidates.
# Behavior: corrected bounded replay, bool terminal mask, and candidate masking.
from dialogxpert_repro.rl import (
    ReplayBuffer,
    Transition,
    bellman_target,
    masked_max,
    select_action,
    soft_update,
    train_qnetwork,
)

__all__ = [
    "ReplayBuffer",
    "Transition",
    "bellman_target",
    "masked_max",
    "select_action",
    "soft_update",
    "train_qnetwork",
]

