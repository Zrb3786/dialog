`artifact_sha256.tsv` hashes every regular package file present when finalized except itself. No symlink is included.
