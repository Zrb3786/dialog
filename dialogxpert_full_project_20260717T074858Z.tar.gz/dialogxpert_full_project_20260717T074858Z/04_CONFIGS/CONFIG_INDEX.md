# Config Index

All tracked configs are included under `configs/`.

- `configs/README.md` — P3.6 gate/shared
- `configs/data_manifests.yml` — P3.6 gate/shared
- `configs/p4_a/phase_a_a0_lr_1e-4.json` — P4-A arm
- `configs/p4_a/phase_a_a1_lr_1e-4.json` — P4-A arm
- `configs/p4_a/phase_a_a1_lr_1e-6.json` — P4-A arm
- `configs/p4_a/phase_a_a2_lr_1e-4.json` — P4-A arm
- `configs/p4_a/phase_a_a2_lr_1e-6.json` — P4-A arm
- `configs/p4_a/phase_a_a3_lr_1e-4.json` — P4-A arm
- `configs/p4_a/phase_b_a0_lr_1e-4.json` — P4-A arm
- `configs/p4_a/phase_b_a1_lr_1e-4.json` — P4-A arm
- `configs/p4_a/phase_b_a1_lr_1e-6.json` — P4-A arm
- `configs/p4_a/phase_b_a2_lr_1e-4.json` — P4-A arm
- `configs/p4_a/phase_b_a2_lr_1e-6.json` — P4-A arm
- `configs/p4_a/phase_b_a3_lr_1e-4.json` — P4-A arm
- `configs/p4_a/registry.json` — P4-A arm
- `configs/test_denylist.yml` — P3.6 gate/shared
