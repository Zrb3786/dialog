# Source Layout

- `02_SOURCE/project/`: complete allowlisted tracked-source snapshot.
- `03_TESTS/`: duplicate test source plus inventory and 90-test evidence.
- `04_CONFIGS/`: duplicate configs plus protocol index.
- `05_DOCS/`: duplicate tracked documentation.
- Runtime results are selected separately in `06_P3_6_RESULTS/` and
  `07_P4_A_SELECTED_RESULTS/`.
