# Current Status

- Git HEAD: `29264b72d7f3bd3156788969e15d931bb6285d48`
- Branch: `repro/dialogxpert-corrected-v1`
- P3.6 tag: `dx-p3_6-pretraining-pass-20260717T071500Z`
- P3.6 Gate A-I: **PASS**
- Reviewer marker: `P4_A_AUTHORIZED_BY_GATE`
- P4-A Phase A snapshot: **STOPPED_SNAPSHOT**
- A0: stopped after 5 train episodes at checkpoint roundtrip (`resume_mismatch`)
- A1/A2/A3: not launched
- Phase B: **NOT STARTED**
- Active P4-A tmux/PIDs at snapshot: none
- No dataset test content access, API, Qwen14B operation, download, or remote push

The tracked `docs/execution/P4_A_PILOT_REPORT.md` predates the authorized launch.
Use this status file and `07_P4_A_SELECTED_RESULTS/` for the later read-only
snapshot disposition. Packaging did not modify the repository report.
