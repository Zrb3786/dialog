# DialogXpert Full Project Package

Created at `2026-07-17T07:54:39Z` from exact clean HEAD `29264b72d7f3bd3156788969e15d931bb6285d48`. This package combines
the allowlisted tracked project, Git delta/rollback materials, P3.6 gate evidence,
and a selected P4-A stopped snapshot. It contains no raw dataset, model weights,
Conda prefix, HF cache, large/data-bearing checkpoint, or complete generation log.

See `12_MANIFESTS/artifact_sha256.tsv` for per-file hashes and
`11_SAFETY/` for exclusion scans.
