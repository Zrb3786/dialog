# Restore and Run

The original repository path was `/data1/zhangruibo/projects/dialog/dialogxpert`. Data and model assets are deliberately
absent. External local paths used by the audited run were:

- Qwen7: `/data1/zhangruibo/models/Qwen2.5-7B-Instruct`
- BERT: `/data1/zhangruibo/models/hf_cache/git_lfs_tmp_20260708_164346/bert-base-uncased`
- Conda: `/data1/zhangruibo/conda_envs/dialogxpert_qwen_v2`

Inspect `01_GIT/full_patch_since_upstream.patch` or verify
`01_GIT/thin_repro.bundle` in a repository that already has prerequisite
`7b35ec95ceaad5afeda85438c89ed67b8750625d`. The bundle is thin and does not replace the upstream checkout.

P4-A is stopped, not complete. Packaged results are a snapshot and do not replace
a final experiment report. No command in this document was executed by packaging.
