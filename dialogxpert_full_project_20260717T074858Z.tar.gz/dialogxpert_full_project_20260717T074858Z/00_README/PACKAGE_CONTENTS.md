# Package Contents

Included: tracked source/scripts/configs/tests/docs; Git patch, mbox, thin bundle,
history and rollback points; all requested P3.6 reports; 90/90 CPU TaskLog;
selected prior/critic/scripted/live artifacts; A0 P4 config/status/heartbeat/result,
four derived episode summaries and checkpoint metadata; environment/model text
manifests; safety and SHA-256 manifests.

Excluded: raw train/valid/test datasets, model weights, Qwen14B partials, Conda
prefixes, HF caches, complete P4 generation records, P4 replay/checkpoint binary,
large logs, Git objects, media and PDFs.
