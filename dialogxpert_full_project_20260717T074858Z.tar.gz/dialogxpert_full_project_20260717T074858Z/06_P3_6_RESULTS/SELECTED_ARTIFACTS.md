# Selected P3.6 Artifacts

All files are under 10 MiB and directly support a P3.6 gate.

- `artifacts/p3_6/scripted_final_20260717T063238Z/scripted_smoke_result.json` — 16012 bytes; SHA-256 `64e33aaa4ab09ccf69273fcae8cb1b4673e7a8eefe91bcf06a48b3cf9163261a`
- `artifacts/p3_6/scripted_final_20260717T063238Z/corrected_primary.contract.json` — 2194 bytes; SHA-256 `1c495199a1d046136ac881ecaed1155694d834f65dd6af7bb3a8a1823b0a8a01`
- `artifacts/p3_6/scripted_final_20260717T063238Z/prompt_faithful.contract.json` — 2202 bytes; SHA-256 `c1029f64e3ddebe1e78931f542e9ac6fc11e7888c13d4772f841e2bf77c649c3`
- `artifacts/p3_6/scripted_final_20260717T063238Z/corrected_primary.transition_records.jsonl` — 101054 bytes; SHA-256 `38f6e954551ca9319ba472bc88789f375c5a555795804963532ba9eb92fc3b52`
- `artifacts/p3_6/scripted_final_20260717T063238Z/prompt_faithful.transition_records.jsonl` — 96508 bytes; SHA-256 `a2a0a2fb74c0870129888c2d1e0f9f8faa27cc59140395816501f55a4512d476`
- `artifacts/p3_6/scripted_final_20260717T063238Z/corrected_primary/fresh_update_1.json` — 240 bytes; SHA-256 `7ebb4543442930c75d27cbde37377915fab4be346cacfbd271b367caa62e52bf`
- `artifacts/p3_6/scripted_final_20260717T063238Z/corrected_primary/fresh_update_2.json` — 240 bytes; SHA-256 `7ebb4543442930c75d27cbde37377915fab4be346cacfbd271b367caa62e52bf`
- `artifacts/p3_6/scripted_final_20260717T063238Z/prompt_faithful/fresh_update_1.json` — 239 bytes; SHA-256 `715250e87fa2aced6d973a5224581c3b9b52932775c829c1ac77da3e598bf238`
- `artifacts/p3_6/scripted_final_20260717T063238Z/prompt_faithful/fresh_update_2.json` — 239 bytes; SHA-256 `715250e87fa2aced6d973a5224581c3b9b52932775c829c1ac77da3e598bf238`
- `logs/p3_6_prior_audit/20260717T060805Z/artifacts/prior_coverage_result.json` — 7390 bytes; SHA-256 `1ae7af139d1bced5794e1f5b503415d5e156893472ca4845696f402f77591f98`
- `logs/p3_6_prior_audit/20260717T060805Z/artifacts/prior_coverage_records.jsonl` — 1431807 bytes; SHA-256 `7d889c60b430983667b3eb3185bd6f74f9ed32c596294ea9ae19a86c77305e84`
- `logs/p3_6_critic_audit/20260717T055558Z/artifacts/critic_calibration_result.json` — 116355 bytes; SHA-256 `ae2085f6dd51bf39a9dd6af298d08eb147c9531889af5cc725706f2be370eb03`
- `logs/p3_6_critic_audit/20260717T055558Z/artifacts/generation_records.jsonl` — 2758613 bytes; SHA-256 `5d26831c59667adcb3b2c24c980724bcc5b8d095a179fb6108b5679c42519a59`
- `logs/p3_6_live_audit/20260717T063210Z/artifacts/live_semantic_smoke_result.json` — 20605 bytes; SHA-256 `e8e5230299ad4ed2034acc94caf920cedb4754263899fb2c59f07b41a818b39d`
- `logs/p3_6_live_audit/20260717T063210Z/artifacts/cls_main/corrected_primary.contract.json` — 3300 bytes; SHA-256 `4b0329d261dc3b0998a9ddb1471ea92b09a6552a75116a190a2e150569574718`
- `logs/p3_6_live_audit/20260717T063210Z/artifacts/masked_mean_ablation/corrected_primary.contract.json` — 3323 bytes; SHA-256 `4e475c2ca3b1a7816a7c9f6784f2c910454a4e284bd3c611befdf5b07b690708`
- `logs/p3_6_live_audit/20260717T063210Z/artifacts/cls_main/corrected_primary.transition_records.jsonl` — 4875155 bytes; SHA-256 `de2f6e9bd63b737535e86b9fe91c48e9012ec1586b72be1f5f922104cb820bd5`
- `logs/p3_6_live_audit/20260717T063210Z/artifacts/masked_mean_ablation/corrected_primary.transition_records.jsonl` — 487580 bytes; SHA-256 `a7d2c57a1ca2ecc051ab0ed3ebd1726b26d8ff6ebd020d9cd814ada4a0c136c2`
- `logs/p3_6_live_audit/20260717T063210Z/artifacts/cls_main/corrected_primary.generation_records.jsonl` — 1212320 bytes; SHA-256 `ee22bc06b2966f01fda2dd7534bd9752eecb94437fca956e8929dff01aac2472`
- `logs/p3_6_live_audit/20260717T063210Z/artifacts/masked_mean_ablation/corrected_primary.generation_records.jsonl` — 157835 bytes; SHA-256 `4699e127daf0bbf461d9787962349e2081910a9b98d0b0d53d24d65f572f3f0d`
