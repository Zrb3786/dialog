#!/usr/bin/env bash
set -euo pipefail
cd /data1/zhangruibo/projects/dialog/dialogxpert && CUDA_VISIBLE_DEVICES='' HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 PYTHONPATH=. /data1/zhangruibo/conda_envs/dialogxpert_qwen_v2/bin/python -m unittest discover -s tests -v
