# Environment Notice

The external Conda prefix is `/data1/zhangruibo/conda_envs/dialogxpert_qwen_v2`.
It is not included. Only pre-existing textual locks/manifests are packaged. No
environment command, installation, repair, or mutation was performed.
