# P4-A Snapshot Status

- Snapshot UTC: `2026-07-17T07:54:39Z`
- Overall state: **STOPPED_SNAPSHOT**
- Active tmux sessions: none
- A0 result: `STOPPED` at train episode 5 checkpoint boundary
- Stop code: `resume_mismatch`
- A0 completed train episodes: `5`
- Baseline valid episodes attempted: `20`
- Phase B: **NOT STARTED**
- Other Phase-A arms: **NOT LAUNCHED**

This is a read-only stopped snapshot. It is not a Phase-A PASS and does not
authorize a P4-A tag. The packaging task did not restart, stop, wait for, or send
input to any tmux task.
