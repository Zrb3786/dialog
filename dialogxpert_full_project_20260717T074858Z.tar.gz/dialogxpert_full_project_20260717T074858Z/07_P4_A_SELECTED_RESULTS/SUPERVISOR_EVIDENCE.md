# Supervisor Evidence

- Intended arm order: A0, A1/1e-6, A1/1e-4, A2/1e-6, A2/1e-4, A3/1e-4.
- Initial session: `dx_p4a_phase_a_20260717T072027Z`.
- Corrected continuation session: `dx_p4a_phase_a_cont_20260717T072027Z`.
- Initial supervisor had a shell-quoting defect in its JSON status grep.
- A corrected continuation supervisor waited for A0 and enforced stop on any
  non-`COMPLETE` status.
- At this snapshot both sessions and PIDs are absent. Only the A0 directory
  exists, confirming that no later arm was launched after A0 stopped.
- The supervisor directory contained no persistent command/status/log files;
  this absence is recorded rather than reconstructed as purported source evidence.
- The actual A0 replay command is preserved in `arms/A0_lr1e-4/command.sh`.
