# Checkpoint Index

| Checkpoint | Size | SHA-256 | Binary included | Reason |
|---|---:|---|---|---|
| P3.6 scripted corrected | 156285 | `c16dc1100f09272aabaf77bfc08e9356f67499bea4de1ffa0aaf287844c3251c` | yes | small synthetic checkpoint |
| P3.6 scripted appendix | 155349 | `78c24c4f11775052f05cd795e561c58ccc959848c38a9b936338b19f03c9527e` | yes | small synthetic checkpoint |
| P3.6 live CLS | 1555110 | `65baabcba0f6d542a97233ee847b53fbd4c89b8ee5054785d38d24df5a413a5d` | no | metadata only; runtime/data-bearing binary excluded |
| P3.6 live masked mean | 969479 | `c50fa7771fb18d8bd61ca997906059850b96098728d5cf675524200ef4119c94` | no | metadata only; runtime/data-bearing binary excluded |
| P4-A A0 episode 5 | 2889651 | `3fee64703812207a9d2ac1c262721f8a6a290fc27eafd5e9af60b37899ed65e3` | no | metadata only; runtime/data-bearing binary excluded |

Included checkpoint binary total: 311634 bytes.
